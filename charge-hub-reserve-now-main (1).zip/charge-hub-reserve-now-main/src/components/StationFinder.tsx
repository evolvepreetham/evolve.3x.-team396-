
import { useState } from 'react';
import { ArrowLeft, MapPin, Filter, Zap, Clock, Star, Battery, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const StationFinder = ({ onBack, onBookStation }) => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedStation, setSelectedStation] = useState(null);

  const stations = [
    {
      id: 1,
      name: "Tesla Supercharger - Downtown",
      location: "123 Main St, Downtown",
      rating: 4.8,
      distance: "0.5 miles",
      price: "$0.35/kWh",
      chargerTypes: ["Tesla", "CCS", "CHAdeMO"],
      maxPower: "250kW",
      availableSpots: 3,
      totalSpots: 8,
      coords: [40.7128, -74.0060],
      amenities: ["WiFi", "Restroom", "Food", "Shopping"]
    },
    {
      id: 2,
      name: "EVgo Fast Charging",
      location: "456 Oak Ave, Midtown",
      rating: 4.6,
      distance: "1.2 miles",
      price: "$0.32/kWh",
      chargerTypes: ["CCS", "CHAdeMO"],
      maxPower: "150kW",
      availableSpots: 2,
      totalSpots: 4,
      coords: [40.7589, -73.9851],
      amenities: ["WiFi", "Covered"]
    },
    {
      id: 3,
      name: "ChargePoint Station",
      location: "789 Pine Rd, Uptown",
      rating: 4.7,
      distance: "2.1 miles",
      price: "$0.28/kWh",
      chargerTypes: ["J1772", "CCS"],
      maxPower: "75kW",
      availableSpots: 0,
      totalSpots: 6,
      coords: [40.7831, -73.9712],
      amenities: ["WiFi", "Shopping", "Food"]
    },
    {
      id: 4,
      name: "Electrify America",
      location: "321 Elm St, Business District",
      rating: 4.5,
      distance: "2.8 miles",
      price: "$0.43/kWh",
      chargerTypes: ["CCS", "CHAdeMO"],
      maxPower: "350kW",
      availableSpots: 5,
      totalSpots: 8,
      coords: [40.7505, -73.9934],
      amenities: ["WiFi", "Restroom", "Food", "24/7"]
    }
  ];

  const filteredStations = stations.filter(station => {
    if (selectedFilter === 'available') return station.availableSpots > 0;
    if (selectedFilter === 'fast') return parseInt(station.maxPower) >= 150;
    if (selectedFilter === 'tesla') return station.chargerTypes.includes('Tesla');
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-xl font-semibold">Find Charging Stations</h1>
          </div>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Map Section */}
          <div className="lg:col-span-2">
            <Card className="h-96 lg:h-[600px]">
              <CardContent className="p-0 h-full">
                <div className="w-full h-full bg-gradient-to-br from-blue-100 to-green-100 rounded-lg flex items-center justify-center relative overflow-hidden">
                  {/* Mock Map */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50">
                    {/* Map pins */}
                    {filteredStations.map((station, index) => (
                      <div
                        key={station.id}
                        className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all duration-200 hover:scale-110 ${
                          selectedStation?.id === station.id ? 'scale-125' : ''
                        }`}
                        style={{
                          left: `${20 + index * 15}%`,
                          top: `${30 + index * 10}%`
                        }}
                        onClick={() => setSelectedStation(station)}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg ${
                          station.availableSpots > 0 ? 'bg-green-500' : 'bg-red-500'
                        }`}>
                          <Zap className="h-4 w-4 text-white" />
                        </div>
                        {station.availableSpots > 0 && (
                          <Badge className="absolute -top-2 -right-2 text-xs bg-white text-green-600 border border-green-200">
                            {station.availableSpots}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="text-center z-10">
                    <MapPin className="h-12 w-12 text-blue-500 mx-auto mb-4" />
                    <p className="text-lg font-semibold text-gray-700 mb-2">Interactive Map</p>
                    <p className="text-gray-500">Click on pins to view station details</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stations List */}
          <div className="space-y-4">
            {/* Search and Filter */}
            <div className="space-y-3">
              <Input 
                placeholder="Search by location..."
                className="w-full"
              />
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter stations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stations</SelectItem>
                  <SelectItem value="available">Available Now</SelectItem>
                  <SelectItem value="fast">Fast Charging (150kW+)</SelectItem>
                  <SelectItem value="tesla">Tesla Compatible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Station Results */}
            <div className="text-sm text-gray-600 mb-4">
              Found {filteredStations.length} stations
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {filteredStations.map((station) => (
                <Card 
                  key={station.id} 
                  className={`cursor-pointer hover:shadow-md transition-all duration-200 ${
                    selectedStation?.id === station.id ? 'ring-2 ring-blue-500 shadow-md' : ''
                  }`}
                  onClick={() => setSelectedStation(station)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-base mb-1">{station.name}</CardTitle>
                        <p className="text-sm text-gray-600 flex items-center mb-2">
                          <MapPin className="h-3 w-3 mr-1" />
                          {station.location}
                        </p>
                        <div className="flex items-center space-x-3 text-xs text-gray-500">
                          <div className="flex items-center">
                            <Star className="h-3 w-3 text-yellow-400 fill-current mr-1" />
                            {station.rating}
                          </div>
                          <div className="flex items-center">
                            <Navigation className="h-3 w-3 mr-1" />
                            {station.distance}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold text-green-600">{station.price}</div>
                        <Badge variant="outline" className="text-xs mt-1">
                          {station.maxPower}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-1">
                          <div className={`w-2 h-2 rounded-full ${station.availableSpots > 0 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <span className="text-sm">
                            {station.availableSpots}/{station.totalSpots} available
                          </span>
                        </div>
                        <div className="flex gap-1">
                          {station.chargerTypes.slice(0, 2).map((type) => (
                            <Badge key={type} variant="secondary" className="text-xs">
                              {type}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          className="flex-1 bg-green-500 hover:bg-green-600"
                          onClick={(e) => {
                            e.stopPropagation();
                            onBookStation(station, 'spot');
                          }}
                          disabled={station.availableSpots === 0}
                        >
                          <Zap className="h-3 w-3 mr-1" />
                          {station.availableSpots === 0 ? 'Full' : 'Book Now'}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            onBookStation(station, 'prebooking');
                          }}
                        >
                          <Clock className="h-3 w-3 mr-1" />
                          Schedule
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Station Details */}
        {selectedStation && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedStation.name}</span>
                <div className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span>{selectedStation.rating}</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Station Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Location:</span>
                      <span>{selectedStation.location}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Distance:</span>
                      <span>{selectedStation.distance}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price:</span>
                      <span className="text-green-600 font-medium">{selectedStation.price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Max Power:</span>
                      <span className="font-medium">{selectedStation.maxPower}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Available:</span>
                      <span className={selectedStation.availableSpots > 0 ? 'text-green-600' : 'text-red-600'}>
                        {selectedStation.availableSpots}/{selectedStation.totalSpots} spots
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Amenities</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedStation.amenities.map((amenity) => (
                      <Badge key={amenity} variant="outline" className="text-xs">
                        {amenity}
                      </Badge>
                    ))}
                  </div>
                  <div className="mt-4 space-y-2">
                    <h5 className="font-medium text-sm">Connector Types</h5>
                    <div className="flex flex-wrap gap-1">
                      {selectedStation.chargerTypes.map((type) => (
                        <Badge key={type} variant="secondary" className="text-xs">
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <Button 
                  className="flex-1 bg-green-500 hover:bg-green-600"
                  onClick={() => onBookStation(selectedStation, 'spot')}
                  disabled={selectedStation.availableSpots === 0}
                >
                  <Zap className="h-4 w-4 mr-2" />
                  {selectedStation.availableSpots === 0 ? 'Currently Full' : 'Book Now'}
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => onBookStation(selectedStation, 'prebooking')}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Schedule Ahead
                </Button>
                <Button variant="outline">
                  <Navigation className="h-4 w-4 mr-2" />
                  Navigate
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StationFinder;
