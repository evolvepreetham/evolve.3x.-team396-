
import { useState } from 'react';
import { CheckCircle, MapPin, Calendar, Clock, Zap, CreditCard, Download, Share2, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const BookingSuccess = ({ bookingData, station, bookingType, onClose }) => {
  const [bookingId] = useState(`CHG-${Date.now().toString().slice(-6)}`);
  const isSpotBooking = bookingType === 'spot';

  const calculatePrice = () => {
    const basePrice = parseFloat(station.price.replace('$', '').replace('/kWh', ''));
    const estimatedKwh = bookingData.duration ? parseInt(bookingData.duration) * 20 / 60 : 40;
    const total = basePrice * estimatedKwh;
    const discount = !isSpotBooking ? total * 0.1 : 0;
    return {
      subtotal: total,
      discount: discount,
      total: total - discount
    };
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Success Header */}
        <div className="text-center p-8 bg-gradient-to-br from-green-50 to-emerald-50">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-green-800 mb-2">Booking Confirmed!</h2>
          <p className="text-green-600 text-lg">
            {isSpotBooking ? 'Your charging spot is reserved' : 'Your charging session is scheduled'}
          </p>
          <div className="mt-4">
            <Badge className="bg-green-100 text-green-800 text-sm px-3 py-1">
              Booking ID: {bookingId}
            </Badge>
          </div>
        </div>

        <div className="p-6">
          {/* Booking Details */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Charging Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Station</p>
                  <p className="font-semibold">{station.name}</p>
                  <p className="text-sm text-gray-500">{station.location}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Connector Type</p>
                  <Badge variant="outline" className="mt-1">
                    {bookingData.chargerType}
                  </Badge>
                </div>
              </div>

              <Separator />

              {isSpotBooking ? (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <div className="flex items-center text-orange-800 mb-2">
                    <Clock className="h-4 w-4 mr-2" />
                    <span className="font-semibold">Immediate Booking</span>
                  </div>
                  <p className="text-sm text-orange-700">
                    Your spot is reserved for the next 15 minutes. Please arrive promptly!
                  </p>
                  <div className="mt-2 text-sm">
                    <strong>Reserved until:</strong> {new Date(Date.now() + 15 * 60000).toLocaleTimeString()}
                  </div>
                </div>
              ) : (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center text-blue-800 mb-2">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span className="font-semibold">Scheduled Session</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <strong>Date:</strong> {bookingData.date}
                    </div>
                    <div>
                      <strong>Time:</strong> {bookingData.time}
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Duration</p>
                  <p className="font-medium">{bookingData.duration} minutes</p>
                </div>
                <div>
                  <p className="text-gray-600">Max Power</p>
                  <p className="font-medium">{station.maxPower}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Summary */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="h-5 w-5 mr-2" />
                Payment Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Estimated Usage:</span>
                  <span>{Math.round(parseInt(bookingData.duration || '60') * 20 / 60)} kWh</span>
                </div>
                <div className="flex justify-between">
                  <span>Rate:</span>
                  <span>{station.price}</span>
                </div>
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>${calculatePrice().subtotal.toFixed(2)}</span>
                </div>
                {!isSpotBooking && (
                  <div className="flex justify-between text-green-600">
                    <span>Pre-booking Discount (10%):</span>
                    <span>-${calculatePrice().discount.toFixed(2)}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total Paid:</span>
                  <span>${calculatePrice().total.toFixed(2)}</span>
                </div>
              </div>
              <div className="mt-4 text-xs text-gray-500">
                * Final amount will be based on actual usage
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span>{bookingData.userInfo.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span>{bookingData.userInfo.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <span>{bookingData.userInfo.phone}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>What's Next?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Confirmation Sent</p>
                    <p className="text-sm text-gray-600">
                      We've sent a confirmation email with all the details to {bookingData.userInfo.email}
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Navigate to Station</p>
                    <p className="text-sm text-gray-600">
                      Use the navigation button below to get directions to the charging station
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Start Charging</p>
                    <p className="text-sm text-gray-600">
                      {isSpotBooking 
                        ? 'Arrive within 15 minutes and start your charging session'
                        : 'Arrive at your scheduled time and start charging'
                      }
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <Button className="bg-blue-500 hover:bg-blue-600">
              <Navigation className="h-4 w-4 mr-2" />
              Get Directions
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Download Receipt
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-6">
            <Button variant="outline">
              <Share2 className="h-4 w-4 mr-2" />
              Share Details
            </Button>
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Add to Calendar
            </Button>
          </div>

          {/* Support Information */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h4 className="font-semibold mb-2">Need Help?</h4>
            <p className="text-sm text-gray-600 mb-2">
              Our 24/7 support team is here to assist you with any questions or issues.
            </p>
            <div className="text-sm">
              <p><strong>Phone:</strong> 1-800-CHARGE-1</p>
              <p><strong>Email:</strong> support@chargehub.com</p>
              <p><strong>Chat:</strong> Available in the app</p>
            </div>
          </div>

          {/* Close Button */}
          <Button onClick={onClose} className="w-full bg-green-500 hover:bg-green-600">
            Done
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BookingSuccess;
