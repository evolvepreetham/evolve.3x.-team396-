
import { useState } from 'react';
import { X, Calendar, Clock, CreditCard, Zap, MapPin, User, Mail, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import BookingSuccess from './BookingSuccess';

const BookingModal = ({ station, bookingType, onClose }) => {
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    duration: '',
    chargerType: '',
    userInfo: {
      name: '',
      email: '',
      phone: ''
    }
  });
  const [showSuccess, setShowSuccess] = useState(false);

  const isSpotBooking = bookingType === 'spot';

  const handleInputChange = (field, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setBookingData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setBookingData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const calculatePrice = () => {
    const basePrice = parseFloat(station.price.replace('$', '').replace('/kWh', ''));
    const estimatedKwh = bookingData.duration ? parseInt(bookingData.duration) * 20 : 40; // Estimate 20kWh per 30min
    const total = basePrice * estimatedKwh;
    const discount = !isSpotBooking ? total * 0.1 : 0; // 10% discount for pre-booking
    return {
      subtotal: total,
      discount: discount,
      total: total - discount
    };
  };

  const handleBooking = () => {
    // Simulate booking process
    setTimeout(() => {
      setShowSuccess(true);
    }, 2000);
  };

  if (showSuccess) {
    return <BookingSuccess bookingData={bookingData} station={station} bookingType={bookingType} onClose={onClose} />;
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold">
              {isSpotBooking ? 'Book Charging Spot' : 'Schedule Charging'}
            </h2>
            <p className="text-gray-600">{station.name}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-4">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 1 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                1
              </div>
              <div className={`w-16 h-0.5 ${step >= 2 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 2 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                2
              </div>
              <div className={`w-16 h-0.5 ${step >= 3 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 3 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                3
              </div>
            </div>
          </div>

          {/* Step 1: Booking Details */}
          {step === 1 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <MapPin className="h-5 w-5 mr-2" />
                    Station Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Location:</span>
                      <p className="font-medium">{station.location}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Max Power:</span>
                      <p className="font-medium">{station.maxPower}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Price:</span>
                      <p className="font-medium text-green-600">{station.price}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Available:</span>
                      <p className="font-medium">{station.availableSpots}/{station.totalSpots} spots</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <span className="text-gray-600">Connector Types:</span>
                    <div className="flex gap-1 mt-1">
                      {station.chargerTypes.map((type) => (
                        <Badge key={type} variant="outline" className="text-xs">
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    {isSpotBooking ? <Zap className="h-5 w-5 mr-2" /> : <Calendar className="h-5 w-5 mr-2" />}
                    {isSpotBooking ? 'Immediate Charging' : 'Schedule Details'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!isSpotBooking && (
                    <>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="date">Date</Label>
                          <Input
                            id="date"
                            type="date"
                            value={bookingData.date}
                            onChange={(e) => handleInputChange('date', e.target.value)}
                            min={new Date().toISOString().split('T')[0]}
                          />
                        </div>
                        <div>
                          <Label htmlFor="time">Time</Label>
                          <Input
                            id="time"
                            type="time"
                            value={bookingData.time}
                            onChange={(e) => handleInputChange('time', e.target.value)}
                          />
                        </div>
                      </div>
                    </>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="duration">Charging Duration</Label>
                      <Select value={bookingData.duration} onValueChange={(value) => handleInputChange('duration', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="90">1.5 hours</SelectItem>
                          <SelectItem value="120">2 hours</SelectItem>
                          <SelectItem value="180">3 hours</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="chargerType">Connector Type</Label>
                      <Select value={bookingData.chargerType} onValueChange={(value) => handleInputChange('chargerType', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select connector" />
                        </SelectTrigger>
                        <SelectContent>
                          {station.chargerTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {isSpotBooking && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <div className="flex items-center text-yellow-800">
                        <Clock className="h-4 w-4 mr-2" />
                        <span className="font-medium">Spot Booking</span>
                      </div>
                      <p className="text-sm text-yellow-700 mt-1">
                        Your charging spot will be reserved for 15 minutes. Please arrive promptly.
                      </p>
                    </div>
                  )}

                  {!isSpotBooking && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-center text-blue-800">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span className="font-medium">Pre-booking Advantage</span>
                      </div>
                      <p className="text-sm text-blue-700 mt-1">
                        Save 10% on your charging session and guarantee your spot!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 2: User Information */}
          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <User className="h-5 w-5 mr-2" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="name"
                      placeholder="Enter your full name"
                      className="pl-10"
                      value={bookingData.userInfo.name}
                      onChange={(e) => handleInputChange('userInfo.name', e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      className="pl-10"
                      value={bookingData.userInfo.email}
                      onChange={(e) => handleInputChange('userInfo.email', e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter your phone number"
                      className="pl-10"
                      value={bookingData.userInfo.phone}
                      onChange={(e) => handleInputChange('userInfo.phone', e.target.value)}
                    />
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">
                    We'll send booking confirmation and updates to your email and phone.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Payment & Confirmation */}
          {step === 3 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <CreditCard className="h-5 w-5 mr-2" />
                    Booking Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Station:</span>
                      <span className="font-medium">{station.name}</span>
                    </div>
                    {!isSpotBooking && (
                      <>
                        <div className="flex justify-between">
                          <span>Date & Time:</span>
                          <span className="font-medium">{bookingData.date} at {bookingData.time}</span>
                        </div>
                      </>
                    )}
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span className="font-medium">{bookingData.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Connector:</span>
                      <span className="font-medium">{bookingData.chargerType}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span>Estimated Usage:</span>
                      <span>{Math.round(parseInt(bookingData.duration || '60') * 20 / 60)} kWh</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>${calculatePrice().subtotal.toFixed(2)}</span>
                    </div>
                    {!isSpotBooking && (
                      <div className="flex justify-between text-green-600">
                        <span>Pre-booking Discount (10%):</span>
                        <span>-${calculatePrice().discount.toFixed(2)}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Total:</span>
                      <span>${calculatePrice().total.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border border-blue-200 bg-blue-50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CreditCard className="h-5 w-5 text-blue-600 mr-3" />
                          <div>
                            <p className="font-medium">Credit Card</p>
                            <p className="text-sm text-gray-600">Secure payment processing</p>
                          </div>
                        </div>
                        <input type="radio" checked readOnly className="text-blue-600" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <Input placeholder="Card number" />
                      <Input placeholder="MM/YY" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <Input placeholder="CVV" />
                      <Input placeholder="ZIP code" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            {step > 1 && (
              <Button variant="outline" onClick={() => setStep(step - 1)}>
                Previous
              </Button>
            )}
            {step < 3 ? (
              <Button 
                onClick={() => setStep(step + 1)}
                className="ml-auto bg-blue-500 hover:bg-blue-600"
                disabled={
                  (step === 1 && (!bookingData.duration || !bookingData.chargerType)) ||
                  (step === 2 && (!bookingData.userInfo.name || !bookingData.userInfo.email))
                }
              >
                Continue
              </Button>
            ) : (
              <Button 
                onClick={handleBooking}
                className="ml-auto bg-green-500 hover:bg-green-600"
              >
                Confirm Booking
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingModal;
