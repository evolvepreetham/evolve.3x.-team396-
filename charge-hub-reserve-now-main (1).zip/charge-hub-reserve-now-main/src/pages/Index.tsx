import { useState } from 'react';
import { Search, Zap, Clock, MapPin, Star, Battery, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import StationFinder from '@/components/StationFinder';
import BookingModal from '@/components/BookingModal';

const Index = () => {
  const [showStationFinder, setShowStationFinder] = useState(false);
  const [selectedStation, setSelectedStation] = useState(null);
  const [bookingType, setBookingType] = useState('');

  const featuredStations = [
    {
      id: 1,
      name: "Tesla Supercharger - Downtown",
      location: "123 Main St, Downtown",
      rating: 4.8,
      distance: "0.5 miles",
      price: "$0.35/kWh",
      chargerTypes: ["Tesla", "CCS", "CHAdeMO"],
      maxPower: "250kW",
      availableSpots: 3,
      totalSpots: 8,
      image: "/placeholder.svg"
    },
    {
      id: 2,
      name: "EVgo Fast Charging",
      location: "456 Oak Ave, Midtown",
      rating: 4.6,
      distance: "1.2 miles",
      price: "$0.32/kWh",
      chargerTypes: ["CCS", "CHAdeMO"],
      maxPower: "150kW",
      availableSpots: 2,
      totalSpots: 4,
      image: "/placeholder.svg"
    },
    {
      id: 3,
      name: "ChargePoint Station",
      location: "789 Pine Rd, Uptown",
      rating: 4.7,
      distance: "2.1 miles",
      price: "$0.28/kWh",
      chargerTypes: ["J1772", "CCS"],
      maxPower: "75kW",
      availableSpots: 1,
      totalSpots: 6,
      image: "/placeholder.svg"
    }
  ];

  const handleBookNow = (station, type) => {
    setSelectedStation(station);
    setBookingType(type);
  };

  if (showStationFinder) {
    return <StationFinder onBack={() => setShowStationFinder(false)} onBookStation={handleBookNow} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-emerald-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="/lovable-uploads/2b6e0e66-b5ca-4f8b-8066-96c0c0b6e4b2.png" 
              alt="ChaloCharge Logo" 
              className="h-10 w-10 object-contain"
            />
            <div className="flex flex-col">
              <span className="text-xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                ChaloCharge
              </span>
              <span className="text-xs text-gray-500 font-medium">by EVOLVE.3X Hubli</span>
            </div>
          </div>
          <nav className="hidden md:flex space-x-6">
            <a href="#" className="text-gray-700 hover:text-green-600 transition-colors">Find Stations</a>
            <a href="#" className="text-gray-700 hover:text-green-600 transition-colors">My Bookings</a>
            <a href="#" className="text-gray-700 hover:text-green-600 transition-colors">Help</a>
          </nav>
          <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
            Sign In
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
            ChaloCharge
          </h1>
          
          {/* Multilingual Slogans */}
          <div className="mb-6 space-y-2">
            <p className="text-2xl md:text-3xl font-semibold text-gray-700">
              चलोचार्ज – ಚಲೋಚಾರ್ಜ್
            </p>
            <div className="space-y-1">
              <p className="text-lg text-gray-600 font-medium">Revolutionizing the EV future</p>
              <p className="text-lg text-gray-600">ईवी भविष्य की क्रांति</p>
              <p className="text-lg text-gray-600">ವಿದ್ಯುತ್ ಪ್ರಯಾಣದಲ್ಲಿ ಕ್ರಾಂತಿ</p>
            </div>
          </div>
          
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Book EV charging spots instantly or schedule ahead. Find the fastest chargers near you with real-time availability.
          </p>
          
          {/* Search Bar */}
          <div className="bg-white rounded-2xl shadow-xl p-6 mb-8 max-w-2xl mx-auto">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input 
                  placeholder="Enter location or address" 
                  className="pl-10 h-12 text-lg border-0 focus-visible:ring-2 focus-visible:ring-green-500"
                />
              </div>
              <Button 
                onClick={() => setShowStationFinder(true)}
                size="lg" 
                className="h-12 px-8 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-lg font-semibold"
              >
                <Search className="mr-2 h-5 w-5" />
                Find Stations
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">12,000+</div>
              <div className="text-gray-600">Charging Stations</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">98%</div>
              <div className="text-gray-600">Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">24/7</div>
              <div className="text-gray-600">Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600">5min</div>
              <div className="text-gray-600">Avg. Booking</div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Start Your Charging Journey</h2>
        <div className="max-w-2xl mx-auto">
          <Card className="relative overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer" onClick={() => setShowStationFinder(true)}>
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 via-blue-400 to-purple-500"></div>
            <CardHeader>
              <div className="flex items-center justify-center space-x-3">
                <div className="bg-gradient-to-r from-green-100 to-blue-100 p-4 rounded-full">
                  <Zap className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-center">Book Your Charging Spot</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-6 text-lg">
                Find and book charging stations instantly or schedule ahead. Choose from thousands of stations with real-time availability.
              </p>
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="flex items-center justify-center space-x-2">
                  <Zap className="h-5 w-5 text-green-500" />
                  <span className="text-sm">Instant Booking</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <Calendar className="h-5 w-5 text-blue-500" />
                  <span className="text-sm">Pre-Booking Available</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <Clock className="h-5 w-5 text-purple-500" />
                  <span className="text-sm">Real-time Availability</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <MapPin className="h-5 w-5 text-orange-500" />
                  <span className="text-sm">12,000+ Stations</span>
                </div>
              </div>
              <Button 
                size="lg"
                className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-lg py-6"
              >
                <Search className="mr-2 h-5 w-5" />
                Find & Book Charging Stations
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Featured Stations */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Popular Stations Near You</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {featuredStations.map((station) => (
            <Card key={station.id} className="hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg mb-1">{station.name}</CardTitle>
                    <p className="text-sm text-gray-600 flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {station.location}
                    </p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">{station.rating}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Distance</span>
                    <span className="font-medium">{station.distance}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Price</span>
                    <span className="font-medium text-green-600">{station.price}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Max Power</span>
                    <Badge variant="outline" className="text-blue-600 border-blue-200">
                      {station.maxPower}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Available</span>
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${station.availableSpots > 0 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      <span className="text-sm font-medium">
                        {station.availableSpots}/{station.totalSpots} spots
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {station.chargerTypes.map((type) => (
                      <Badge key={type} variant="secondary" className="text-xs">
                        {type}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button 
                      size="sm" 
                      className="flex-1 bg-green-500 hover:bg-green-600"
                      onClick={() => handleBookNow(station, 'spot')}
                      disabled={station.availableSpots === 0}
                    >
                      <Zap className="h-4 w-4 mr-1" />
                      {station.availableSpots === 0 ? 'Full' : 'Book Now'}
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => handleBookNow(station, 'prebooking')}
                    >
                      <Clock className="h-4 w-4 mr-1" />
                      Schedule
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose ChaloCharge?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Battery className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Charging</h3>
              <p className="text-gray-600">Ultra-fast DC charging up to 350kW. Get back on the road in minutes, not hours.</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Everywhere You Go</h3>
              <p className="text-gray-600">Extensive network coverage with stations at shopping centers, hotels, and highways.</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
              <p className="text-gray-600">Round-the-clock customer support and real-time station monitoring for reliability.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img 
                  src="/lovable-uploads/2b6e0e66-b5ca-4f8b-8066-96c0c0b6e4b2.png" 
                  alt="ChaloCharge Logo" 
                  className="h-8 w-8 object-contain"
                />
                <div className="flex flex-col">
                  <span className="text-lg font-bold">ChaloCharge</span>
                  <span className="text-xs text-gray-400">by EVOLVE.3X Hubli</span>
                </div>
              </div>
              <p className="text-gray-400 mb-2">Revolutionizing the EV future</p>
              <p className="text-gray-400 text-sm">ईवी भविष्य की क्रांति • ವಿದ್ಯುತ್ ಪ್ರಯಾಣದಲ್ಲಿ ಕ್ರಾಂತಿ</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Find Stations</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Book Charging</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Route Planning</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Report Issue</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About EVOLVE.3X</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Partners</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 ChaloCharge by EVOLVE.3X Hubli. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      {selectedStation && (
        <BookingModal
          station={selectedStation}
          bookingType={bookingType}
          onClose={() => {
            setSelectedStation(null);
            setBookingType('');
          }}
        />
      )}
    </div>
  );
};

export default Index;
