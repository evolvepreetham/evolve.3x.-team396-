// generate_test_data.js
const admin = require("firebase-admin");

// Download your service account key from Firebase Console and put the path here:
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app"
});

const db = admin.database();
const historyRef = db.ref("charging_station/history");

function generateTestData() {
  const now = Date.now();
  const data = [];
  
  // Generate 24 hours of test data
  for (let i = 0; i < 24; i++) {
    const timestamp = now - (24 - i) * 60 * 60 * 1000; // Each hour
    
    // Simulate realistic AC values
    const ac_voltage = 220 + (Math.random() - 0.5) * 10; // 215-225V
    const ac_current = 10 + (Math.random() - 0.5) * 2; // 9-11A
    const ac_power = ac_voltage * ac_current * (0.9 + (Math.random() - 0.5) * 0.1);
    const ac_energy = (i === 0 ? 0 : data[i-1].power.ac.energy) + ac_power / 1000;
    const ac_frequency = 50 + (Math.random() - 0.5) * 0.2; // 49.9-50.1Hz
    const ac_power_factor = 0.92 + (Math.random() - 0.5) * 0.05;
    
    // Simulate realistic DC values
    const dc_voltage = 400 + (Math.random() - 0.5) * 20; // 390-410V
    const dc_current = 8 + (Math.random() - 0.5) * 2; // 7-9A
    const dc_power = dc_voltage * dc_current;
    
    // Simulate environment
    const temperature = 30 + (Math.random() - 0.5) * 5; // 27.5-32.5°C
    const humidity = 50 + (Math.random() - 0.5) * 10; // 45-55%
    
    const entry = {
      timestamp: timestamp,
      power: {
        ac: {
          voltage: +ac_voltage.toFixed(2),
          current: +ac_current.toFixed(2),
          power: +ac_power.toFixed(2),
          energy: +ac_energy.toFixed(3),
          frequency: +ac_frequency.toFixed(2),
          power_factor: +ac_power_factor.toFixed(3)
        },
        dc: {
          voltage: +dc_voltage.toFixed(2),
          current: +dc_current.toFixed(2),
          power: +dc_power.toFixed(2)
        }
      },
      environment: {
        temperature: +temperature.toFixed(2),
        humidity: +humidity.toFixed(2)
      },
      cycles: Math.floor(Math.random() * 5) + 1, // 1-5 cycles per hour
      efficiency: ac_power > 0 ? +((dc_power / ac_power) * 100).toFixed(1) : null
    };
    
    data.push(entry);
  }
  
  return data;
}

async function uploadTestData() {
  try {
    const testData = generateTestData();
    console.log(`Generated ${testData.length} test data entries`);
    
    // Upload each entry to Firebase
    for (const entry of testData) {
      await historyRef.child(entry.timestamp).set(entry);
      console.log(`Uploaded data for timestamp: ${new Date(entry.timestamp).toLocaleString()}`);
    }
    
    console.log("Test data upload completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error uploading test data:", error);
    process.exit(1);
  }
}

uploadTestData(); 