import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBIxhLuWiZCmVzHA7MLBYAxNj1OjXAqZYQ",
  authDomain: "dbs3-6e2a6.firebaseapp.com", // updated to match new project
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "dbs3-6e2a6", // updated to match new project
  // appId: "YOUR_APP_ID" // Optional: add if you have it
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);