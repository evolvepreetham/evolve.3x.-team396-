import React, { useState } from "react";
import MonitorPanel from "./components/MonitorPanel";
import MaintenancePanel from "./components/MaintenancePanel";
import MaintenanceBookingPanel from "./components/MaintenanceBookingPanel";
import HistoryPanel from "./components/HistoryPanel";
import PowerManagementPanel from "./components/PowerManagementPanel";
import "./App.css";

const STATIONS = [
  { id: "station1", name: "Charging Station 1", location: "Vidyanagar, Hubli" },
  { id: "station2", name: "Charging Station 2", location: "NH Toll, Hubli" },
  { id: "station3", name: "Charging Station 3", location: "Navanagar" },
  { id: "station4", name: "Charging Station 4", location: "Dharwad Old Bus Stand" },
  { id: "station5", name: "Charging Station 5", location: "Varur" }
];

function App() {
  const [activeTab, setActiveTab] = useState("monitor");
  const [selectedStation, setSelectedStation] = useState(null);

  const tabs = [
    { id: "monitor", label: "Monitor", component: MonitorPanel },
    { id: "history", label: "History", component: HistoryPanel },
    { id: "maintenance", label: "Maintenance", component: MaintenancePanel },
    { id: "maintenance_booking", label: "Book Technician", component: MaintenanceBookingPanel },
    { id: "power_management", label: "Power Management", component: PowerManagementPanel },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component;

  if (!selectedStation) {
    // Landing page with station cards
    return (
      <div className="App" style={{ minHeight: '100vh', background: '#f5f5f5' }}>
        <header className="App-header">
          <h1 style={{ fontSize: '2.5rem', letterSpacing: 2, marginBottom: 0 }}>EVISION</h1>
          <div style={{ fontSize: '1.1rem', color: '#888', marginTop: 0, marginBottom: 8, textTransform: 'lowercase' }}>powered by evolve.3x</div>
          <div style={{ fontSize: '1.2rem', color: '#007bff', fontWeight: 600, marginBottom: 16 }}>EVISION – Prevent. Predict. Perform.</div>
          <p style={{ fontSize: '1.2rem', color: '#888', marginTop: 0 }}>EV Charging Station Dashboard</p>
        </header>
        <main className="App-main" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
          <h2 style={{ marginBottom: '2rem' }}>Select a Charging Station</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '2rem', width: '100%', maxWidth: 1100 }}>
            {STATIONS.map(station => (
              <div
                key={station.id}
                onClick={() => { setSelectedStation(station.id); setActiveTab("monitor"); }}
                style={{
                  background: '#fff',
                  borderRadius: 16,
                  boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
                  padding: '2rem',
                  cursor: 'pointer',
                  textAlign: 'center',
                  transition: 'transform 0.15s',
                  border: '2px solid #007bff',
                  fontWeight: 600,
                  fontSize: '1.3rem',
                  color: '#222',
                  position: 'relative',
                  minHeight: 180
                }}
                className="station-card"
              >
                <span style={{ fontSize: '2.5rem', display: 'block', marginBottom: 16 }}>⚡</span>
                {station.name}
                <div style={{ fontSize: '1rem', color: '#007bff', marginTop: 12, fontWeight: 500 }}>{station.location}</div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1 style={{ fontSize: '2rem', letterSpacing: 2, marginBottom: 0 }}>EVISION</h1>
        <div style={{ fontSize: '1rem', color: '#888', marginTop: 0, marginBottom: 8, textTransform: 'lowercase' }}>powered by evolve.3x</div>
        <div style={{ fontSize: '1.1rem', color: '#007bff', fontWeight: 600, marginBottom: 8 }}>EVISION – Prevent. Predict. Perform.</div>
        <div style={{ margin: '1rem 0' }}>
          <button
            onClick={() => setSelectedStation(null)}
            style={{
              background: '#007bff',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              padding: '0.5rem 1.5rem',
              fontSize: '1rem',
              fontWeight: 600,
              cursor: 'pointer',
              marginRight: 16
            }}
          >
            ← Back to Stations
          </button>
          <span style={{ fontWeight: 600, fontSize: '1.1rem', color: '#007bff' }}>{STATIONS.find(s => s.id === selectedStation)?.name}</span>
          <span style={{ fontWeight: 500, fontSize: '1rem', color: '#444', marginLeft: 16 }}>{STATIONS.find(s => s.id === selectedStation)?.location}</span>
        </div>
      </header>
      <nav className="App-nav">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`nav-button ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </nav>
      <main className="App-main">
        {ActiveComponent && <ActiveComponent station={selectedStation} onTabChange={setActiveTab} />}
      </main>
    </div>
  );
}

export default App; 