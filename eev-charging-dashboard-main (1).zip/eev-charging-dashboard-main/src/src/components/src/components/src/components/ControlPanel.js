import React from "react";
import { ref, set } from "firebase/database";
import { db } from "../firebase";

export default function ControlPanel() {
  const sendCmd = cmd => set(ref(db, "ev_station/commands"), { action: cmd, timestamp: Date.now() });
  return (
    <div>
      <h2>Controls</h2>
      <button onClick={() => sendCmd("RELAY_ON")}>Relay ON</button>
      <button onClick={() => sendCmd("RELAY_OFF")}>Relay OFF</button>
      <button onClick={() => sendCmd("RESET_TRIP")}>Reset Trip</button>
    </div>
  );
}
