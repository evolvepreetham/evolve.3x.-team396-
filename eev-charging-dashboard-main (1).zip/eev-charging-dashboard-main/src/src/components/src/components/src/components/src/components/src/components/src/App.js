import React from "react";
import MonitorPanel from "./components/MonitorPanel";
import SlotStatus from "./components/SlotStatus";
import ControlPanel from "./components/ControlPanel";
import MaintenancePanel from "./components/MaintenancePanel";
import LogsPanel from "./components/LogsPanel";

export default function App() {
  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>EV Charging Station Dashboard</h1>
      <MonitorPanel />
      <SlotStatus />
      <ControlPanel />
      <MaintenancePanel />
      <LogsPanel />
    </div>
  );
}
