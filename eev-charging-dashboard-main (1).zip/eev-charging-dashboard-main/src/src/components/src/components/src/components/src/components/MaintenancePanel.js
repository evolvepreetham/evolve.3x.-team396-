import React, { useEffect, useState } from "react";

export default function MaintenancePanel() {
  const [alert, setAlert] = useState("");

  useEffect(() => {
    // place predictive logic here, e.g. temperature-based checks
    // For demo:
    setAlert("Temperature high — inspect cooling system.");
  }, []);

  return (
    <div>
      <h2>Maintenance Recommendations</h2>
      <p>{alert}</p>
      <h4>Periodic Maintenance</h4>
      <ul>
        <li>IR sensors: Monthly</li>
        <li>DHT11: Monthly</li>
        <li>Relay: Every 6 months</li>
      </ul>
    </div>
  );
}
