import React, { useEffect, useState } from "react";
import { db } from "../firebase";
import { ref, onValue } from "firebase/database";

export default function LogsPanel() {
  const [logs, setLogs] = useState([]);
  useEffect(() => {
    const logRef = ref(db, "ev_station/logs");
    return onValue(logRef, snap => {
      const arr = snap.val() ? Object.entries(snap.val()).map(([k,v]) => v) : [];
      setLogs(arr.reverse());
    });
  }, []);
  return (
    <div>
      <h2>Event Logs</h2>
      {logs.map((l,i) => <div key={i}>{new Date(l.timestamp).toLocaleString()}: {l.message}</div>)}
    </div>
  );
}
