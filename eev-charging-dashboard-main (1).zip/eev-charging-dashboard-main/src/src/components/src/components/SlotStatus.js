import React, { useEffect, useState } from "react";
import { db } from "../firebase";
import { ref, onValue } from "firebase/database";

export default function SlotStatus() {
  const [slots, setSlots] = useState({});
  useEffect(() => {
    const slotRef = ref(db, "ev_station/sensors");
    return onValue(slotRef, snap => {
      const d = snap.val() || {};
      setSlots({ slot1: d.slot1, slot2: d.slot2, slot3: d.slot3, slot4: d.slot4, slot5: d.slot5, slot6: d.slot6 });
    });
  }, []);
  return (
    <div>
      <h2>Slot Availability</h2>
      {Object.entries(slots).map(([k,v]) => (
        <div key={k}>{k.toUpperCase()}: {v ? "Occupied" : "Vacant"}</div>
      ))}
    </div>
  );
}
