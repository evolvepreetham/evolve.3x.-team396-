import React, { useEffect, useState } from "react";
import { db } from "../firebase";
import { ref, onValue } from "firebase/database";

export default function MonitorPanel() {
  const [data, setData] = useState({});
  useEffect(() => {
    const sensorRef = ref(db, "ev_station/sensors");
    return onValue(sensorRef, snap => setData(snap.val() || {}));
  }, []);

  return (
    <div>
      <h2>Live Monitoring</h2>
      <ul>
        {["voltage_in","voltage_out","voltage_extra","current_in","current_out","current_extra","temperature","humidity"].map(k => (
          <li key={k}>{k.replace(/_/g," ")}: {data[k]}</li>
        ))}
        <li>Power In: {data.power_in} W</li>
        <li>Power Out: {data.power_out} W</li>
        <li>Relay Status: {data.relay ? "ON" : "OFF"}</li>
        <li>Trip Status: {data.trip ? "TRIPPED" : "NORMAL"}</li>
      </ul>
    </div>
  );
}
