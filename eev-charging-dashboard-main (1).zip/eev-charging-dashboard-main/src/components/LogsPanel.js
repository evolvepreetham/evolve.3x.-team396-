import React, { useState, useEffect } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";

export default function LogsPanel() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const logsRef = ref(db, "ev_station/logs");
    const unsubscribe = onValue(logsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const logsArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        // Sort by timestamp, newest first
        logsArray.sort((a, b) => b.timestamp - a.timestamp);
        setLogs(logsArray);
      }
    });

    return () => unsubscribe();
  }, []);

  const formatDate = (timestamp) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div>
      <h2>System Logs</h2>
      <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
        {logs.map(log => (
          <div key={log.id} style={{ 
            border: '1px solid #ddd', 
            padding: '1rem', 
            margin: '0.5rem 0',
            borderRadius: '8px',
            backgroundColor: '#f8f9fa'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <span style={{ 
                fontWeight: 'bold',
                color: '#007bff'
              }}>
                Log {log.id}
              </span>
              <span style={{ fontSize: '0.8rem', color: '#666' }}>
                {formatDate(log.timestamp)}
              </span>
            </div>
            <p style={{ margin: '0.5rem 0', fontSize: '1rem' }}>{log.message}</p>
          </div>
        ))}
        {logs.length === 0 && (
          <div style={{ 
            textAlign: 'center', 
            padding: '2rem',
            color: '#666', 
            fontStyle: 'italic',
            border: '2px dashed #ddd',
            borderRadius: '8px'
          }}>
            No logs available
          </div>
        )}
      </div>
      
      {logs.length > 0 && (
        <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
          <p><strong>Total Logs:</strong> {logs.length}</p>
          <p><strong>Latest:</strong> {logs.length > 0 ? formatDate(logs[0].timestamp) : 'N/A'}</p>
        </div>
      )}
    </div>
  );
} 