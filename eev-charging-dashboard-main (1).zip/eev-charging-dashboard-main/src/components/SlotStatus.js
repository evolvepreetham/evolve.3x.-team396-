import React, { useState, useEffect } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";

function getRandomSensorData() {
  return {
    slot1: Math.random() > 0.5,
    slot2: Math.random() > 0.5,
    slot3: Math.random() > 0.5,
    slot4: Math.random() > 0.5,
    slot5: Math.random() > 0.5,
    slot6: Math.random() > 0.5
  };
}

export default function SlotStatus({ station }) {
  const [sensors, setSensors] = useState({});

  useEffect(() => {
    if (station === "station1") {
      // Fetch from new structure
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const d = snapshot.val();
        if (!d) {
          setSensors({ slots: [] });
          return;
        }
        setSensors({ slots: d.slots || [] });
      });
      return () => unsubscribe();
    } else {
      const updateDummy = () => setSensors(getRandomSensorData());
      updateDummy();
      const interval = setInterval(updateDummy, 3000);
      return () => clearInterval(interval);
    }
  }, [station]);

  // Map slots from new structure
  const slots = Array.isArray(sensors.slots)
    ? sensors.slots.map((slot, idx) => ({
        id: idx + 1,
        occupied: slot.occupied || false,
        status: slot.occupied ? 'Occupied' : 'Available'
      }))
    : [];

  return (
    <div>
      <h2>Slot Status</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
        {slots.map(slot => (
          <div key={slot.id} style={{ 
            border: '1px solid #ccc', 
            padding: '1rem', 
            borderRadius: '8px',
            backgroundColor: slot.occupied ? '#e8f5e8' : '#e8f4fd',
            borderColor: slot.occupied ? '#4caf50' : '#2196f3'
          }}>
            <h3>Slot {slot.id}</h3>
            <p>Status: <span style={{ 
              color: slot.occupied ? '#4caf50' : '#2196f3',
              fontWeight: 'bold'
            }}>
              {slot.status}
            </span></p>
            <div style={{ 
              width: '20px', 
              height: '20px', 
              borderRadius: '50%', 
              backgroundColor: slot.occupied ? '#4caf50' : '#2196f3',
              margin: '0.5rem auto'
            }}></div>
          </div>
        ))}
      </div>
      
      <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
        <h3>Summary</h3>
        <p>Occupied Slots: {slots.filter(slot => slot.occupied).length}</p>
        <p>Available Slots: {slots.filter(slot => !slot.occupied).length}</p>
        <p>Total Slots: {slots.length}</p>
      </div>
    </div>
  );
} 