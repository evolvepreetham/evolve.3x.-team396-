import React, { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";
// Remove jsPDF imports for now
// import jsPDF from "jspdf";
// import "jspdf-autotable";

function getRandomMaintenanceData() {
  const now = Date.now();
  const lastMaintenance = now - Math.floor(Math.random() * 10 * 24 * 60 * 60 * 1000);
  const nextMaintenance = now + Math.floor(Math.random() * 10 * 24 * 60 * 60 * 1000);
  const healthStates = ["Good", "Warning", "Needs Attention"];
  const health = healthStates[Math.floor(Math.random() * healthStates.length)];
  const recommendations = {
    cooling: Math.random() > 0.7 ? "Inspect fan — temperature > 50°C" : undefined,
    slots: Math.random() > 0.7 ? "IR sensor 3 not responding" : undefined
  };
  return {
    lastMaintenance,
    nextMaintenance,
    health,
    recommendations,
    predictedNext: nextMaintenance + Math.floor(Math.random() * 5 * 24 * 60 * 60 * 1000)
  };
}

export default function MaintenanceReportPanel({ station }) {
  const [maintenance, setMaintenance] = useState({});
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    if (station === "station1") {
      // Try to fetch maintenance info from new structure
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const d = snapshot.val();
        if (!d) {
          setMaintenance({});
          setLogs([]);
          return;
        }
        setMaintenance(d.system || {});
        setLogs([]); // No logs in new structure by default
      });
      return () => unsubscribe();
    } else {
      setMaintenance(getRandomMaintenanceData());
      setLogs([
        { timestamp: Date.now() - 3600000, message: "Routine check completed." },
        { timestamp: Date.now() - 7200000, message: "No issues detected." },
        { timestamp: Date.now() - 10800000, message: "Fan speed adjusted." }
      ]);
    }
  }, [station]);

  const formatDate = (timestamp) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleDateString() + ' ' + new Date(timestamp).toLocaleTimeString();
  };

  // Dummy handler for Download PDF button
  const handleDownloadPDF = () => {
    alert('PDF download feature will be available once PDF library is installed.');
  };

  // Health status icon
  const healthIcon = (health) => {
    if (health === 'Good') return <span style={{ color: '#28a745', fontWeight: 700, fontSize: 20 }}>●</span>;
    if (health === 'Warning') return <span style={{ color: '#ffc107', fontWeight: 700, fontSize: 20 }}>●</span>;
    if (health === 'Needs Attention') return <span style={{ color: '#dc3545', fontWeight: 700, fontSize: 20 }}>●</span>;
    return <span style={{ color: '#6c757d', fontWeight: 700, fontSize: 20 }}>●</span>;
  };

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', background: '#f4f6fb', borderRadius: 18, boxShadow: '0 6px 24px rgba(0,0,0,0.10)', padding: '2.5rem', fontFamily: 'Segoe UI, Arial, sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
        <h2 style={{ textAlign: 'center', margin: 0, flex: 1, letterSpacing: 1 }}>Maintenance Report</h2>
        <button onClick={handleDownloadPDF} style={{ background: 'linear-gradient(90deg, #007bff 0%, #0056b3 100%)', color: '#fff', border: 'none', borderRadius: 8, padding: '0.7rem 2rem', fontWeight: 700, fontSize: 18, cursor: 'pointer', marginLeft: 32, boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>⬇ Download PDF</button>
      </div>
      <div style={{ display: 'flex', gap: 32, marginBottom: 32 }}>
        <div style={{ flex: 1, background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', padding: 24 }}>
          <h3 style={{ marginTop: 0, color: '#007bff', letterSpacing: 0.5 }}>Maintenance Schedule</h3>
          <div style={{ marginBottom: 12 }}><strong>Last Maintenance:</strong> {formatDate(maintenance.lastMaintenance || maintenance.last_maintenance)}</div>
          <div style={{ marginBottom: 12 }}><strong>Next Scheduled:</strong> {formatDate(maintenance.nextMaintenance || maintenance.next_maintenance)}</div>
          <div style={{ marginBottom: 12 }}><strong>Predicted Next:</strong> {formatDate(maintenance.predictedNext)}</div>
        </div>
        <div style={{ flex: 1, background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', padding: 24, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center' }}>
          <h3 style={{ marginTop: 0, color: '#007bff', letterSpacing: 0.5 }}>System Health</h3>
          <div style={{ display: 'flex', alignItems: 'center', fontSize: 18 }}>
            {healthIcon(maintenance.health)}
            <span style={{ marginLeft: 12, fontWeight: 600 }}>{maintenance.health || 'Unknown'}</span>
          </div>
        </div>
      </div>
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', padding: 24, marginBottom: 32 }}>
        <h3 style={{ marginTop: 0, color: '#007bff', letterSpacing: 0.5 }}>Recommendations</h3>
        {maintenance.recommendations && (maintenance.recommendations.cooling || maintenance.recommendations.slots) ? (
          <ul style={{ margin: 0, paddingLeft: 20, fontSize: 17 }}>
            {maintenance.recommendations.cooling && <li>{maintenance.recommendations.cooling}</li>}
            {maintenance.recommendations.slots && <li>{maintenance.recommendations.slots}</li>}
          </ul>
        ) : <p style={{ fontSize: 17 }}>No recommendations at this time.</p>}
      </div>
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', padding: 24 }}>
        <h3 style={{ marginTop: 0, color: '#007bff', letterSpacing: 0.5 }}>Recent Maintenance Logs</h3>
        <ul style={{ margin: 0, paddingLeft: 20, fontSize: 16 }}>
          {logs.length === 0 && <li>No logs available.</li>}
          {logs.map((log, i) => (
            <li key={i}>{formatDate(log.timestamp)} — {log.message}</li>
          ))}
        </ul>
      </div>
    </div>
  );
} 