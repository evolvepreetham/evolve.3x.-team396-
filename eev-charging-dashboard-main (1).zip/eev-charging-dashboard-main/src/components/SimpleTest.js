import React, { useState, useEffect } from "react";
import { ref, onValue, set } from "firebase/database";
import { db } from "../firebase";

export default function SimpleTest() {
  const [status, setStatus] = useState("Initializing...");
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    console.log("SimpleTest: Starting Firebase test...");
    
    // Test 1: Try to read from root
    const rootRef = ref(db, "/");
    
    const unsubscribe = onValue(rootRef, (snapshot) => {
      console.log("SimpleTest: Root data:", snapshot.val());
      setData(snapshot.val());
      setStatus("Connected to Firebase");
      setError(null);
    }, (error) => {
      console.error("SimpleTest: Firebase error:", error);
      setError(error.message);
      setStatus("Connection failed");
    });

    return () => unsubscribe();
  }, []);

  const testWrite = async () => {
    try {
      await set(ref(db, "test/react-app"), {
        message: "Hello from React",
        timestamp: Date.now()
      });
      setStatus("Write test successful");
    } catch (err) {
      setError(err.message);
      setStatus("Write test failed");
    }
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h2>Firebase Connection Debug</h2>
      
      <div style={{ 
        padding: '1rem', 
        margin: '1rem 0',
        backgroundColor: error ? '#ffe8e8' : '#e8f5e8',
        borderRadius: '8px',
        border: '1px solid #ddd'
      }}>
        <h3>Status: {status}</h3>
        {error && <p style={{ color: 'red' }}>Error: {error}</p>}
      </div>

      <div style={{ margin: '1rem 0' }}>
        <button onClick={testWrite} style={{ marginRight: '1rem' }}>
          Test Write to Firebase
        </button>
      </div>

      <div style={{ margin: '1rem 0' }}>
        <h3>Firebase Data (Root):</h3>
        <pre style={{ 
          backgroundColor: '#f5f5f5', 
          padding: '1rem', 
          borderRadius: '8px',
          overflow: 'auto',
          maxHeight: '400px'
        }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      </div>

      <div style={{ margin: '1rem 0' }}>
        <h3>Firebase Configuration:</h3>
        <pre style={{ 
          backgroundColor: '#f5f5f5', 
          padding: '1rem', 
          borderRadius: '8px'
        }}>
          {JSON.stringify({
            databaseURL: "https://evosdb1-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "evosdb1"
          }, null, 2)}
        </pre>
      </div>
    </div>
  );
} 