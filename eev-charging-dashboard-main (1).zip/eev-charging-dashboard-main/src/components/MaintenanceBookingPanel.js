import React, { useState, useEffect } from "react";
import { ref, push, onValue, set } from "firebase/database";
import { db } from "../firebase";
import Notification from "./Notification";

const MAINTENANCE_TYPES = [
  "Preventive Maintenance",
  "Corrective Maintenance",
  "Emergency Repair",
  "System Inspection",
  "Component Replacement",
  "Software Update",
  "Hardware Upgrade",
  "Safety Check",
  "Power Supply Repair",
  "Cooling System Repair"
];

const PRIORITY_LEVELS = [
  { value: "low", label: "Low", color: "#28a745" },
  { value: "medium", label: "Medium", color: "#ffc107" },
  { value: "high", label: "High", color: "#fd7e14" },
  { value: "urgent", label: "Urgent", color: "#dc3545" }
];

const TECHNICIANS = [
  { id: "tech1", name: "Rajesh Kumar", specialization: "Electrical Systems", experience: "8 years", rating: 4.8, available: true },
  { id: "tech2", name: "Priya Sharma", specialization: "Software & IoT", experience: "6 years", rating: 4.9, available: true },
  { id: "tech3", name: "Amit Patel", specialization: "Hardware & Mechanical", experience: "10 years", rating: 4.7, available: true },
  { id: "tech4", name: "Sneha Reddy", specialization: "Network & Communication", experience: "5 years", rating: 4.6, available: false },
  { id: "tech5", name: "Vikram Singh", specialization: "Power Systems", experience: "12 years", rating: 4.9, available: true },
  { id: "tech6", name: "Arjun Mehta", specialization: "Power Supply & Cooling", experience: "9 years", rating: 4.8, available: true }
];

export default function MaintenanceBookingPanel({ station }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);
  const [formData, setFormData] = useState({
    maintenanceType: "",
    priority: "medium",
    description: "",
    scheduledDate: "",
    scheduledTime: "",
    selectedTechnician: "",
    contactPerson: "",
    contactPhone: "",
    estimatedDuration: "2"
  });

  useEffect(() => {
    // Load existing bookings
    const bookingsRef = ref(db, `maintenance_bookings/${station}`);
    const unsubscribe = onValue(bookingsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const bookingsArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setBookings(bookingsArray.sort((a, b) => b.createdAt - a.createdAt));
      } else {
        setBookings([]);
      }
    });

    return () => unsubscribe();
  }, [station]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const bookingData = {
        ...formData,
        stationId: station,
        status: "pending",
        createdAt: Date.now(),
        bookingId: `BK${Date.now()}`
      };

      const bookingsRef = ref(db, `maintenance_bookings/${station}`);
      await push(bookingsRef, bookingData);

      // Reset form
      setFormData({
        maintenanceType: "",
        priority: "medium",
        description: "",
        scheduledDate: "",
        scheduledTime: "",
        selectedTechnician: "",
        contactPerson: "",
        contactPhone: "",
        estimatedDuration: "2"
      });

      setNotification({
        message: "Maintenance booking created successfully!",
        type: "success"
      });
    } catch (error) {
      console.error("Error creating booking:", error);
      setNotification({
        message: "Error creating booking. Please try again.",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateBookingStatus = async (bookingId, newStatus) => {
    try {
      const bookingRef = ref(db, `maintenance_bookings/${station}/${bookingId}`);
      await set(ref(db, `maintenance_bookings/${station}/${bookingId}/status`), newStatus);
      setNotification({
        message: `Booking status updated to ${newStatus.replace('_', ' ')}`,
        type: "success"
      });
    } catch (error) {
      console.error("Error updating booking status:", error);
      setNotification({
        message: "Error updating booking status.",
        type: "error"
      });
    }
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleDateString() + ' ' + new Date(timestamp).toLocaleTimeString();
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return '#ffc107';
      case 'confirmed': return '#17a2b8';
      case 'in_progress': return '#007bff';
      case 'completed': return '#28a745';
      case 'cancelled': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const getPriorityColor = (priority) => {
    const priorityObj = PRIORITY_LEVELS.find(p => p.value === priority);
    return priorityObj ? priorityObj.color : '#6c757d';
  };

  return (
    <div style={{ padding: '1rem' }}>
      {notification && (
        <Notification
          message={notification.message}
          type={notification.type}
          onClose={() => setNotification(null)}
        />
      )}
      <h2>Maintenance Booking System</h2>
      
      {/* Booking Form */}
      <div style={{ 
        background: '#f8f9fa', 
        padding: '1.5rem', 
        borderRadius: '8px', 
        marginBottom: '2rem',
        border: '1px solid #dee2e6'
      }}>
        <h3>Book a Technician</h3>
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Maintenance Type *
              </label>
              <select
                name="maintenanceType"
                value={formData.maintenanceType}
                onChange={handleInputChange}
                required
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              >
                <option value="">Select Maintenance Type</option>
                {MAINTENANCE_TYPES.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Priority Level *
              </label>
              <select
                name="priority"
                value={formData.priority}
                onChange={handleInputChange}
                required
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              >
                {PRIORITY_LEVELS.map(priority => (
                  <option key={priority.value} value={priority.value}>{priority.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Scheduled Date *
              </label>
              <input
                type="date"
                name="scheduledDate"
                value={formData.scheduledDate}
                onChange={handleInputChange}
                required
                min={new Date().toISOString().split('T')[0]}
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Scheduled Time *
              </label>
              <input
                type="time"
                name="scheduledTime"
                value={formData.scheduledTime}
                onChange={handleInputChange}
                required
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Technician *
              </label>
              <select
                name="selectedTechnician"
                value={formData.selectedTechnician}
                onChange={handleInputChange}
                required
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              >
                <option value="">Select Technician</option>
                {TECHNICIANS.filter(tech => tech.available).map(tech => (
                  <option key={tech.id} value={tech.id}>
                    {tech.name} - {tech.specialization} ({tech.experience}, ⭐{tech.rating})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Estimated Duration (hours)
              </label>
              <input
                type="number"
                name="estimatedDuration"
                value={formData.estimatedDuration}
                onChange={handleInputChange}
                min="1"
                max="24"
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              />
            </div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
              Description *
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              rows="3"
              placeholder="Describe the maintenance issue or requirements..."
              style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Contact Person *
              </label>
              <input
                type="text"
                name="contactPerson"
                value={formData.contactPerson}
                onChange={handleInputChange}
                required
                placeholder="Name of contact person"
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                Contact Phone *
              </label>
              <input
                type="tel"
                name="contactPhone"
                value={formData.contactPhone}
                onChange={handleInputChange}
                required
                placeholder="Phone number"
                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ced4da' }}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              background: '#007bff',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              padding: '0.75rem 1.5rem',
              fontSize: '1rem',
              fontWeight: 'bold',
              cursor: loading ? 'not-allowed' : 'pointer',
              opacity: loading ? 0.6 : 1
            }}
          >
            {loading ? 'Creating Booking...' : 'Book Maintenance'}
          </button>
        </form>
      </div>

      {/* Available Technicians */}
      <div style={{ 
        background: '#f8f9fa', 
        padding: '1.5rem', 
        borderRadius: '8px', 
        marginBottom: '2rem',
        border: '1px solid #dee2e6'
      }}>
        <h3>Available Technicians</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          {TECHNICIANS.map(tech => (
            <div
              key={tech.id}
              style={{
                background: tech.available ? '#fff' : '#f8f9fa',
                padding: '1rem',
                borderRadius: '8px',
                border: `2px solid ${tech.available ? '#28a745' : '#6c757d'}`,
                opacity: tech.available ? 1 : 0.6
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <h4 style={{ margin: 0, color: tech.available ? '#333' : '#6c757d' }}>{tech.name}</h4>
                <span style={{ 
                  background: tech.available ? '#28a745' : '#6c757d',
                  color: '#fff',
                  padding: '0.25rem 0.5rem',
                  borderRadius: '4px',
                  fontSize: '0.8rem'
                }}>
                  {tech.available ? 'Available' : 'Unavailable'}
                </span>
              </div>
              <p style={{ margin: '0.5rem 0', color: '#666' }}><strong>Specialization:</strong> {tech.specialization}</p>
              <p style={{ margin: '0.5rem 0', color: '#666' }}><strong>Experience:</strong> {tech.experience}</p>
              <p style={{ margin: '0.5rem 0', color: '#666' }}><strong>Rating:</strong> ⭐ {tech.rating}/5.0</p>
            </div>
          ))}
        </div>
      </div>

      {/* Existing Bookings */}
      <div>
        <h3>Maintenance Bookings</h3>
        {bookings.length === 0 ? (
          <p style={{ color: '#666', fontStyle: 'italic' }}>No maintenance bookings found.</p>
        ) : (
          <div>
            {bookings.some(booking => booking.autoGenerated) && (
              <div style={{ marginBottom: '2rem' }}>
                <div style={{ 
                  background: '#e8f5e8', 
                  padding: '1rem', 
                  borderRadius: '8px', 
                  marginBottom: '1rem',
                  border: '1px solid #4caf50'
                }}>
                  <h4 style={{ margin: '0 0 0.5rem 0', color: '#2e7d32' }}>
                    🤖 Auto-Generated Bookings
                  </h4>
                  <p style={{ margin: '0', color: '#666', fontSize: '0.9rem' }}>
                    These bookings were automatically created based on system predictions and health monitoring.
                  </p>
                </div>
              </div>
            )}
            <div style={{ display: 'grid', gap: '1rem' }}>
              {bookings.map(booking => (
                <div
                  key={booking.id}
                  style={{
                    background: booking.autoGenerated ? '#f8f9fa' : '#fff',
                    padding: '1rem',
                    borderRadius: '8px',
                    border: booking.autoGenerated ? '2px solid #4caf50' : '1px solid #dee2e6',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                    <div>
                      <h4 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>
                        {booking.maintenanceType}
                        {booking.autoGenerated && (
                          <span style={{ 
                            background: '#4caf50', 
                            color: '#fff', 
                            padding: '0.2rem 0.5rem', 
                            borderRadius: '4px', 
                            fontSize: '0.7rem', 
                            marginLeft: '0.5rem' 
                          }}>
                            🤖 AUTO
                          </span>
                        )}
                      </h4>
                      <p style={{ margin: '0.5rem 0', color: '#666' }}>
                        <strong>Booking ID:</strong> {booking.bookingId}
                      </p>
                      <p style={{ margin: '0.5rem 0', color: '#666' }}>
                        <strong>Scheduled:</strong> {booking.scheduledDate} at {booking.scheduledTime}
                      </p>
                      <p style={{ margin: '0.5rem 0', color: '#666' }}>
                        <strong>Contact:</strong> {booking.contactPerson} ({booking.contactPhone})
                      </p>
                      <p style={{ margin: '0.5rem 0', color: '#666' }}>
                        <strong>Duration:</strong> {booking.estimatedDuration} hours
                      </p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{
                        background: getPriorityColor(booking.priority),
                        color: '#fff',
                        padding: '0.25rem 0.5rem',
                        borderRadius: '4px',
                        fontSize: '0.8rem',
                        marginBottom: '0.5rem'
                      }}>
                        {booking.priority.toUpperCase()} Priority
                      </div>
                      <div style={{
                        background: getStatusColor(booking.status),
                        color: '#fff',
                        padding: '0.25rem 0.5rem',
                        borderRadius: '4px',
                        fontSize: '0.8rem'
                      }}>
                        {booking.status.replace('_', ' ').toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ marginBottom: '1rem' }}>
                    <strong>Description:</strong>
                    <p style={{ margin: '0.5rem 0', color: '#666' }}>{booking.description}</p>
                  </div>

                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    {booking.status === 'pending' && (
                      <>
                        <button
                          onClick={() => updateBookingStatus(booking.id, 'confirmed')}
                          style={{
                            background: '#17a2b8',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            padding: '0.5rem 1rem',
                            fontSize: '0.9rem',
                            cursor: 'pointer'
                          }}
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => updateBookingStatus(booking.id, 'cancelled')}
                          style={{
                            background: '#dc3545',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            padding: '0.5rem 1rem',
                            fontSize: '0.9rem',
                            cursor: 'pointer'
                          }}
                        >
                          Cancel
                        </button>
                      </>
                    )}
                    {booking.status === 'confirmed' && (
                      <button
                        onClick={() => updateBookingStatus(booking.id, 'in_progress')}
                        style={{
                          background: '#007bff',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '0.5rem 1rem',
                          fontSize: '0.9rem',
                          cursor: 'pointer'
                        }}
                      >
                        Start Work
                      </button>
                    )}
                    {booking.status === 'in_progress' && (
                      <button
                        onClick={() => updateBookingStatus(booking.id, 'completed')}
                        style={{
                          background: '#28a745',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '0.5rem 1rem',
                          fontSize: '0.9rem',
                          cursor: 'pointer'
                        }}
                      >
                        Mark Complete
                      </button>
                    )}
                  </div>

                  <div style={{ fontSize: '0.8rem', color: '#999', marginTop: '0.5rem' }}>
                    Created: {formatDate(booking.createdAt)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 