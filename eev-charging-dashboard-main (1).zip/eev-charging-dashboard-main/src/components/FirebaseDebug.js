import React, { useState, useEffect } from "react";
import { ref, onValue, set, get } from "firebase/database";
import { db } from "../firebase";

export default function FirebaseDebug() {
  const [logs, setLogs] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState("Testing...");

  const addLog = (message, type = "info") => {
    setLogs(prev => [...prev, { message, type, timestamp: new Date().toLocaleTimeString() }]);
  };

  useEffect(() => {
    addLog("Starting Firebase connection test...");
    
    // Test 1: Basic connection
    const testRef = ref(db, "/");
    
    const unsubscribe = onValue(testRef, (snapshot) => {
      addLog("✅ Firebase connection successful", "success");
      addLog(`Data received: ${JSON.stringify(snapshot.val()).substring(0, 100)}...`, "info");
      setConnectionStatus("Connected");
    }, (error) => {
      addLog(`❌ Firebase connection failed: ${error.message}`, "error");
      setConnectionStatus("Failed");
    });

    return () => unsubscribe();
  }, []);

  const testSpecificPath = async (path) => {
    addLog(`Testing path: ${path}`);
    try {
      const snapshot = await get(ref(db, path));
      if (snapshot.exists()) {
        addLog(`✅ Path ${path} exists with data`, "success");
        addLog(`Data: ${JSON.stringify(snapshot.val()).substring(0, 200)}...`, "info");
      } else {
        addLog(`⚠️ Path ${path} does not exist`, "warning");
      }
    } catch (error) {
      addLog(`❌ Error reading ${path}: ${error.message}`, "error");
    }
  };

  const testWrite = async () => {
    addLog("Testing write operation...");
    try {
      await set(ref(db, "test/react-debug"), {
        message: "Test write from React app",
        timestamp: Date.now()
      });
      addLog("✅ Write test successful", "success");
    } catch (error) {
      addLog(`❌ Write test failed: ${error.message}`, "error");
    }
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
      <h2>Firebase Debug Console</h2>
      
      <div style={{ 
        padding: '1rem', 
        margin: '1rem 0',
        backgroundColor: connectionStatus === "Connected" ? '#e8f5e8' : '#ffe8e8',
        borderRadius: '8px',
        border: '1px solid #ddd'
      }}>
        <h3>Connection Status: {connectionStatus}</h3>
      </div>

      <div style={{ margin: '1rem 0' }}>
        <h3>Test Operations</h3>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
          <button onClick={() => testSpecificPath("ev_station")}>Test ev_station path</button>
          <button onClick={() => testSpecificPath("ev_station/sensors")}>Test sensors path</button>
          <button onClick={() => testSpecificPath("ev_station/commands")}>Test commands path</button>
          <button onClick={testWrite}>Test Write</button>
        </div>
      </div>

      <div style={{ margin: '1rem 0' }}>
        <h3>Debug Logs</h3>
        <div style={{ 
          backgroundColor: '#f5f5f5', 
          padding: '1rem', 
          borderRadius: '8px',
          maxHeight: '400px',
          overflowY: 'auto'
        }}>
          {logs.map((log, index) => (
            <div key={index} style={{ 
              margin: '0.25rem 0',
              padding: '0.25rem',
              borderLeft: `3px solid ${
                log.type === 'error' ? '#ff6b6b' : 
                log.type === 'success' ? '#4caf50' : 
                log.type === 'warning' ? '#ffa726' : '#2196f3'
              }`,
              paddingLeft: '0.5rem'
            }}>
              <span style={{ fontSize: '0.8rem', color: '#666' }}>{log.timestamp}</span>
              <span style={{ marginLeft: '0.5rem' }}>{log.message}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ margin: '1rem 0' }}>
        <h3>Firebase Configuration</h3>
        <pre style={{ 
          backgroundColor: '#f5f5f5', 
          padding: '1rem', 
          borderRadius: '8px',
          fontSize: '0.9rem'
        }}>
          {JSON.stringify({
            databaseURL: "https://evosdb1-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "evosdb1",
            apiKey: "AIzaSyCOYL-D4ATlYLGQo2GabVSCJBUNufPW1so"
          }, null, 2)}
        </pre>
      </div>
    </div>
  );
} 