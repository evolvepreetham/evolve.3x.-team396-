import React, { useState, useEffect } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";

function getRandomSensorData() {
  const now = Date.now();
  return {
    voltage_in: (11 + Math.random() * 3).toFixed(2),
    voltage_out: (11 + Math.random() * 3).toFixed(2),
    voltage_extra: (10 + Math.random() * 3).toFixed(2),
    current_in: (4 + Math.random() * 2).toFixed(2),
    current_out: (4 + Math.random() * 2).toFixed(2),
    current_extra: (0.1 + Math.random() * 1).toFixed(2),
    power_in: (50 + Math.random() * 20).toFixed(2),
    power_out: (45 + Math.random() * 20).toFixed(2),
    temperature: (25 + Math.random() * 15).toFixed(2),
    humidity: (30 + Math.random() * 40).toFixed(2),
    relay: Math.random() > 0.5,
    trip: Math.random() > 0.8,
    slot1: Math.random() > 0.5,
    slot2: Math.random() > 0.5,
    slot3: Math.random() > 0.5,
    slot4: Math.random() > 0.5,
    slot5: Math.random() > 0.5,
    slot6: Math.random() > 0.5,
    timestamp: now
  };
}

export default function MonitorPanel({ station }) {
  const [sensors, setSensors] = useState({});
  const [connectionStatus, setConnectionStatus] = useState("Connecting...");

  useEffect(() => {
    if (station === "station1") {
      setConnectionStatus("Connecting...");
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const d = snapshot.val();
        if (!d) {
          setSensors({});
          setConnectionStatus("No Data");
          return;
        }
        // Map all available fields, but AC/DC from power
        const sensorsData = {
          ac: d.power?.ac || {},
          dc: d.power?.dc || {},
          environment: d.environment || {},
          system: d.system || {},
          connection: d.connection || {},
          slots: d.slots || [],
          timestamp: d.timestamp || Date.now(),
          utc: d.utc || ''
        };
        console.log("Monitor Panel - Received data:", d);
        console.log("Monitor Panel - AC data:", d.power?.ac);
        console.log("Monitor Panel - Power factor:", d.power?.ac?.power_factor);
        setSensors(sensorsData);
        setConnectionStatus("Connected");
      }, (error) => {
        setConnectionStatus("Error: " + error.message);
      });
      return () => unsubscribe();
    } else {
      setConnectionStatus("Demo Mode");
      const updateDummy = () => setSensors(getRandomSensorData());
      updateDummy();
      const interval = setInterval(updateDummy, 3000);
      return () => clearInterval(interval);
    }
  }, [station]);

  // Replace the UI to show all fields from sensors
  return (
    <div>
      <h2>Station Monitor</h2>
      <div style={{ 
        padding: '0.5rem', 
        marginBottom: '1rem', 
        backgroundColor: connectionStatus === "Connected" || connectionStatus === "Demo Mode" ? '#e8f5e8' : '#ffe8e8',
        borderRadius: '4px',
        border: '1px solid #ddd'
      }}>
        <strong>Connection Status:</strong> {connectionStatus}
      </div>
      {connectionStatus === "Connected" && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>AC Readings</h3>
            <p>Voltage: {sensors.ac.voltage ?? 'N/A'} V</p>
            <p>Current: {sensors.ac.current ?? 'N/A'} A</p>
            <p>Power: {sensors.ac.power ?? 'N/A'} W</p>
            <p>Energy: {sensors.ac.energy ?? 'N/A'} kWh</p>
            <p>Frequency: {sensors.ac.frequency ?? 'N/A'} Hz</p>
            <p>Power Factor: {sensors.ac.power_factor ?? 'N/A'}</p>
          </div>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>DC Readings</h3>
            <p>Voltage: {sensors.dc.voltage ?? 'N/A'} V</p>
            <p>Current: {sensors.dc.current ?? 'N/A'} A</p>
            <p>Power: {sensors.dc.power ?? 'N/A'} W</p>
          </div>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>Environmental</h3>
            <p>Temperature: {sensors.environment.temperature ?? 'N/A'} °C</p>
            <p>Humidity: {sensors.environment.humidity ?? 'N/A'} %</p>
            <p>Fire Detected: {sensors.environment.fire_detected === false ? 'No' : sensors.environment.fire_detected === true ? 'Yes' : 'N/A'}</p>
          </div>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>System Status</h3>
            {Object.keys(sensors.system).length > 0 ? (
              <ul style={{ paddingLeft: 16 }}>
                {Object.entries(sensors.system).map(([k, v]) => (
                  <li key={k}><strong>{k}:</strong> {String(v)}</li>
                ))}
              </ul>
            ) : 'N/A'}
          </div>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>Connection Info</h3>
            {Object.keys(sensors.connection).length > 0 ? (
              <ul style={{ paddingLeft: 16 }}>
                {Object.entries(sensors.connection).map(([k, v]) => (
                  <li key={k}><strong>{k}:</strong> {String(v)}</li>
                ))}
              </ul>
            ) : 'N/A'}
          </div>
          <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
            <h3>Slot Status</h3>
            {Array.isArray(sensors.slots) && sensors.slots.length > 0 ? (
              <ul style={{ paddingLeft: 16 }}>
                {sensors.slots.map((slot, idx) => (
                  <li key={idx}><strong>Slot {idx + 1}:</strong> {slot.occupied ? 'Occupied' : 'Empty'}</li>
                ))}
              </ul>
            ) : 'N/A'}
          </div>
        </div>
      )}
      {sensors.timestamp && (
        <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#666' }}>
          Last Updated: {new Date(Number(sensors.timestamp)).toLocaleString()} | UTC: {sensors.utc}
        </p>
      )}
      <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
        <h3>Raw sensor data</h3>
        <pre style={{ fontSize: 12 }}>{JSON.stringify(sensors, null, 2)}</pre>
      </div>
    </div>
  );
} 