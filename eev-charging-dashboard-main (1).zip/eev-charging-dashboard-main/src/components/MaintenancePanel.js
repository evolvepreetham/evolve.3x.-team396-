import React, { useState, useEffect } from "react";
import { ref, onValue, push } from "firebase/database";
import { db } from "../firebase";

function getRandomMaintenanceData() {
  const now = Date.now();
  const lastMaintenance = now - Math.floor(Math.random() * 10 * 24 * 60 * 60 * 1000); // up to 10 days ago
  const nextMaintenance = now + Math.floor(Math.random() * 10 * 24 * 60 * 60 * 1000); // up to 10 days ahead
  const healthStates = ["Good", "Warning", "Needs Attention"];
  const health = healthStates[Math.floor(Math.random() * healthStates.length)];
  const recommendations = {
    cooling: Math.random() > 0.7 ? "Inspect fan — temperature > 50°C" : undefined,
    powerSupply: Math.random() > 0.7 ? "Voltage fluctuation detected in power supply unit" : undefined
  };
  return {
    lastMaintenance,
    nextMaintenance,
    health,
    recommendations,
    predictedNext: nextMaintenance + Math.floor(Math.random() * 5 * 24 * 60 * 60 * 1000) // up to 5 days after next
  };
}

export default function MaintenancePanel({ station, onTabChange }) {
  const [maintenance, setMaintenance] = useState({});
  const [suggestedBookings, setSuggestedBookings] = useState([]);
  const [showBookingSuggestions, setShowBookingSuggestions] = useState(false);

  useEffect(() => {
    if (station === "station1") {
      // Try to fetch maintenance info from new structure
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const d = snapshot.val();
        if (!d) {
          setMaintenance({});
          return;
        }
        const maintenanceData = d.system || {};
        setMaintenance(maintenanceData);
        
        // Generate suggested bookings based on maintenance data
        const suggestions = generateSuggestedBookings(maintenanceData);
        setSuggestedBookings(suggestions);
      });
      return () => unsubscribe();
    } else {
      const randomData = getRandomMaintenanceData();
      setMaintenance(randomData);
      
      // Generate suggested bookings for demo data
      const suggestions = generateSuggestedBookings(randomData);
      setSuggestedBookings(suggestions);
    }
  }, [station]);

  const formatDate = (timestamp) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleDateString() + ' ' + new Date(timestamp).toLocaleTimeString();
  };

  // Generate suggested bookings based on maintenance predictions
  const generateSuggestedBookings = (maintenanceData) => {
    const suggestions = [];
    const now = Date.now();
    
    // Check if system health needs attention
    if (maintenanceData.health === 'Warning' || maintenanceData.health === 'Needs Attention') {
      suggestions.push({
        id: 'health-check',
        type: 'System Health Check',
        priority: maintenanceData.health === 'Needs Attention' ? 'high' : 'medium',
        description: `System health is ${maintenanceData.health.toLowerCase()}. Immediate inspection required.`,
        estimatedDuration: 2,
        urgency: 'within 24 hours'
      });
    }

    // Check if predicted maintenance is due soon (within 7 days)
    if (maintenanceData.predictedNext && (maintenanceData.predictedNext - now) < 7 * 24 * 60 * 60 * 1000) {
      suggestions.push({
        id: 'predicted-maintenance',
        type: 'Preventive Maintenance',
        priority: 'medium',
        description: 'Predicted maintenance due soon. Schedule preventive maintenance to avoid issues.',
        estimatedDuration: 4,
        urgency: 'within 3 days'
      });
    }

    // Check for specific recommendations
    if (maintenanceData.recommendations) {
      if (maintenanceData.recommendations.cooling) {
        suggestions.push({
          id: 'cooling-issue',
          type: 'Cooling System Repair',
          priority: 'high',
          description: maintenanceData.recommendations.cooling,
          estimatedDuration: 3,
          urgency: 'within 12 hours'
        });
      }
      
      if (maintenanceData.recommendations.powerSupply) {
        suggestions.push({
          id: 'power-supply-issue',
          type: 'Power Supply Repair',
          priority: 'high',
          description: maintenanceData.recommendations.powerSupply,
          estimatedDuration: 4,
          urgency: 'within 6 hours'
        });
      }
    }

    return suggestions;
  };

  const createBookingFromSuggestion = async (suggestion) => {
    try {
      const bookingData = {
        maintenanceType: suggestion.type,
        priority: suggestion.priority,
        description: suggestion.description,
        scheduledDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Tomorrow
        scheduledTime: '09:00',
        selectedTechnician: 'tech1', // Default to first available technician
        contactPerson: 'System Admin',
        contactPhone: '+91-9876543210',
        estimatedDuration: suggestion.estimatedDuration.toString(),
        stationId: station,
        status: 'pending',
        createdAt: Date.now(),
        bookingId: `BK${Date.now()}`,
        autoGenerated: true,
        urgency: suggestion.urgency
      };

      const bookingsRef = ref(db, `maintenance_bookings/${station}`);
      await push(bookingsRef, bookingData);
      
      alert(`Booking created for ${suggestion.type}!`);
      setShowBookingSuggestions(false);
    } catch (error) {
      console.error("Error creating booking:", error);
      alert("Error creating booking. Please try again.");
    }
  };

  return (
    <div>
      <h2>Maintenance Panel</h2>
      <div style={{ 
        background: '#e3f2fd', 
        padding: '1rem', 
        borderRadius: '8px', 
        marginBottom: '2rem',
        border: '1px solid #2196f3'
      }}>
        <h3 style={{ margin: '0 0 1rem 0', color: '#1976d2' }}>📋 Quick Actions</h3>
        <p style={{ margin: '0 0 1rem 0', color: '#333' }}>
          Need to schedule maintenance? Book a technician for preventive maintenance, repairs, or emergency services.
        </p>
        <button
          onClick={() => onTabChange && onTabChange('maintenance_booking')}
          style={{
            background: '#2196f3',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            padding: '0.75rem 1.5rem',
            fontSize: '1rem',
            fontWeight: 'bold',
            cursor: 'pointer'
          }}
        >
          🛠️ Book a Technician
        </button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
          <h3>Last Maintenance</h3>
          <p>{formatDate(maintenance.lastMaintenance || maintenance.last_maintenance)}</p>
        </div>
        <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
          <h3>Next Scheduled Maintenance</h3>
          <p>{formatDate(maintenance.nextMaintenance || maintenance.next_maintenance)}</p>
        </div>
        <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
          <h3>Predicted Next Maintenance</h3>
          <p>{formatDate(maintenance.predictedNext)}</p>
        </div>
        <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
          <h3>System Health</h3>
          <p style={{ color: maintenance.health === 'Good' ? 'green' : maintenance.health === 'Warning' ? 'orange' : 'red', fontWeight: 'bold' }}>{maintenance.health || 'Unknown'}</p>
        </div>
      </div>
      <div style={{ border: '1px solid #ddd', padding: '1rem', borderRadius: '8px', marginBottom: '2rem' }}>
        <h3>Recommendations</h3>
        {maintenance.recommendations && (
          <>
            {maintenance.recommendations.cooling && (
              <div style={{ padding: '0.5rem', backgroundColor: '#fff3cd', border: '1px solid #ffeaa7', borderRadius: '4px', marginBottom: '0.5rem' }}>
                <strong>Cooling:</strong> {maintenance.recommendations.cooling}
              </div>
            )}
            {maintenance.recommendations.powerSupply && (
              <div style={{ padding: '0.5rem', backgroundColor: '#fff3cd', border: '1px solid #ffeaa7', borderRadius: '4px' }}>
                <strong>Power Supply:</strong> {maintenance.recommendations.powerSupply}
              </div>
            )}
            {!(maintenance.recommendations.cooling || maintenance.recommendations.powerSupply) && <p>No recommendations at this time.</p>}
          </>
        )}
        {!maintenance.recommendations && <p>No recommendations at this time.</p>}
      </div>

      {/* Smart Booking Suggestions */}
      {suggestedBookings.length > 0 && (
        <div style={{ 
          border: '1px solid #ff9800', 
          padding: '1rem', 
          borderRadius: '8px', 
          marginBottom: '2rem',
          background: '#fff3e0'
        }}>
          <h3 style={{ margin: '0 0 1rem 0', color: '#e65100' }}>
            🔥 Smart Booking Suggestions
          </h3>
          <p style={{ margin: '0 0 1rem 0', color: '#666' }}>
            Based on system predictions and current health status, we recommend the following maintenance bookings:
          </p>
          
          <div style={{ display: 'grid', gap: '1rem' }}>
            {suggestedBookings.map((suggestion, index) => (
              <div
                key={suggestion.id}
                style={{
                  background: '#fff',
                  padding: '1rem',
                  borderRadius: '8px',
                  border: '1px solid #ff9800',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div style={{ flex: 1 }}>
                  <h4 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>
                    {suggestion.type}
                  </h4>
                  <p style={{ margin: '0.5rem 0', color: '#666', fontSize: '0.9rem' }}>
                    {suggestion.description}
                  </p>
                  <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem' }}>
                    <span style={{
                      background: suggestion.priority === 'high' ? '#dc3545' : suggestion.priority === 'medium' ? '#ffc107' : '#28a745',
                      color: suggestion.priority === 'medium' ? '#333' : '#fff',
                      padding: '0.25rem 0.5rem',
                      borderRadius: '4px',
                      fontSize: '0.8rem',
                      fontWeight: 'bold'
                    }}>
                      {suggestion.priority.toUpperCase()} Priority
                    </span>
                    <span style={{
                      background: '#e3f2fd',
                      color: '#1976d2',
                      padding: '0.25rem 0.5rem',
                      borderRadius: '4px',
                      fontSize: '0.8rem'
                    }}>
                      ⏰ {suggestion.urgency}
                    </span>
                    <span style={{
                      background: '#f3e5f5',
                      color: '#7b1fa2',
                      padding: '0.25rem 0.5rem',
                      borderRadius: '4px',
                      fontSize: '0.8rem'
                    }}>
                      ⏱️ {suggestion.estimatedDuration}h
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => createBookingFromSuggestion(suggestion)}
                  style={{
                    background: '#ff9800',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '0.5rem 1rem',
                    fontSize: '0.9rem',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    marginLeft: '1rem'
                  }}
                >
                  📋 Auto-Book
                </button>
              </div>
            ))}
          </div>
          
          <div style={{ marginTop: '1rem', textAlign: 'center' }}>
            <button
              onClick={() => onTabChange && onTabChange('maintenance_booking')}
              style={{
                background: '#e65100',
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                padding: '0.75rem 1.5rem',
                fontSize: '1rem',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}
            >
              🛠️ View All Bookings
            </button>
          </div>
        </div>
      )}
    </div>
  );
} 