import React, { useState, useEffect } from "react";
import { ref, onValue, set, get } from "firebase/database";
import { db } from "../firebase";

export default function TestConnection() {
  const [testData, setTestData] = useState(null);
  const [writeStatus, setWriteStatus] = useState("");
  const [readStatus, setReadStatus] = useState("");

  // Test read operation
  useEffect(() => {
    console.log("TestConnection: Testing read operation...");
    const testRef = ref(db, "ev_station/sensors");
    
    const unsubscribe = onValue(testRef, (snapshot) => {
      console.log("TestConnection: Read successful:", snapshot.val());
      setTestData(snapshot.val());
      setReadStatus("Read successful");
    }, (error) => {
      console.error("TestConnection: Read error:", error);
      setReadStatus("Read error: " + error.message);
    });

    return () => unsubscribe();
  }, []);

  // Test write operation
  const testWrite = async () => {
    console.log("TestConnection: Testing write operation...");
    setWriteStatus("Writing...");
    
    try {
      await set(ref(db, "ev_station/test"), {
        message: "Test write from React app",
        timestamp: Date.now()
      });
      console.log("TestConnection: Write successful");
      setWriteStatus("Write successful");
    } catch (error) {
      console.error("TestConnection: Write error:", error);
      setWriteStatus("Write error: " + error.message);
    }
  };

  return (
    <div style={{ padding: '1rem', border: '2px solid #007bff', borderRadius: '8px', margin: '1rem 0' }}>
      <h3>Firebase Connection Test</h3>
      
      <div style={{ marginBottom: '1rem' }}>
        <strong>Read Status:</strong> {readStatus}
      </div>
      
      <div style={{ marginBottom: '1rem' }}>
        <button onClick={testWrite}>Test Write Operation</button>
        <strong>Write Status:</strong> {writeStatus}
      </div>
      
      <div style={{ marginBottom: '1rem' }}>
        <strong>Test Data:</strong>
        <pre style={{ backgroundColor: '#f5f5f5', padding: '0.5rem', borderRadius: '4px' }}>
          {JSON.stringify(testData, null, 2)}
        </pre>
      </div>
    </div>
  );
} 