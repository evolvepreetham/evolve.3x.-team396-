import React, { useState, useEffect } from "react";
import { ref, onValue, set, push, update } from "firebase/database";
import { db } from "../firebase";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";

// Mock data generators for demo
const generatePowerData = () => {
  const data = [];
  const now = new Date();
  for (let i = 10; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 5 * 60000);
    const dynamicLoad = 300 + Math.random() * 200;
    const nonDynamicLoad = dynamicLoad + 150 + Math.random() * 100;
    const dynamicSavings = nonDynamicLoad - dynamicLoad;
    const gridAllocated = Math.min(800, dynamicLoad + 50);
    
    data.push({
      time: time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      dynamicLoad: Math.round(dynamicLoad),
      nonDynamicLoad: Math.round(nonDynamicLoad),
      dynamicSavings: Math.round(dynamicSavings),
      gridAllocated: Math.round(gridAllocated),
      gridLimit: 800
    });
  }
  return data;
};

const generateGridRequests = () => [
  {
    id: "REQ-001",
    type: "power_increase",
    requestedPower: 150,
    status: "approved",
    timestamp: "14:30",
    reason: "High demand period"
  },
  {
    id: "REQ-002", 
    type: "power_decrease",
    requestedPower: 75,
    status: "pending",
    timestamp: "14:25",
    reason: "Low demand period"
  }
];

const generateChargingSlots = () => [
  {
    id: "slot1",
    status: "charging",
    currentPower: 18.5,
    maxPower: 20,
    sessionDuration: 23,
    sessionCost: 12.50,
    vehicleId: "KA-01-AB-1234"
  },
  {
    id: "slot2", 
    status: "charging",
    currentPower: 19.2,
    maxPower: 20,
    sessionDuration: 15,
    sessionCost: 8.20,
    vehicleId: "KA-01-CD-5678"
  },
  {
    id: "slot3",
    status: "available",
    currentPower: 0,
    maxPower: 20,
    sessionDuration: 0,
    sessionCost: 0,
    vehicleId: null
  },
  {
    id: "slot4",
    status: "charging",
    currentPower: 17.8,
    maxPower: 20,
    sessionDuration: 31,
    sessionCost: 16.80,
    vehicleId: "KA-01-EF-9012"
  }
];

const PowerGauge = ({ currentPower, maxPower, gridLimit, title }) => {
  const powerPercentage = (currentPower / maxPower) * 100;
  const gridPercentage = (currentPower / gridLimit) * 100;
  const isNearLimit = gridPercentage > 85;
  const isOverLimit = gridPercentage > 100;

  // Calculate grid costs with correct logic
  const baseLoad = 20; // Fixed base load (kW) - updated to match new logic
  const additionalPower = Math.max(0, currentPower - baseLoad); // Extra power beyond base
  
  // Daily consumption calculations
  const baseLoadDaily = baseLoad * 24; // Base load daily (kWh)
  const additionalPowerDaily = additionalPower * 24; // Additional power daily (kWh)
  const totalDailyConsumption = baseLoadDaily + additionalPowerDaily; // Total daily (kWh)
  
  // Normal case: Pay for 90% of 80 kW capacity
  const normalCaseDaily = 80 * 0.9 * 24; // 72 kW * 24 hours = 1728 kWh daily
  const normalCaseCost = normalCaseDaily * 8; // ₹8/kWh for normal case
  
  // Dynamic case: Base load + additional power
  const dynamicBaseCost = baseLoadDaily * 6; // ₹6/kWh for base load
  const dynamicAdditionalCost = additionalPowerDaily * 8; // ₹8/kWh for additional power
  const dynamicTotalCost = dynamicBaseCost + dynamicAdditionalCost;
  
  const gridCostSavings = normalCaseCost - dynamicTotalCost;

  const getStatusColor = () => {
    if (isOverLimit) return '#ef4444';
    if (isNearLimit) return '#f59e0b';
    return '#10b981';
  };

  const getStatusText = () => {
    if (isOverLimit) return 'OVER LIMIT';
    if (isNearLimit) return 'NEAR LIMIT';
    return 'NORMAL';
  };

  return (
    <div className="power-gauge" style={{
      background: '#fff',
      borderRadius: 12,
      padding: '1.5rem',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      border: `2px solid ${getStatusColor()}`,
      position: 'relative'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <h3 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0 }}>{title}</h3>
        <div style={{
          padding: '0.5rem 1rem',
          borderRadius: 20,
          backgroundColor: getStatusColor(),
          color: '#fff',
          fontSize: '0.8rem',
          fontWeight: 600
        }}>
          {getStatusText()}
        </div>
      </div>

      <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#007bff', marginBottom: '0.5rem' }}>
          {currentPower.toFixed(1)}
          <span style={{ fontSize: '1.2rem', color: '#666', marginLeft: '0.5rem' }}>kW</span>
        </div>
        <div style={{ fontSize: '0.9rem', color: '#666' }}>
          of {maxPower} kW capacity
        </div>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '0.5rem' }}>
          <span style={{ color: '#666' }}>Power Usage</span>
          <span>{powerPercentage.toFixed(1)}%</span>
        </div>
        <div style={{
          width: '100%',
          height: '8px',
          backgroundColor: '#e5e7eb',
          borderRadius: 4,
          overflow: 'hidden'
        }}>
          <div style={{
            width: `${powerPercentage}%`,
            height: '100%',
            backgroundColor: '#007bff',
            transition: 'width 0.3s ease'
          }} />
        </div>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '0.5rem' }}>
          <span style={{ color: '#666' }}>Grid Limit</span>
          <span style={{ color: isOverLimit ? '#ef4444' : '#333' }}>
            {gridPercentage.toFixed(1)}%
          </span>
        </div>
        <div style={{
          width: '100%',
          height: '6px',
          backgroundColor: '#e5e7eb',
          borderRadius: 3,
          overflow: 'hidden',
          position: 'relative'
        }}>
          <div style={{
            width: `${Math.min(gridPercentage, 100)}%`,
            height: '100%',
            backgroundColor: isOverLimit ? '#ef4444' : isNearLimit ? '#f59e0b' : '#10b981',
            transition: 'width 0.3s ease'
          }} />
          <div style={{
            position: 'absolute',
            top: 0,
            left: '85%',
            height: '100%',
            width: '2px',
            backgroundColor: '#666'
          }} />
        </div>
        <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.25rem' }}>
          Grid limit: {gridLimit} kW
        </div>
      </div>

      {/* Grid Cost Information */}
      <div style={{ 
        marginBottom: '1rem', 
        padding: '1rem', 
        backgroundColor: '#f8f9fa', 
        borderRadius: 8,
        border: '1px solid #e5e7eb'
      }}>
        <div style={{ fontSize: '0.9rem', fontWeight: 600, color: '#666', marginBottom: '0.75rem' }}>
          Daily Grid Power Costs:
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: '#666' }}>Normal Case (90% of 80kW)</span>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#ef4444' }}>
            ₹{normalCaseCost.toFixed(2)}
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: '#666' }}>Base Load (40kW @ ₹6/kWh)</span>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#10b981' }}>
            ₹{dynamicBaseCost.toFixed(2)}
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: '#666' }}>Additional Power ({additionalPower.toFixed(1)}kW @ ₹8/kWh)</span>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#f59e0b' }}>
            ₹{dynamicAdditionalCost.toFixed(2)}
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e5e7eb', paddingTop: '0.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: '#666' }}>Total Dynamic Cost</span>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#007bff' }}>
            ₹{dynamicTotalCost.toFixed(2)}
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e5e7eb', paddingTop: '0.25rem' }}>
          <span style={{ fontSize: '0.8rem', color: '#666' }}>Daily Savings</span>
          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#10b981' }}>
            ₹{gridCostSavings.toFixed(2)}
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', paddingTop: '1rem', borderTop: '1px solid #e5e7eb' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
            {powerPercentage.toFixed(0)}%
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Utilization</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>
            {(maxPower - currentPower).toFixed(1)}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Available kW</div>
        </div>
      </div>
    </div>
  );
};

const GridInteractionWidget = ({ requests, currentAllocation, maxAllocation, onNewRequest }) => {
  const [requestPower, setRequestPower] = useState(0);
  const [isRequesting, setIsRequesting] = useState(false);

  const pendingRequests = requests.filter(r => r.status === 'pending');
  const latestRequest = requests[0];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return '✅';
      case 'denied': return '❌';
      default: return '⏳';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return '#10b981';
      case 'denied': return '#ef4444';
      default: return '#f59e0b';
    }
  };

  const handleRequest = async (type) => {
    setIsRequesting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    onNewRequest(requestPower, type);
    setRequestPower(0);
    setIsRequesting(false);
  };

  const utilizationPercentage = (currentAllocation / maxAllocation) * 100;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {/* Current Grid Status */}
      <div style={{
        background: '#fff',
        borderRadius: 12,
        padding: '1.5rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0 }}>Grid Allocation</h3>
          <div style={{
            padding: '0.5rem 1rem',
            borderRadius: 20,
            backgroundColor: utilizationPercentage > 90 ? '#f59e0b' : '#10b981',
            color: '#fff',
            fontSize: '0.8rem',
            fontWeight: 600
          }}>
            ⚡ {utilizationPercentage.toFixed(1)}% Utilized
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.9rem', color: '#666' }}>Current Allocation</span>
            <span style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>{currentAllocation} kW</span>
          </div>
          
          <div style={{
            width: '100%',
            height: '8px',
            backgroundColor: '#e5e7eb',
            borderRadius: 4,
            overflow: 'hidden'
          }}>
            <div style={{
              width: `${utilizationPercentage}%`,
              height: '100%',
              backgroundColor: '#007bff',
              transition: 'width 0.3s ease'
            }} />
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: '#666' }}>
            <span>0 kW</span>
            <span>Max: {maxAllocation} kW</span>
          </div>
        </div>
      </div>

      {/* Active Requests */}
      {pendingRequests.length > 0 && (
        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '1.5rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          border: '2px solid #f59e0b'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
            <span style={{ fontSize: '1.2rem' }}>⏳</span>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0 }}>Pending Requests</h3>
            <div style={{
              padding: '0.25rem 0.5rem',
              borderRadius: 12,
              backgroundColor: '#f59e0b',
              color: '#fff',
              fontSize: '0.7rem',
              fontWeight: 600
            }}>
              {pendingRequests.length}
            </div>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {pendingRequests.slice(0, 3).map((request) => (
              <div key={request.id} style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '0.75rem',
                backgroundColor: '#f8f9fa',
                borderRadius: 8
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span>{getStatusIcon(request.status)}</span>
                  <span style={{ fontSize: '0.9rem' }}>
                    {request.type.replace('_', ' ').toUpperCase()}: {request.requestedPower} kW
                  </span>
                </div>
                <span style={{ fontSize: '0.8rem', color: '#666' }}>{request.timestamp}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* New Request Interface */}
      <div style={{
        background: '#fff',
        borderRadius: 12,
        padding: '1.5rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0, marginBottom: '1rem' }}>Request Power Adjustment</h3>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={{ fontSize: '0.9rem', color: '#666', display: 'block', marginBottom: '0.5rem' }}>
              Power Amount (kW)
            </label>
            <input
              type="number"
              value={requestPower}
              onChange={(e) => setRequestPower(Number(e.target.value))}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: 8,
                fontSize: '1rem'
              }}
              placeholder="Enter power amount..."
              min="0"
              max={maxAllocation}
            />
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            <button
              onClick={() => handleRequest('power_increase')}
              disabled={isRequesting || requestPower <= 0}
              style={{
                padding: '0.75rem',
                backgroundColor: '#007bff',
                color: '#fff',
                border: 'none',
                borderRadius: 8,
                fontSize: '0.9rem',
                fontWeight: 600,
                cursor: isRequesting || requestPower <= 0 ? 'not-allowed' : 'pointer',
                opacity: isRequesting || requestPower <= 0 ? 0.5 : 1
              }}
            >
              📤 Request Increase
            </button>
            <button
              onClick={() => handleRequest('power_decrease')}
              disabled={isRequesting || requestPower <= 0}
              style={{
                padding: '0.75rem',
                backgroundColor: '#fff',
                color: '#007bff',
                border: '1px solid #007bff',
                borderRadius: 8,
                fontSize: '0.9rem',
                fontWeight: 600,
                cursor: isRequesting || requestPower <= 0 ? 'not-allowed' : 'pointer',
                opacity: isRequesting || requestPower <= 0 ? 0.5 : 1
              }}
            >
              📤 Request Decrease
            </button>
          </div>
          
          <button
            onClick={() => handleRequest('emergency')}
            disabled={isRequesting}
            style={{
              width: '100%',
              padding: '0.75rem',
              backgroundColor: '#ef4444',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              fontSize: '0.9rem',
              fontWeight: 600,
              cursor: isRequesting ? 'not-allowed' : 'pointer',
              opacity: isRequesting ? 0.5 : 1
            }}
          >
            🚨 Emergency Request
          </button>
        </div>
      </div>
    </div>
  );
};

const ChargingSlotCard = ({ slot, onOverride, onPowerAdjustment, onEmergencyStop }) => {
  const getStatusColor = () => {
    switch (slot.status) {
      case 'charging': return '#10b981';
      case 'active': return '#007bff';
      case 'available': return '#6b7280';
      case 'maintenance': return '#f59e0b';
      case 'error': return '#ef4444';
      case 'offline': return '#6b7280';
      default: return '#ef4444';
    }
  };

  const getStatusText = () => {
    switch (slot.status) {
      case 'charging': return '⚡ Charging';
      case 'active': return '🟢 Active';
      case 'available': return '⚪ Available';
      case 'maintenance': return '🔧 Maintenance';
      case 'error': return '❌ Error';
      case 'offline': return '🔴 Offline';
      default: return '❓ Unknown';
    }
  };

  const getStatusIcon = () => {
    switch (slot.status) {
      case 'charging': return '⚡';
      case 'active': return '🟢';
      case 'available': return '⚪';
      case 'maintenance': return '🔧';
      case 'error': return '❌';
      case 'offline': return '🔴';
      default: return '❓';
    }
  };

  // Calculate power efficiency
  const powerEfficiency = slot.maxPower > 0 ? (slot.currentPower / slot.maxPower) * 100 : 0;
  
  // Calculate grid cost with correct logic
  const baseLoad = 40; // Fixed base load (kW)
  const additionalPower = Math.max(0, slot.currentPower - (baseLoad / 4)); // Per slot additional power
  
  // Session consumption calculations (convert minutes to hours)
  const sessionHours = slot.sessionDuration / 60;
  const baseLoadSession = (baseLoad / 4) * sessionHours; // Base load per slot (kWh)
  const additionalPowerSession = additionalPower * sessionHours; // Additional power per slot (kWh)
  
  // Normal case: Pay for 90% of 80 kW capacity per slot
  const normalCaseSession = (80 * 0.9 / 4) * sessionHours; // 18 kW per slot (kWh)
  const normalCaseCost = normalCaseSession * 8; // ₹8/kWh for normal case
  
  // Dynamic case: Base load + additional power
  const dynamicBaseCost = baseLoadSession * 6; // ₹6/kWh for base load
  const dynamicAdditionalCost = additionalPowerSession * 8; // ₹8/kWh for additional power
  const dynamicTotalCost = dynamicBaseCost + dynamicAdditionalCost;
  
  const gridCostSavings = normalCaseCost - dynamicTotalCost;

  return (
    <div style={{
      background: '#fff',
      borderRadius: 12,
      padding: '1.5rem',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      border: `2px solid ${getStatusColor()}`,
      position: 'relative'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <h4 style={{ fontSize: '1.1rem', fontWeight: 600, margin: 0 }}>Slot {slot.id}</h4>
        <div style={{
          padding: '0.25rem 0.75rem',
          borderRadius: 12,
          backgroundColor: getStatusColor(),
          color: '#fff',
          fontSize: '0.8rem',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: '0.25rem'
        }}>
          {getStatusIcon()} {getStatusText().split(' ')[1]}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.9rem', color: '#666' }}>Current Power</span>
          <span style={{ fontSize: '1rem', fontWeight: 600, color: '#007bff' }}>
            {slot.currentPower.toFixed(1)} kW
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.9rem', color: '#666' }}>Max Power</span>
          <span style={{ fontSize: '1rem', fontWeight: 600 }}>
            {slot.maxPower} kW
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.9rem', color: '#666' }}>Power Efficiency</span>
          <span style={{ fontSize: '1rem', fontWeight: 600, color: powerEfficiency > 80 ? '#10b981' : powerEfficiency > 50 ? '#f59e0b' : '#ef4444' }}>
            {powerEfficiency.toFixed(1)}%
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.9rem', color: '#666' }}>Session Duration</span>
          <span style={{ fontSize: '1rem', fontWeight: 600 }}>
            {slot.sessionDuration} min
          </span>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.9rem', color: '#666' }}>Session Cost</span>
          <span style={{ fontSize: '1rem', fontWeight: 600, color: '#10b981' }}>
            ₹{slot.sessionCost.toFixed(2)}
          </span>
        </div>

        {/* Grid Cost Information */}
        <div style={{ 
          marginTop: '0.5rem', 
          padding: '0.75rem', 
          backgroundColor: '#f8f9fa', 
          borderRadius: 8,
          border: '1px solid #e5e7eb'
        }}>
          <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#666', marginBottom: '0.5rem' }}>
            Grid Power Costs:
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Normal (18kW @ ₹8/kWh)</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#ef4444' }}>
              ₹{normalCaseCost.toFixed(2)}
            </span>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Base (10kW @ ₹6/kWh)</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#10b981' }}>
              ₹{dynamicBaseCost.toFixed(2)}
            </span>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Additional ({additionalPower.toFixed(1)}kW @ ₹8/kWh)</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#f59e0b' }}>
              ₹{dynamicAdditionalCost.toFixed(2)}
            </span>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e5e7eb', paddingTop: '0.25rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Total Dynamic</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#007bff' }}>
              ₹{dynamicTotalCost.toFixed(2)}
            </span>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e5e7eb', paddingTop: '0.25rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Savings</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#10b981' }}>
              ₹{gridCostSavings.toFixed(2)}
            </span>
          </div>
        </div>
        
        {slot.vehicleId && (
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.9rem', color: '#666' }}>Vehicle ID</span>
            <span style={{ fontSize: '0.9rem', fontWeight: 600, color: '#666' }}>
              {slot.vehicleId}
            </span>
          </div>
        )}

        {/* Additional Station 1 Information */}
        {slot.occupied && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.9rem', color: '#666' }}>Battery Level</span>
              <span style={{ fontSize: '1rem', fontWeight: 600, color: slot.batteryLevel > 80 ? '#10b981' : slot.batteryLevel > 50 ? '#f59e0b' : '#ef4444' }}>
                {slot.batteryLevel}%
              </span>
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.9rem', color: '#666' }}>Charging Rate</span>
              <span style={{ fontSize: '1rem', fontWeight: 600, color: '#007bff' }}>
                {slot.chargingRate} kW
              </span>
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.9rem', color: '#666' }}>Est. Time Left</span>
              <span style={{ fontSize: '1rem', fontWeight: 600, color: '#f59e0b' }}>
                {slot.estimatedTime} min
              </span>
            </div>
          </>
        )}
      </div>

      {/* Interactive Controls */}
      <div style={{ marginTop: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        {/* Main Control Button */}
        <button
          onClick={() => onOverride(slot.id)}
          style={{
            width: '100%',
            padding: '0.75rem',
            backgroundColor: slot.status === 'charging' ? '#ef4444' : '#10b981',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            fontSize: '0.9rem',
            fontWeight: 600,
            cursor: 'pointer'
          }}
        >
          {slot.status === 'charging' ? '🛑 Stop Charging' : '⚡ Start Charging'}
        </button>

        {/* Power Adjustment Controls (only for charging slots) */}
        {slot.status === 'charging' && onPowerAdjustment && (
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              onClick={() => onPowerAdjustment(slot.id, Math.max(5, parseFloat(slot.currentPower) - 2))}
              style={{
                flex: 1,
                padding: '0.5rem',
                backgroundColor: '#f59e0b',
                color: '#fff',
                border: 'none',
                borderRadius: 6,
                fontSize: '0.8rem',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              ⬇️ -2 kW
            </button>
            <button
              onClick={() => onPowerAdjustment(slot.id, Math.min(20, parseFloat(slot.currentPower) + 2))}
              style={{
                flex: 1,
                padding: '0.5rem',
                backgroundColor: '#10b981',
                color: '#fff',
                border: 'none',
                borderRadius: 6,
                fontSize: '0.8rem',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              ⬆️ +2 kW
            </button>
          </div>
        )}

        {/* Emergency Stop Button */}
        {slot.status === 'charging' && onEmergencyStop && (
          <button
            onClick={() => onEmergencyStop(slot.id)}
            style={{
              width: '100%',
              padding: '0.5rem',
              backgroundColor: '#ef4444',
              color: '#fff',
              border: 'none',
              borderRadius: 6,
              fontSize: '0.8rem',
              fontWeight: 600,
              cursor: 'pointer'
            }}
          >
            🚨 Emergency Stop
          </button>
        )}
      </div>
    </div>
  );
};

const DynamicPowerStatus = ({ dynamicState, powerCalc }) => {
  return (
    <div style={{
      background: '#fff',
      borderRadius: 12,
      padding: '1.5rem',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      border: '2px solid #007bff'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <h3 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0 }}>Dynamic Power Status</h3>
        <div style={{
          padding: '0.5rem 1rem',
          borderRadius: 20,
          backgroundColor: powerCalc.activeSlots > 2 ? '#f59e0b' : '#10b981',
          color: '#fff',
          fontSize: '0.8rem',
          fontWeight: 600
        }}>
          {powerCalc.activeSlots > 2 ? '🔄 Dynamic Mode' : '⚡ Base Load'}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
            {powerCalc.activeSlots}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Active Slots</div>
        </div>
        
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>
            {dynamicState.baseLoad} kW
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Base Load</div>
        </div>
        
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#f59e0b' }}>
            {powerCalc.requiredGridPower} kW
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Grid Allocation</div>
        </div>
        
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#ef4444' }}>
            {powerCalc.additionalRequest} kW
          </div>
          <div style={{ fontSize: '0.8rem', color: '#666' }}>Additional Request</div>
        </div>
      </div>

      <div style={{ 
        marginTop: '1rem', 
        padding: '1rem', 
        backgroundColor: '#f8f9fa', 
        borderRadius: 8,
        border: '1px solid #e5e7eb'
      }}>
        <div style={{ fontSize: '0.9rem', fontWeight: 600, color: '#666', marginBottom: '0.5rem' }}>
          Current Status:
        </div>
        <div style={{ fontSize: '0.8rem', color: '#666' }}>
          {powerCalc.requestReason}
        </div>
      </div>
    </div>
  );
};

const DynamicComparisonPanel = ({ data, totalSavings, dynamicState, powerCalc }) => {
  const latestData = data[data.length - 1];
  const currentSavings = latestData?.dynamicSavings || 0;
  const efficiencyPercent = latestData ? 
    ((latestData.nonDynamicLoad - latestData.dynamicLoad) / latestData.nonDynamicLoad * 100) : 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            padding: '0.75rem',
            borderRadius: 8,
            backgroundColor: '#007bff',
            color: '#fff'
          }}>
            📊
          </div>
          <div>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>
              Dynamic vs Non-Dynamic Power Management
            </h3>
            <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>
              Real-time comparison and savings analysis
            </p>
          </div>
        </div>
        
        <div style={{
          padding: '0.5rem 1rem',
          borderRadius: 20,
          backgroundColor: '#10b981',
          color: '#fff',
          fontSize: '0.9rem',
          fontWeight: 600
        }}>
          🛡️ {efficiencyPercent.toFixed(1)}% More Efficient
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '1.5rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              padding: '0.5rem',
              borderRadius: 8,
              backgroundColor: '#10b981',
              color: '#fff'
            }}>
              📉
            </div>
            <div>
              <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>Power Saved Today</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>{totalSavings.powerSaved.toFixed(0)}</p>
              <p style={{ fontSize: '0.8rem', color: '#10b981', margin: 0 }}>kWh saved</p>
            </div>
          </div>
        </div>

        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '1.5rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              padding: '0.5rem',
              borderRadius: 8,
              backgroundColor: '#f59e0b',
              color: '#fff'
            }}>
              💰
            </div>
            <div>
              <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>Cost Savings</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>₹{totalSavings.costSaved.toFixed(0)}</p>
              <p style={{ fontSize: '0.8rem', color: '#f59e0b', margin: 0 }}>vs non-dynamic</p>
            </div>
          </div>
        </div>

        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '1.5rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              padding: '0.5rem',
              borderRadius: 8,
              backgroundColor: '#007bff',
              color: '#fff'
            }}>
              ⚡
            </div>
            <div>
              <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>Current Savings</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>{currentSavings.toFixed(0)}</p>
              <p style={{ fontSize: '0.8rem', color: '#007bff', margin: 0 }}>kW right now</p>
            </div>
          </div>
        </div>

        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '1.5rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              padding: '0.5rem',
              borderRadius: 8,
              backgroundColor: '#10b981',
              color: '#fff'
            }}>
              📈
            </div>
            <div>
              <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>Grid Efficiency</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>{totalSavings.efficiency.toFixed(1)}%</p>
              <p style={{ fontSize: '0.8rem', color: '#10b981', margin: 0 }}>utilization</p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid Cost Comparison */}
      <div style={{
        background: '#fff',
        borderRadius: 12,
        padding: '1.5rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginTop: '1rem'
      }}>
        <h4 style={{ fontSize: '1.1rem', fontWeight: 600, margin: 0, marginBottom: '1rem' }}>
          Grid Power Cost Comparison
        </h4>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
          <div style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#fef2f2', borderRadius: 8 }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#ef4444', marginBottom: '0.5rem' }}>
              Normal Case
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#ef4444' }}>
              90% of 80kW
            </div>
            <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
              72 kW minimum payment
            </div>
          </div>
          
          <div style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#f0fdf4', borderRadius: 8 }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#10b981', marginBottom: '0.5rem' }}>
              Base Load
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>
              40 kW Fixed
            </div>
            <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
<<<<<<< HEAD
              Supports up to 2 slots (20kW each)
=======
              Always paid for
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
            </div>
          </div>
          
          <div style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#fef3c7', borderRadius: 8 }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#f59e0b', marginBottom: '0.5rem' }}>
              Additional Power
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#f59e0b' }}>
<<<<<<< HEAD
              +20kW Per Slot
            </div>
            <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
              Auto-requested when 3+ slots active
=======
              As Needed
            </div>
            <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
              Only when 3+ slots active
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
            </div>
          </div>
          
          <div style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#dbeafe', borderRadius: 8 }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#007bff', marginBottom: '0.5rem' }}>
              Daily Savings
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
              ₹{totalSavings.costSaved.toFixed(0)}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
              Per day with dynamic
            </div>
          </div>
        </div>
      </div>

      {/* Comparison Chart */}
      <div style={{
        background: '#fff',
        borderRadius: 12,
        padding: '1.5rem',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <div style={{ marginBottom: '1rem' }}>
          <h4 style={{ fontSize: '1.2rem', fontWeight: 600, margin: 0, marginBottom: '0.5rem' }}>
            Power Consumption Comparison
          </h4>
          <p style={{ fontSize: '0.9rem', color: '#666', margin: 0 }}>
            Dynamic vs Non-Dynamic load over time
          </p>
        </div>
        
        <div style={{ height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="dynamicLoad" 
                stroke="#007bff" 
                strokeWidth={3}
                dot={false}
                name="Dynamic Load"
              />
              <Line 
                type="monotone" 
                dataKey="nonDynamicLoad" 
                stroke="#ef4444" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                name="Non-Dynamic Load"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default function PowerManagementPanel({ station }) {
  const [powerData, setPowerData] = useState(generatePowerData());
  const [gridRequests, setGridRequests] = useState(generateGridRequests());
  const [slots, setSlots] = useState([]);
  const [selectedView, setSelectedView] = useState('overview');
  const [connectionStatus, setConnectionStatus] = useState("Connecting...");
  const [dynamicPowerState, setDynamicPowerState] = useState({
<<<<<<< HEAD
    baseLoad: 40, // Fixed base load from grid (kW) - updated to 40kW for 2 slots
=======
    baseLoad: 20, // Fixed base load from grid (kW) - updated to match new logic
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
    currentGridAllocation: 0, // Current power allocated from grid
    maxGridCapacity: 80, // Maximum grid capacity
    activeSlots: 0,
    dynamicRequests: []
  });
  const [realTimeData, setRealTimeData] = useState({});
  const [notification, setNotification] = useState(null);

  // Fetch real-time data for Station 1
  useEffect(() => {
    if (station === "station1") {
      setConnectionStatus("Connecting...");
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          console.log("Power Management - Received data:", data);
          console.log("Raw slots data from Firebase:", data.slots);
          setRealTimeData(data);
          setConnectionStatus("Connected");
          
          // Process slots data
<<<<<<< HEAD
          // Convert slots object to array if it's an object
          let slotsData = [];
          if (data.slots) {
            if (Array.isArray(data.slots)) {
              slotsData = data.slots;
            } else if (typeof data.slots === 'object') {
              // Convert object format {0: {status: "charging"}, 1: {status: "available"}} to array
              slotsData = Object.keys(data.slots).map(key => ({
                ...data.slots[key],
                slotNumber: parseInt(key)
              }));
            }
          }
          console.log("Raw slots data:", slotsData);
          console.log("Converted slots data:", slotsData);
=======
          const slotsData = data.slots || [];
          console.log("Raw slots data:", slotsData);
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
          
          const processedSlots = slotsData.map((slot, index) => {
            // Safety check for slot data
            if (!slot || typeof slot !== 'object') {
              console.log(`Invalid slot data at index ${index}:`, slot);
              return {
                id: `slot${index + 1}`,
                status: 'available',
                currentPower: 0,
                maxPower: 20,
                sessionDuration: 0,
                sessionCost: 0,
                vehicleId: null,
                occupied: false,
                chargingRate: 0,
                batteryLevel: 0,
                estimatedTime: 0
              };
            }
            
            console.log(`Processing slot ${index + 1}:`, slot);
<<<<<<< HEAD
            // Determine if slot is occupied based on status (charging = occupied)
            const isOccupied = slot.status === 'charging';
=======
            const isOccupied = Boolean(slot.occupied);
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
            console.log(`Slot ${index + 1} occupied:`, isOccupied);
            
            return {
              id: `slot${index + 1}`,
              status: isOccupied ? 'charging' : 'available',
              currentPower: isOccupied ? (15 + Math.random() * 5).toFixed(1) : 0, // 15-20 kW when occupied
              maxPower: 20,
              sessionDuration: isOccupied ? Math.floor(Math.random() * 60) + 5 : 0, // 5-65 minutes
              sessionCost: isOccupied ? (parseFloat(slot.currentPower || 0) * 0.12 * (slot.sessionDuration || 0) / 60).toFixed(2) : 0,
              vehicleId: isOccupied ? `KA-01-${String.fromCharCode(65 + index)}${String.fromCharCode(65 + index)}-${Math.floor(Math.random() * 9999).toString().padStart(4, '0')}` : null,
              occupied: isOccupied,
              chargingRate: isOccupied ? (15 + Math.random() * 5).toFixed(1) : 0,
              batteryLevel: isOccupied ? Math.floor(Math.random() * 40) + 60 : 0, // 60-100%
              estimatedTime: isOccupied ? Math.floor(Math.random() * 30) + 10 : 0 // 10-40 minutes
            };
          });
          
          setSlots(processedSlots);
          
          // Calculate dynamic power based on real slot data
          const powerCalc = calculateDynamicPower(processedSlots);
          console.log("Real-time power calculation:", powerCalc);
          console.log("Processed slots data:", processedSlots);
          
          if (powerCalc) {
            checkAndRequestGridPower(processedSlots, powerCalc);
          }
          
        } else {
          console.log("No data received from Firebase");
          setConnectionStatus("No Data");
          setSlots([]);
          
          // Initialize with empty slots for Station 1
          if (station === "station1") {
            const emptySlots = Array.from({ length: 6 }, (_, index) => ({
              id: `slot${index + 1}`,
              status: 'available',
              currentPower: 0,
              maxPower: 20,
              sessionDuration: 0,
              sessionCost: 0,
              vehicleId: null,
              occupied: false,
              chargingRate: 0,
              batteryLevel: 0,
              estimatedTime: 0
            }));
            setSlots(emptySlots);
          }
        }
      }, (error) => {
        setConnectionStatus("Error: " + error.message);
      });
      
      return () => unsubscribe();
    } else {
      // Use demo data for other stations
      setConnectionStatus("Demo Mode");
      setSlots(generateChargingSlots());
    }
  }, [station]);

  // Dynamic Power Management Logic
  const calculateDynamicPower = (currentSlots) => {
    // Safety check for undefined or empty slots
    if (!currentSlots || !Array.isArray(currentSlots)) {
      console.log("calculateDynamicPower: Invalid slots data", currentSlots);
      return {
        activeSlots: 0,
        totalPowerNeeded: 0,
<<<<<<< HEAD
        baseLoad: 40, // Updated to 40kW base load
=======
        baseLoad: 20,
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
        requiredGridPower: 0,
        additionalRequest: 0,
        requestReason: 'No slots data available'
      };
    }
    
    const activeSlots = currentSlots.filter(slot => slot.occupied === true).length;
    console.log(`Active slots (occupied): ${activeSlots}`);
    console.log("Slots data for power calculation:", currentSlots.map(s => ({ id: s.id, occupied: s.occupied, status: s.status })));
    
    let totalPowerNeeded = 0;
    let requiredGridPower = 0;
    let additionalRequest = 0;
    let requestReason = '';
    
<<<<<<< HEAD
    // Each slot requires 20kW when active
    // Base grid supply is 40kW (enough for 2 slots)
    // When a third slot activates, request additional 20kW
    
=======
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
    if (activeSlots === 0) {
      // 0 slots occupied = 0 kW
      totalPowerNeeded = 0;
      requiredGridPower = 0;
      requestReason = 'No slots occupied - 0 kW consumption';
    } else if (activeSlots === 1) {
<<<<<<< HEAD
      // 1 slot occupied = 20 kW (within base load)
      totalPowerNeeded = 20;
      requiredGridPower = 40; // Still maintain base load of 40kW
      requestReason = '1 slot occupied - 20 kW consumption (within 40 kW base load)';
    } else if (activeSlots === 2) {
      // 2 slots occupied = 40 kW (exactly base load)
      totalPowerNeeded = 40;
      requiredGridPower = 40;
      requestReason = '2 slots occupied - 40 kW consumption (matches 40 kW base load)';
    } else if (activeSlots === 3) {
      // 3 slots occupied = 60 kW (base load + additional 20kW)
      totalPowerNeeded = 60;
      requiredGridPower = 60;
      additionalRequest = 20; // Request additional 20kW beyond base load
      requestReason = '3 slots occupied - 60 kW needed (40 kW base + 20 kW additional)';
    } else {
      // 4 slots occupied = 80 kW (base load + additional 40kW)
      totalPowerNeeded = 80;
      requiredGridPower = 80;
      additionalRequest = 40; // Request additional 40kW beyond base load
      requestReason = '4 slots occupied - 80 kW needed (40 kW base + 40 kW additional)';
=======
      // 1 slot occupied = 20 kW
      totalPowerNeeded = 20;
      requiredGridPower = 20;
      requestReason = '1 slot occupied - 20 kW consumption';
    } else if (activeSlots === 2) {
      // 2 slots occupied = 20 kW base load + 20 kW from grid = 40 kW total
      totalPowerNeeded = 40;
      requiredGridPower = 40;
      requestReason = '2 slots occupied - 20 kW base + 20 kW grid = 40 kW total';
    } else {
      // 3+ slots occupied = 20 kW base load + additional power from grid
      totalPowerNeeded = activeSlots * 20;
      requiredGridPower = 20 + (activeSlots - 1) * 20; // 20 kW base + additional for extra slots
      additionalRequest = (activeSlots - 1) * 20; // Additional power needed beyond base
      requestReason = `${activeSlots} slots occupied - 20 kW base + ${additionalRequest} kW from grid = ${totalPowerNeeded} kW total`;
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
    }
    
    console.log(`Power calculation: ${activeSlots} slots = ${totalPowerNeeded} kW needed, ${requiredGridPower} kW from grid`);
    
    return {
      activeSlots,
      totalPowerNeeded,
<<<<<<< HEAD
      baseLoad: 40, // Updated to 40kW base load
=======
      baseLoad: 20,
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
      requiredGridPower,
      additionalRequest,
      requestReason
    };
  };

  // Auto Grid Request Logic
  const checkAndRequestGridPower = (currentSlots, powerCalc) => {
    // Safety check for undefined parameters
    if (!currentSlots || !powerCalc) {
      console.log("checkAndRequestGridPower: Missing parameters", { currentSlots, powerCalc });
      return;
    }
    
    const currentAllocation = dynamicPowerState.currentGridAllocation;
    
    // Check if we need to request more power
    if (powerCalc.requiredGridPower > currentAllocation && powerCalc.additionalRequest > 0) {
      const newRequest = {
        id: `AUTO-${Date.now()}`,
        type: 'power_increase',
        requestedPower: powerCalc.additionalRequest,
        status: 'pending',
        timestamp: new Date().toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit'
        }),
        reason: powerCalc.requestReason
      };
      
      setGridRequests(prev => [newRequest, ...prev.slice(0, 9)]);
      
      // Auto-approve after 2 seconds (simulating grid response)
      setTimeout(() => {
        setGridRequests(prev => prev.map(req => 
          req.id === newRequest.id 
            ? { ...req, status: 'approved' }
            : req
        ));
        
        // Update dynamic power state
        setDynamicPowerState(prev => ({
          ...prev,
          currentGridAllocation: powerCalc.requiredGridPower,
          activeSlots: powerCalc.activeSlots,
          dynamicRequests: [...prev.dynamicRequests, newRequest]
        }));
      }, 2000);
    }
    
    // Check if we can reduce power allocation
    if (powerCalc.requiredGridPower < currentAllocation && powerCalc.activeSlots <= 1) {
      const reductionRequest = {
        id: `REDUCE-${Date.now()}`,
        type: 'power_decrease',
        requestedPower: currentAllocation - powerCalc.requiredGridPower,
        status: 'pending',
        timestamp: new Date().toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit'
        }),
        reason: `Reducing to base load (${powerCalc.activeSlots} slots active)`
      };
      
      setGridRequests(prev => [reductionRequest, ...prev.slice(0, 9)]);
      
      // Auto-approve reduction
      setTimeout(() => {
        setGridRequests(prev => prev.map(req => 
          req.id === reductionRequest.id 
            ? { ...req, status: 'approved' }
            : req
        ));
        
        setDynamicPowerState(prev => ({
          ...prev,
          currentGridAllocation: powerCalc.requiredGridPower,
          activeSlots: powerCalc.activeSlots
        }));
      }, 1000);
    }
  };

  // Calculate total savings based on current power state
  const powerCalc = calculateDynamicPower(slots);
<<<<<<< HEAD
  const baseLoad = 40; // 40kW base load for 2 slots
=======
  const baseLoad = 40;
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
  const additionalPower = Math.max(0, powerCalc.requiredGridPower - baseLoad);
  
  // Daily calculations
  const normalCaseDaily = 80 * 0.9 * 24; // 1728 kWh daily
  const normalCaseCost = normalCaseDaily * 8; // ₹13,824 daily
  
  const baseLoadDaily = baseLoad * 24; // 960 kWh daily
  const additionalPowerDaily = additionalPower * 24; // Additional kWh daily
  const dynamicBaseCost = baseLoadDaily * 6; // ₹5,760 daily
  const dynamicAdditionalCost = additionalPowerDaily * 8; // Additional cost daily
  const dynamicTotalCost = dynamicBaseCost + dynamicAdditionalCost;
  
  const totalSavings = {
    powerSaved: normalCaseDaily - (baseLoadDaily + additionalPowerDaily),
    costSaved: normalCaseCost - dynamicTotalCost,
    efficiency: ((normalCaseDaily - (baseLoadDaily + additionalPowerDaily)) / normalCaseDaily) * 100
  };

  const totalPower = slots.reduce((sum, slot) => sum + slot.currentPower, 0);
  const maxPower = slots.reduce((sum, slot) => sum + slot.maxPower, 0);
  const activeSlots = slots.filter(slot => slot.status === 'charging' || slot.status === 'active').length;
  const gridLimit = 80; // Updated to match 4 slots × 20 kW

  // Fetch live data from Firebase for Station 1
  useEffect(() => {
    if (station === "station1") {
      setConnectionStatus("Connecting...");
      
      // Fetch current status from Firebase
      const statusRef = ref(db, "charging_station/current_status");
      const unsubscribe = onValue(statusRef, (snapshot) => {
        const data = snapshot.val();
        if (!data) { 
          setConnectionStatus("No Data"); 
          return; 
        }
        
        setConnectionStatus("Connected");
        
        // Extract slot data from Firebase
        const firebaseSlots = data.slots || [];
        const mappedSlots = firebaseSlots.map((slot, index) => ({
          id: `slot${index + 1}`,
          status: slot.status || 'available',
          currentPower: slot.current_power || slot.power || 0,
          maxPower: slot.max_power || 20, // Assuming 20 kW per slot
          sessionDuration: slot.session_duration || slot.duration || 0,
          sessionCost: slot.session_cost || slot.cost || 0,
          vehicleId: slot.vehicle_id || slot.vehicleId || null
        }));
        
        setSlots(mappedSlots);
        
        // Calculate dynamic power based on real data
        const powerCalc = calculateDynamicPower(mappedSlots);
        
        // Update power data with real values
        setPowerData(prev => {
          const newData = [...prev.slice(1)];
          const now = new Date();
          
          const dynamicLoad = powerCalc.requiredGridPower;
          const nonDynamicLoad = 80; // Always pay for 80 kW in normal case
          const dynamicSavings = nonDynamicLoad - dynamicLoad;
          const gridAllocated = powerCalc.requiredGridPower;
          
          newData.push({
            time: now.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit'
            }),
            dynamicLoad: Math.round(dynamicLoad),
            nonDynamicLoad: Math.round(nonDynamicLoad),
            dynamicSavings: Math.round(dynamicSavings),
            gridAllocated: Math.round(gridAllocated),
            gridLimit: 80
          });
          return newData;
        });
        
        // Check and request grid power based on real slot data
        checkAndRequestGridPower(mappedSlots);
        
      }, (error) => {
        setConnectionStatus("Error: " + error.message);
      });
      
      return () => unsubscribe();
    } else {
      // Use mock data for other stations
      const interval = setInterval(() => {
        // Update power data based on dynamic allocation
        setPowerData(prev => {
          const newData = [...prev.slice(1)];
          const now = new Date();
          const powerCalc = calculateDynamicPower(slots);
          
          const dynamicLoad = powerCalc.requiredGridPower;
          const nonDynamicLoad = 80; // Always pay for 80 kW in normal case
          const dynamicSavings = nonDynamicLoad - dynamicLoad;
          const gridAllocated = powerCalc.requiredGridPower;
          
          newData.push({
            time: now.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit'
            }),
            dynamicLoad: Math.round(dynamicLoad),
            nonDynamicLoad: Math.round(nonDynamicLoad),
            dynamicSavings: Math.round(dynamicSavings),
            gridAllocated: Math.round(gridAllocated),
            gridLimit: 80
          });
          return newData;
        });

        // Check and request grid power based on slot changes
        checkAndRequestGridPower(slots);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [station, dynamicPowerState.currentGridAllocation]);

  // Auto-clear notifications after 5 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Interactive slot control functions
  const handleSlotOverride = async (slotId) => {
    if (station === "station1") {
      try {
        console.log(`Updating slot ${slotId} in Firebase...`);
        
        // Find the slot index
        const slotIndex = parseInt(slotId.replace('slot', '')) - 1;
        const currentSlot = slots.find(s => s.id === slotId);
        
        if (!currentSlot) {
          console.error(`Slot ${slotId} not found`);
          return;
        }
        
        // Toggle slot status
        const newStatus = currentSlot.status === 'charging' ? 'available' : 'charging';
        const newOccupied = newStatus === 'charging';
        
        // Update Firebase
        const statusRef = ref(db, "charging_station/current_status");
        const slotsRef = ref(db, `charging_station/current_status/slots/${slotIndex}`);
        
        await update(slotsRef, {
          occupied: newOccupied,
          lastUpdated: Date.now(),
          status: newStatus,
          currentPower: newOccupied ? (15 + Math.random() * 5).toFixed(1) : 0,
          sessionStart: newOccupied ? Date.now() : null,
          vehicleId: newOccupied ? `KA-01-${String.fromCharCode(65 + slotIndex)}${String.fromCharCode(65 + slotIndex)}-${Math.floor(Math.random() * 9999).toString().padStart(4, '0')}` : null
        });
        
        console.log(`Successfully updated slot ${slotId} to ${newStatus}`);
        setNotification({
          type: 'success',
          message: `Slot ${slotId} ${newStatus === 'charging' ? 'started' : 'stopped'} charging`,
          timestamp: Date.now()
        });
        
      } catch (error) {
        console.error(`Error updating slot ${slotId}:`, error);
        setNotification({
          type: 'error',
          message: `Failed to update slot ${slotId}: ${error.message}`,
          timestamp: Date.now()
        });
      }
    } else {
      setSlots(prev => prev.map(slot => 
        slot.id === slotId 
          ? { ...slot, status: slot.status === 'charging' ? 'available' : 'charging' }
          : slot
      ));
    }
  };

  const handleSlotPowerAdjustment = async (slotId, newPower) => {
    if (station === "station1") {
      try {
        const slotIndex = parseInt(slotId.replace('slot', '')) - 1;
        const slotsRef = ref(db, `charging_station/current_status/slots/${slotIndex}`);
        
        await update(slotsRef, {
          currentPower: newPower,
          lastUpdated: Date.now()
        });
        
        console.log(`Updated slot ${slotId} power to ${newPower} kW`);
        setNotification({
          type: 'success',
          message: `Slot ${slotId} power adjusted to ${newPower} kW`,
          timestamp: Date.now()
        });
        
      } catch (error) {
        console.error(`Error updating slot ${slotId} power:`, error);
        setNotification({
          type: 'error',
          message: `Failed to adjust slot ${slotId} power: ${error.message}`,
          timestamp: Date.now()
        });
      }
    }
  };

  const handleEmergencyStop = async (slotId) => {
    if (station === "station1") {
      try {
        const slotIndex = parseInt(slotId.replace('slot', '')) - 1;
        const slotsRef = ref(db, `charging_station/current_status/slots/${slotIndex}`);
        
        await update(slotsRef, {
          occupied: false,
          status: 'emergency_stop',
          currentPower: 0,
          lastUpdated: Date.now(),
          emergencyStopTime: Date.now()
        });
        
        console.log(`Emergency stop activated for slot ${slotId}`);
        setNotification({
          type: 'warning',
          message: `🚨 Emergency stop activated for slot ${slotId}`,
          timestamp: Date.now()
        });
        
      } catch (error) {
        console.error(`Error activating emergency stop for slot ${slotId}:`, error);
        setNotification({
          type: 'error',
          message: `Failed to activate emergency stop for slot ${slotId}: ${error.message}`,
          timestamp: Date.now()
        });
      }
    }
  };

  const getSlotStatusSummary = () => {
    const totalSlots = slots.length;
<<<<<<< HEAD
    // Count slots with status 'charging' as occupied
    const occupiedSlots = slots.filter(slot => slot.status === 'charging' || slot.occupied === true).length;
=======
    // Use the occupied field directly from the processed slots data
    const occupiedSlots = slots.filter(slot => slot.occupied === true).length;
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
    const availableSlots = totalSlots - occupiedSlots;
    
    console.log("Slot status summary:", {
      totalSlots,
      occupiedSlots,
      availableSlots,
      slots: slots.map(s => ({ id: s.id, occupied: s.occupied, status: s.status }))
    });
    
    // Calculate power based on new logic
    let totalPowerConsumption = 0;
    if (occupiedSlots === 0) {
      totalPowerConsumption = 0;
    } else if (occupiedSlots === 1) {
      totalPowerConsumption = 20;
    } else if (occupiedSlots === 2) {
      totalPowerConsumption = 40; // 20 kW base + 20 kW from grid
    } else {
      totalPowerConsumption = 20 + (occupiedSlots - 1) * 20; // 20 kW base + additional from grid
    }
    
    return {
      totalSlots,
      occupiedSlots,
      availableSlots,
      totalPowerConsumption: totalPowerConsumption.toFixed(1)
    };
  };

  const handleGridRequest = (power, type) => {
    const newRequest = {
      id: `REQ-${Date.now()}`,
      type: type,
      requestedPower: power,
      status: 'pending',
      timestamp: new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setGridRequests(prev => [newRequest, ...prev]);
  };

  return (
    <div style={{ padding: '1rem' }}>
      {/* Header */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        marginBottom: '2rem',
        padding: '1rem',
        background: '#fff',
        borderRadius: 12,
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            padding: '0.75rem',
            borderRadius: 8,
            backgroundColor: '#007bff',
            color: '#fff',
            fontSize: '1.5rem'
          }}>
            ⚡
          </div>
          <div>
            <h2 style={{ fontSize: '1.8rem', fontWeight: 'bold', margin: 0 }}>
              DYNAMIC POWER MANAGEMENT
            </h2>
            <p style={{ fontSize: '1rem', color: '#666', margin: 0 }}>
              EV Charging Station Power Management
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <div style={{
              padding: '0.5rem 1rem',
              borderRadius: 20,
              backgroundColor: '#10b981',
              color: '#fff',
              fontSize: '0.9rem',
              fontWeight: 600
            }}>
              👥 {activeSlots} Active
            </div>
                          <div style={{ 
                padding: '0.5rem 1rem',
                borderRadius: 20,
                backgroundColor: totalPower > gridLimit * 0.85 ? '#f59e0b' : '#10b981',
                color: '#fff',
                fontSize: '0.9rem',
                fontWeight: 600
              }}>
                ⚡ {totalPower.toFixed(0)} kW
              </div>
              {station === "station1" && (
                <div style={{ 
                  padding: '0.5rem 1rem',
                  borderRadius: 20,
                  backgroundColor: '#007bff',
                  color: '#fff',
                  fontSize: '0.9rem',
                  fontWeight: 600
                }}>
                  🔌 {getSlotStatusSummary().occupiedSlots} Occupied
                </div>
              )}
            {station === "station1" && (
              <div style={{
                padding: '0.5rem 1rem',
                borderRadius: 20,
                backgroundColor: connectionStatus === "Connected" ? '#10b981' : connectionStatus === "Error" ? '#ef4444' : '#f59e0b',
                color: '#fff',
                fontSize: '0.9rem',
                fontWeight: 600
              }}>
                {connectionStatus === "Connected" ? "🟢 Live Data" : connectionStatus === "Error" ? "🔴 Error" : "🟡 Connecting"}
              </div>
            )}
          </div>

          <div style={{ display: 'flex', background: '#f3f4f6', borderRadius: 8, padding: '0.25rem' }}>
            <button
              onClick={() => setSelectedView('overview')}
              style={{
                padding: '0.5rem 1rem',
                borderRadius: 6,
                border: 'none',
                background: selectedView === 'overview' ? '#007bff' : 'transparent',
                color: selectedView === 'overview' ? '#fff' : '#666',
                fontSize: '0.9rem',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              Overview
            </button>
            <button
              onClick={() => setSelectedView('analytics')}
              style={{
                padding: '0.5rem 1rem',
                borderRadius: 6,
                border: 'none',
                background: selectedView === 'analytics' ? '#007bff' : 'transparent',
                color: selectedView === 'analytics' ? '#fff' : '#666',
                fontSize: '0.9rem',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              📊 Analytics
            </button>
            <button
              onClick={() => setSelectedView('grid')}
              style={{
                padding: '0.5rem 1rem',
                borderRadius: 6,
                border: 'none',
                background: selectedView === 'grid' ? '#007bff' : 'transparent',
                color: selectedView === 'grid' ? '#fff' : '#666',
                fontSize: '0.9rem',
                fontWeight: 600,
                cursor: 'pointer'
              }}
            >
              ⚙️ Grid
            </button>
          </div>
        </div>
      </div>

      {/* Notification Display */}
      {notification && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          zIndex: 1000,
          padding: '1rem',
          borderRadius: '8px',
          backgroundColor: notification.type === 'success' ? '#10b981' : 
                         notification.type === 'error' ? '#ef4444' : '#f59e0b',
          color: '#fff',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
          maxWidth: '300px',
          animation: 'slideIn 0.3s ease-out'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '1.2rem' }}>
              {notification.type === 'success' ? '✅' : 
               notification.type === 'error' ? '❌' : '⚠️'}
            </span>
            <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>
              {notification.message}
            </span>
          </div>
        </div>
      )}

      {/* Power Calculation Explanation for Station 1 */}
      {station === "station1" && (
        <div style={{ 
          marginBottom: '2rem',
          padding: '1.5rem',
          background: '#e8f5e8',
          borderRadius: '12px',
          border: '2px solid #10b981'
        }}>
          <h4 style={{ margin: '0 0 1rem 0', color: '#10b981', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            ⚡ Real-time Power Calculation Logic
          </h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
            <div style={{ 
              padding: '1rem', 
              background: '#fff', 
              borderRadius: '8px', 
              border: '1px solid #e9ecef',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981' }}>
                0 Slots
              </div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>0 kW Consumption</div>
              <div style={{ fontSize: '0.8rem', color: '#999' }}>No power needed</div>
            </div>
            <div style={{ 
              padding: '1rem', 
              background: '#fff', 
              borderRadius: '8px', 
              border: '1px solid #e9ecef',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
<<<<<<< HEAD
                1-2 Slots
              </div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>40 kW Base Load</div>
              <div style={{ fontSize: '0.8rem', color: '#999' }}>Within base grid supply</div>
=======
                1 Slot
              </div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>20 kW Consumption</div>
              <div style={{ fontSize: '0.8rem', color: '#999' }}>Base load only</div>
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
            </div>
            <div style={{ 
              padding: '1rem', 
              background: '#fff', 
              borderRadius: '8px', 
              border: '1px solid #e9ecef',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#f59e0b' }}>
<<<<<<< HEAD
                3+ Slots
              </div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>40 kW Base + 20 kW</div>
              <div style={{ fontSize: '0.8rem', color: '#999' }}>Auto-request additional power</div>
            </div>
          </div>
          <div style={{ marginTop: '1rem', padding: '0.75rem', backgroundColor: '#f0fdf4', borderRadius: '8px', fontSize: '0.9rem', color: '#10b981' }}>
            <strong>Power Management Logic:</strong> Base grid supply is 40kW (enough for 2 slots). When a third slot activates, system automatically requests an additional 20kW from the grid.
          </div>
=======
                2+ Slots
              </div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>20 kW Base + Grid</div>
              <div style={{ fontSize: '0.8rem', color: '#999' }}>Additional power from grid</div>
            </div>
          </div>
>>>>>>> d14e7b8d094e807a8e89f7a0621a99bf749c4738
        </div>
      )}

      {/* Slot Status Summary for Station 1 */}
      {station === "station1" && (
        <div style={{ 
          marginBottom: '2rem',
          padding: '1.5rem',
          background: '#f8f9fa',
          borderRadius: '12px',
          border: '2px solid #007bff'
        }}>
          <h3 style={{ margin: '0 0 1rem 0', color: '#007bff', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            🔌 Interactive Slot Management - Station 1
          </h3>
          {getSlotStatusSummary().totalSlots > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div style={{ 
                padding: '1rem', 
                background: '#fff', 
                borderRadius: '8px', 
                border: '1px solid #e9ecef',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#007bff' }}>
                  {getSlotStatusSummary().totalSlots}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>Total Slots</div>
              </div>
              <div style={{ 
                padding: '1rem', 
                background: '#fff', 
                borderRadius: '8px', 
                border: '1px solid #e9ecef',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#10b981' }}>
                  {getSlotStatusSummary().occupiedSlots}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>Occupied</div>
              </div>
              <div style={{ 
                padding: '1rem', 
                background: '#fff', 
                borderRadius: '8px', 
                border: '1px solid #e9ecef',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#f59e0b' }}>
                  {getSlotStatusSummary().availableSlots}
                </div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>Available</div>
              </div>
              <div style={{ 
                padding: '1rem', 
                background: '#fff', 
                borderRadius: '8px', 
                border: '1px solid #e9ecef',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#ef4444' }}>
                  {getSlotStatusSummary().totalPowerConsumption} kW
                </div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>Total Power</div>
              </div>
            </div>
          ) : (
            <div style={{ 
              padding: '1rem', 
              background: '#fff', 
              borderRadius: '8px', 
              border: '1px solid #e9ecef',
              textAlign: 'center',
              color: '#666'
            }}>
              <div style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>📡</div>
              <div>Waiting for slot data from Firebase...</div>
              <div style={{ fontSize: '0.8rem', marginTop: '0.5rem' }}>
                Connection Status: {connectionStatus}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Content */}
      {selectedView === 'overview' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Top Row - Power Gauge and Grid Interaction */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
            <PowerGauge 
              currentPower={totalPower} 
              maxPower={maxPower} 
              gridLimit={gridLimit} 
              title="Total Station Power" 
            />
            <GridInteractionWidget 
              requests={gridRequests} 
              currentAllocation={dynamicPowerState.currentGridAllocation} 
              maxAllocation={dynamicPowerState.maxGridCapacity} 
              onNewRequest={handleGridRequest} 
            />
          </div>

          {/* Dynamic Power Status */}
          <DynamicPowerStatus 
            dynamicState={dynamicPowerState}
            powerCalc={calculateDynamicPower(slots)}
          />

          {/* Dynamic vs Non-Dynamic Comparison */}
          <DynamicComparisonPanel 
            data={powerData} 
            totalSavings={totalSavings}
            dynamicState={dynamicPowerState}
            powerCalc={calculateDynamicPower(slots)}
          />

          {/* Charging Slots Grid */}
          <div>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '1rem' }}>
              Charging Slots Status
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
              {slots.map(slot => (
                <ChargingSlotCard 
                  key={slot.id} 
                  slot={slot} 
                  onOverride={handleSlotOverride}
                  onPowerAdjustment={handleSlotPowerAdjustment}
                  onEmergencyStop={handleEmergencyStop}
                />
              ))}
            </div>
            
            {/* Debug Info for Station 1 */}
            {station === "station1" && (
              <div style={{
                marginTop: '2rem',
                padding: '1rem',
                backgroundColor: '#f8f9fa',
                borderRadius: 8,
                border: '1px solid #e5e7eb'
              }}>
                <h4 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '0.5rem' }}>
                  Real-time Slot Status Debug (Station 1)
                </h4>
                <div style={{ fontSize: '0.8rem', color: '#666' }}>
                  <div><strong>Connection Status:</strong> {connectionStatus}</div>
                  <div><strong>Total Slots:</strong> {getSlotStatusSummary().totalSlots}</div>
                  <div><strong>Occupied Slots:</strong> {getSlotStatusSummary().occupiedSlots}</div>
                  <div><strong>Available Slots:</strong> {getSlotStatusSummary().availableSlots}</div>
                  <div><strong>Total Power Consumption:</strong> {getSlotStatusSummary().totalPowerConsumption} kW</div>
                  <div><strong>Active Slots:</strong> {activeSlots}</div>
                  <div><strong>Total Power:</strong> {totalPower.toFixed(2)} kW</div>
                  <div style={{ marginTop: '0.5rem', padding: '0.5rem', backgroundColor: '#fff', borderRadius: '4px' }}>
                    <strong>Individual Slot Status:</strong>
                    {slots.map((slot, index) => (
                      <div key={slot.id} style={{ marginLeft: '1rem', marginTop: '0.25rem' }}>
                        {slot.id}: occupied={slot.occupied ? 'true' : 'false'}, status={slot.status}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {selectedView === 'analytics' && (
        <div style={{
          background: '#fff',
          borderRadius: 12,
          padding: '2rem',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '1rem' }}>
            Power Analytics
          </h3>
          <p style={{ color: '#666', marginBottom: '2rem' }}>
            Detailed power consumption analytics and efficiency metrics
          </p>
          
          <div style={{ height: 400 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={powerData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="dynamicSavings" 
                  stroke="#10b981" 
                  fill="#10b981"
                  fillOpacity={0.3}
                  strokeWidth={2}
                  name="Power Saved"
                />
                <Area 
                  type="monotone" 
                  dataKey="gridAllocated" 
                  stroke="#007bff" 
                  fill="#007bff"
                  fillOpacity={0.3}
                  strokeWidth={2}
                  name="Grid Allocated"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {selectedView === 'grid' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
          <GridInteractionWidget 
            requests={gridRequests} 
            currentAllocation={gridLimit} 
            maxAllocation={1000} 
            onNewRequest={handleGridRequest} 
          />
          <div style={{
            background: '#fff',
            borderRadius: 12,
            padding: '1.5rem',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 600, marginBottom: '1rem' }}>
              Grid Status
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Current Allocation</span>
                <span style={{ fontWeight: 600 }}>{gridLimit} kW</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Max Capacity</span>
                <span style={{ fontWeight: 600 }}>1000 kW</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Utilization</span>
                <span style={{ fontWeight: 600, color: '#10b981' }}>80%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
