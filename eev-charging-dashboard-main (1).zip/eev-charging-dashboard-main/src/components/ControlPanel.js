import React, { useState } from "react";
import { ref, set } from "firebase/database";
import { db } from "../firebase";

export default function ControlPanel() {
  const [lastCommand, setLastCommand] = useState("");
  const [commandStatus, setCommandStatus] = useState("");

  const sendCmd = async (cmd) => {
    console.log("ControlPanel: Sending command:", cmd);
    setCommandStatus("Sending...");
    
    try {
      await set(ref(db, "ev_station/commands"), { 
        action: cmd, 
        timestamp: Date.now() 
      });
      console.log("ControlPanel: Command sent successfully");
      setLastCommand(cmd);
      setCommandStatus("Sent successfully");
      
      // Clear status after 2 seconds
      setTimeout(() => setCommandStatus(""), 2000);
    } catch (error) {
      console.error("ControlPanel: Error sending command:", error);
      setCommandStatus("Error: " + error.message);
    }
  };

  return (
    <div>
      <h2>Controls</h2>
      
      {commandStatus && (
        <div style={{ 
          padding: '0.5rem', 
          marginBottom: '1rem', 
          backgroundColor: commandStatus.includes('Error') ? '#ffe8e8' : '#e8f5e8',
          borderRadius: '4px',
          border: '1px solid #ddd'
        }}>
          <strong>Status:</strong> {commandStatus}
        </div>
      )}
      
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
        <button onClick={() => sendCmd("RELAY_ON")}>Relay ON</button>
        <button onClick={() => sendCmd("RELAY_OFF")}>Relay OFF</button>
        <button onClick={() => sendCmd("RESET_TRIP")}>Reset Trip</button>
      </div>
      
      {lastCommand && (
        <div style={{ padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
          <h3>Last Command</h3>
          <p>Command: {lastCommand}</p>
          <p>Time: {new Date().toLocaleString()}</p>
        </div>
      )}
    </div>
  );
} 