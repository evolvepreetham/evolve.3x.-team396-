import React, { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceDot } from "recharts";

const PARAMS = [
  { key: "ac.voltage", label: "AC Voltage (V)" },
  { key: "ac.current", label: "AC Current (A)" },
  { key: "ac.power", label: "AC Power (W)" },
  { key: "ac.energy", label: "AC Energy (kWh)" },
  { key: "ac.frequency", label: "AC Frequency (Hz)" },
  { key: "ac.power_factor", label: "AC Power Factor" },
  { key: "dc.voltage", label: "DC Voltage (V)" },
  { key: "dc.current", label: "DC Current (A)" },
  { key: "dc.power", label: "DC Power (W)" },
  { key: "environment.temperature", label: "Temperature (°C)" },
  { key: "environment.humidity", label: "Humidity (%)" }
];

const AC_PARAMS = [
  { key: "voltage", label: "Voltage (V)", color: "#8884d8" },
  { key: "current", label: "Current (A)", color: "#82ca9d" },
  { key: "power", label: "Power (W)", color: "#ff7300" },
  { key: "energy", label: "Energy (kWh)", color: "#0088FE" },
  { key: "frequency", label: "Frequency (Hz)", color: "#00C49F" },
  { key: "power_factor", label: "Power Factor", color: "#FFBB28" }
];
const DC_PARAMS = [
  { key: "voltage", label: "Voltage (V)", color: "#8884d8" },
  { key: "current", label: "Current (A)", color: "#82ca9d" },
  { key: "power", label: "Power (W)", color: "#ff7300" }
];

function getNested(obj, path) {
  return path.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : null), obj);
}

function generateRealisticDummyHistory() {
  const now = Date.now();
  const data = [];
  const recommendations = [];
  for (let i = 0; i < 24; i++) {
    const t = now - (24 - i) * 60 * 60 * 1000;
    // Simulate realistic AC values
    const ac_voltage = 220 + (Math.random() - 0.5) * 10; // 215-225V
    const ac_current = 10 + (Math.random() - 0.5) * 2; // 9-11A
    const ac_power = ac_voltage * ac_current * (0.9 + (Math.random() - 0.5) * 0.1); // with pf
    const ac_energy = (i === 0 ? 0 : data[i-1].ac.energy) + ac_power / 1000; // kWh
    const ac_frequency = 50 + (Math.random() - 0.5) * 0.2; // 49.9-50.1Hz
    const ac_power_factor = 0.92 + (Math.random() - 0.5) * 0.05; // 0.895-0.945
    // Simulate realistic DC values
    const dc_voltage = 400 + (Math.random() - 0.5) * 20; // 390-410V
    const dc_current = 8 + (Math.random() - 0.5) * 2; // 7-9A
    const dc_power = dc_voltage * dc_current;
    // Simulate environment
    const temperature = 30 + (Math.random() - 0.5) * 5; // 27.5-32.5°C
    const humidity = 50 + (Math.random() - 0.5) * 10; // 45-55%
    // Fault detection
    let faults = [];
    if (ac_voltage > 230) faults.push("AC overvoltage detected");
    if (ac_voltage < 210) faults.push("AC undervoltage detected");
    if (ac_current > 12) faults.push("AC overcurrent detected");
    if (ac_power_factor < 0.9) faults.push("Low power factor");
    if (dc_voltage > 420) faults.push("DC overvoltage detected");
    if (dc_current > 10) faults.push("DC overcurrent detected");
    if (temperature > 40) faults.push("High temperature detected");
    // Recommendations
    let recs = [];
    if (faults.includes("AC overvoltage detected")) recs.push("Check grid supply or voltage regulator.");
    if (faults.includes("AC undervoltage detected")) recs.push("Inspect incoming supply for brownout.");
    if (faults.includes("AC overcurrent detected")) recs.push("Check for short circuit or overload.");
    if (faults.includes("Low power factor")) recs.push("Consider power factor correction.");
    if (faults.includes("DC overvoltage detected")) recs.push("Check DC-DC converter settings.");
    if (faults.includes("DC overcurrent detected")) recs.push("Inspect DC load or wiring.");
    if (faults.includes("High temperature detected")) recs.push("Schedule cooling system maintenance.");
    if (recs.length > 0) {
      recommendations.push({
        time: new Date(t).toLocaleString(),
        faults,
        recs
      });
    }
    data.push({
      timestamp: t,
      ac: {
        voltage: +ac_voltage.toFixed(2),
        current: +ac_current.toFixed(2),
        power: +ac_power.toFixed(2),
        energy: +ac_energy.toFixed(3),
        frequency: +ac_frequency.toFixed(2),
        power_factor: +ac_power_factor.toFixed(3)
      },
      dc: {
        voltage: +dc_voltage.toFixed(2),
        current: +dc_current.toFixed(2),
        power: +dc_power.toFixed(2)
      },
      environment: {
        temperature: +temperature.toFixed(2),
        humidity: +humidity.toFixed(2)
      },
      cycles: i, // Add cycles for dummy data
      efficiency: ac_power > 0 ? ((dc_power / ac_power) * 100).toFixed(1) : null // Add efficiency for dummy data
    });
  }
  return { data, recommendations };
}

export default function HistoryPanel({ station }) {
  const [history, setHistory] = useState([]);
  const [live, setLive] = useState({});
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [realTimeData, setRealTimeData] = useState([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showHistoricalViewer, setShowHistoricalViewer] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedTimeRange, setSelectedTimeRange] = useState('24h');

  useEffect(() => {
    if (station === "station1") {
      // Fetch history
      const historyRef = ref(db, "charging_station/history");
      const unsubHistory = onValue(historyRef, (snapshot) => {
        const val = snapshot.val();
        if (!val) {
          console.log("No history data found, using dummy data");
          const { data, recommendations } = generateRealisticDummyHistory();
          setHistory(data);
          setLive(data[data.length - 1]);
          setRecommendations(recommendations);
          setLoading(false);
          return;
        }
        
        console.log("History data received:", Object.keys(val).length, "entries");
        const arr = Object.entries(val).map(([utc, d]) => ({
          timestamp: d.timestamp || Number(utc),
          ac: d.power?.ac || {},
          dc: d.power?.dc || {},
          environment: d.environment || {},
          cycles: d.cycles || 0,
          efficiency: d.efficiency || null
        })).sort((a, b) => a.timestamp - b.timestamp);
        
        console.log("Processed history data:", arr.length, "entries");
        setHistory(arr);
        
        // Set the latest entry as live data
        if (arr.length > 0) {
          setLive(arr[arr.length - 1]);
        }
        setLoading(false);
      });
      
      // Fetch live data and add to real-time history
      const liveRef = ref(db, "charging_station/current_status");
      const unsubLive = onValue(liveRef, (snapshot) => {
        const d = snapshot.val();
        console.log("Live data snapshot:", d);
        if (d) {
          console.log("Live data received:", d);
          const currentTime = Date.now(); // Always use current time
          const liveData = {
            timestamp: currentTime, // Force current timestamp
            ac: d.power?.ac || {},
            dc: d.power?.dc || {},
            environment: d.environment || {},
            cycles: d.cycles || 0,
            efficiency: d.efficiency || null
          };
          console.log("Processed live data with current time:", liveData);
          console.log("AC data includes power factor:", liveData.ac?.power_factor);
          setLive(liveData);
          
          // Add to real-time data array (keep last 50 points)
          setRealTimeData(prevData => {
            const newData = [...prevData, liveData];
            if (newData.length > 50) {
              return newData.slice(-50); // Keep only last 50 points
            }
            return newData;
          });
        } else {
          console.log("No live data available");
          // Generate test real-time data for demonstration
          const testData = {
            timestamp: Date.now(),
            ac: {
              voltage: 220 + Math.random() * 10,
              current: 10 + Math.random() * 2,
              power: 2200 + Math.random() * 200,
              energy: 5 + Math.random() * 2,
              frequency: 50 + Math.random() * 0.2,
              power_factor: 0.92 + Math.random() * 0.05
            },
            dc: {
              voltage: 400 + Math.random() * 20,
              current: 8 + Math.random() * 2,
              power: 3200 + Math.random() * 300
            },
            environment: {
              temperature: 30 + Math.random() * 5,
              humidity: 50 + Math.random() * 10
            },
            cycles: Math.floor(Math.random() * 5) + 1,
            efficiency: 85 + Math.random() * 10
          };
          
          console.log("Test data includes power factor:", testData.ac?.power_factor);
          setLive(testData);
          setRealTimeData(prevData => {
            const newData = [...prevData, testData];
            if (newData.length > 50) {
              return newData.slice(-50);
            }
            return newData;
          });
        }
      });
      
      return () => { unsubHistory(); unsubLive(); };
    } else {
      // Use realistic dummy data for other stations
      const { data, recommendations } = generateRealisticDummyHistory();
      setHistory(data);
      setLive(data[data.length - 1]);
      setRecommendations(recommendations);
      setLoading(false);
    }
  }, [station]);

  // Update current time every second and add real-time data points
  useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
      
      // Add a new data point every 5 seconds if we have live data
      if (live.timestamp && Object.keys(live.ac).length > 0) {
        const newDataPoint = {
          ...live,
          timestamp: Date.now() // Update with current time
        };
        
        setRealTimeData(prevData => {
          const newData = [...prevData, newDataPoint];
          if (newData.length > 50) {
            return newData.slice(-50);
          }
          return newData;
        });
      }
    }, 5000); // Update every 5 seconds
    
    return () => clearInterval(timeInterval);
  }, [live]);

  const formatTime = ts => {
    const d = new Date(ts);
    return d.getHours() + ":" + String(d.getMinutes()).padStart(2, '0');
  };

  // Filter historical data by date and time range
  const getFilteredHistoricalData = () => {
    if (!showHistoricalViewer) return history;
    
    const selectedDateObj = new Date(selectedDate);
    const startOfDay = selectedDateObj.getTime();
    const endOfDay = startOfDay + 24 * 60 * 60 * 1000;
    
    let filteredData = history.filter(d => {
      const dataDate = new Date(d.timestamp);
      return dataDate >= startOfDay && dataDate < endOfDay;
    });
    
    // Apply time range filter
    if (selectedTimeRange !== '24h') {
      const now = new Date();
      const rangeMap = {
        '1h': 60 * 60 * 1000,
        '6h': 6 * 60 * 60 * 1000,
        '12h': 12 * 60 * 60 * 1000
      };
      
      const rangeMs = rangeMap[selectedTimeRange];
      const cutoffTime = now.getTime() - rangeMs;
      
      filteredData = filteredData.filter(d => d.timestamp >= cutoffTime);
    }
    
    return filteredData;
  };

  // Combine historical and real-time data and filter for station 1 only
  const combinedData = [...history, ...realTimeData]
    .filter(d => d.timestamp) // Filter out entries without timestamps
    .sort((a, b) => a.timestamp - b.timestamp);
  
  // Calculate efficiency for each data point
  const perfHistory = combinedData.map(d => ({
    ...d,
    efficiency: d.power_in && d.power_out ? ((d.power_out / d.power_in) * 100).toFixed(1) : null
  }));
  const avgEfficiency = perfHistory.length > 0 ? (
    perfHistory.reduce((sum, d) => sum + (parseFloat(d.efficiency) || 0), 0) / perfHistory.length
  ).toFixed(1) : null;

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '2rem' }}>
        <h2>Loading Historical Data...</h2>
        <p>Please wait while we fetch the data from the database.</p>
      </div>
    );
  }

  return (
    <div>
      <h2>Live + Historical Data</h2>
      <div style={{ 
        background: '#e3f2fd', 
        padding: '1rem', 
        borderRadius: '8px', 
        marginBottom: '1rem',
        border: '1px solid #2196f3'
      }}>
        <h4 style={{ margin: '0 0 0.5rem 0', color: '#1976d2' }}>
          📊 Data Status - Station 1
          <span style={{ 
            background: '#4caf50', 
            color: '#fff', 
            padding: '0.2rem 0.5rem', 
            borderRadius: '4px', 
            fontSize: '0.7rem', 
            marginLeft: '0.5rem',
            animation: 'pulse 2s infinite'
          }}>
            🔴 LIVE
          </span>
          <span style={{ 
            background: '#2196f3', 
            color: '#fff', 
            padding: '0.2rem 0.5rem', 
            borderRadius: '4px', 
            fontSize: '0.7rem', 
            marginLeft: '0.5rem'
          }}>
            🕐 {currentTime.toLocaleTimeString()}
          </span>
        </h4>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>Historical Data Points:</strong> {history.length} entries
        </p>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>Real-time Data Points:</strong> {realTimeData.length} entries
        </p>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>Total Data Points:</strong> {combinedData.length} entries
        </p>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>Live Data Available:</strong> {Object.keys(live).length > 0 ? 'Yes' : 'No'}
        </p>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>AC Data Points:</strong> {combinedData.filter(d => Object.keys(d.ac).length > 0).length} entries
        </p>
        <p style={{ margin: '0.5rem 0', color: '#333' }}>
          <strong>DC Data Points:</strong> {combinedData.filter(d => Object.keys(d.dc).length > 0).length} entries
        </p>
      </div>

      {/* Historical Data Viewer Controls */}
      <div style={{ 
        background: '#fff3e0', 
        padding: '1rem', 
        borderRadius: '8px', 
        marginBottom: '1rem',
        border: '1px solid #ff9800'
      }}>
        <h4 style={{ margin: '0 0 1rem 0', color: '#e65100' }}>
          📅 Historical Data Viewer
        </h4>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
              Date:
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ddd' }}
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
              Time Range:
            </label>
            <select
              value={selectedTimeRange}
              onChange={(e) => setSelectedTimeRange(e.target.value)}
              style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ddd' }}
            >
              <option value="1h">Last 1 Hour</option>
              <option value="6h">Last 6 Hours</option>
              <option value="12h">Last 12 Hours</option>
              <option value="24h">Full Day</option>
            </select>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'end' }}>
            <button
              onClick={() => setShowHistoricalViewer(!showHistoricalViewer)}
              style={{
                padding: '0.5rem 1rem',
                background: showHistoricalViewer ? '#f44336' : '#4caf50',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: 'bold'
              }}
            >
              {showHistoricalViewer ? 'Hide Historical View' : 'Show Historical View'}
            </button>
            <button
              onClick={() => {
                setSelectedDate(new Date().toISOString().split('T')[0]);
                setSelectedTimeRange('24h');
              }}
              style={{
                padding: '0.5rem 1rem',
                background: '#2196f3',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Reset
            </button>
          </div>
        </div>
        {showHistoricalViewer && (
          <div style={{ marginTop: '1rem', padding: '1rem', background: '#f5f5f5', borderRadius: '4px' }}>
            <p><strong>Filtered Data Points:</strong> {getFilteredHistoricalData().length} entries</p>
            <p><strong>Date Range:</strong> {new Date(selectedDate).toLocaleDateString()}</p>
            <p><strong>Time Range:</strong> {selectedTimeRange}</p>
          </div>
        )}
      </div>
      {history.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '2rem', background: '#f8f9fa', borderRadius: '8px', margin: '1rem 0' }}>
          <h3>No Historical Data Available</h3>
          <p>Historical data will appear here once the system starts logging data.</p>
          <p>For demonstration purposes, you can view dummy data for other stations.</p>
        </div>
      ) : (
        <>
                    {/* Individual AC Parameter Graphs */}
          <div style={{ marginBottom: 32 }}>
            <h3>AC Parameters (Station 1 - Real-time)</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1rem' }}>
              {AC_PARAMS.map(param => (
                <div key={param.key} style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem' }}>
                  <h4 style={{ margin: '0 0 1rem 0', color: '#333' }}>{param.label}</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={combinedData.map(d => ({ 
                      timestamp: d.timestamp, 
                      value: d.ac?.[param.key] || 0 
                    }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="timestamp" 
                        tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                        angle={-45}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis />
                      <Tooltip 
                        labelFormatter={ts => new Date(ts).toLocaleString()}
                        formatter={(value, name) => [value, param.label]}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke={param.color} 
                        dot={false} 
                        name={param.label}
                        strokeWidth={2}
                      />
                      {live.ac?.[param.key] && live.timestamp && (
                        <ReferenceDot 
                          x={live.timestamp} 
                          y={live.ac[param.key]} 
                          r={5} 
                          fill={param.color} 
                          stroke="none" 
                          label={{ 
                            value: `Live: ${live.ac[param.key]}`, 
                            position: 'top',
                            fill: param.color
                          }} 
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              ))}
            </div>
          </div>
          
                    {/* Individual DC Parameter Graphs */}
          <div style={{ marginBottom: 32 }}>
            <h3>DC Parameters (Station 1 - Real-time)</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1rem' }}>
              {DC_PARAMS.map(param => (
                <div key={param.key} style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem' }}>
                  <h4 style={{ margin: '0 0 1rem 0', color: '#333' }}>{param.label}</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={combinedData.map(d => ({ 
                      timestamp: d.timestamp, 
                      value: d.dc?.[param.key] || 0 
                    }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="timestamp" 
                        tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                        angle={-45}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis />
                      <Tooltip 
                        labelFormatter={ts => new Date(ts).toLocaleString()}
                        formatter={(value, name) => [value, param.label]}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke={param.color} 
                        dot={false} 
                        name={param.label}
                        strokeWidth={2}
                      />
                      {live.dc?.[param.key] && live.timestamp && (
                        <ReferenceDot 
                          x={live.timestamp} 
                          y={live.dc[param.key]} 
                          r={5} 
                          fill={param.color} 
                          stroke="none" 
                          label={{ 
                            value: `Live: ${live.dc[param.key]}`, 
                            position: 'top',
                            fill: param.color
                          }} 
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              ))}
            </div>
          </div>
          
          {/* Charging Cycles Graph */}
          <h3 style={{ marginTop: '2rem' }}>Charging Cycles (Station 1 - Real-time)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={combinedData.map(d => ({ 
              timestamp: d.timestamp, 
              cycles: d.cycles || 0 
            }))} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="timestamp" 
                tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis allowDecimals={false} />
              <Tooltip labelFormatter={ts => new Date(ts).toLocaleString()} />
              <Legend />
              <Line type="monotone" dataKey="cycles" stroke="#8884d8" name="Charging Cycles" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
          
          {/* Performance (Efficiency) Graph */}
          <h3 style={{ marginTop: '2rem' }}>Performance (Efficiency) - Station 1 Real-time</h3>
          <div style={{ marginBottom: '1rem', fontWeight: 600 }}>
            Average efficiency today: {avgEfficiency ? `${avgEfficiency}%` : 'N/A'}
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={perfHistory} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="timestamp" 
                tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis domain={[0, 100]} unit="%" />
              <Tooltip labelFormatter={ts => new Date(ts).toLocaleString()} />
              <Legend />
              <Line type="monotone" dataKey="efficiency" stroke="#00b894" name="Efficiency (%)" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
          
          {/* Recommendations for non-station1 */}
          {station !== "station1" && (
            <div style={{ marginTop: 32, padding: 16, background: '#fffbe6', border: '1px solid #ffe58f', borderRadius: 8 }}>
              <h3>Predicted Faults & Maintenance Suggestions</h3>
              {recommendations.map((rec, idx) => (
                <div key={idx} style={{ marginBottom: 16 }}>
                  <strong>{rec.time}</strong>
                  <ul>
                    {Array.isArray(rec.faults) && rec.faults.map((f, i) => <li key={i} style={{ color: 'red' }}>{f}</li>)}
                    {Array.isArray(rec.recs) && rec.recs.map((r, i) => <li key={i} style={{ color: 'green' }}>{r}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {/* Historical Data Graphs */}
          {showHistoricalViewer && getFilteredHistoricalData().length > 0 && (
            <>
              <div style={{ marginTop: '3rem', padding: '2rem', background: '#f8f9fa', borderRadius: '8px', border: '2px solid #ff9800' }}>
                <h3 style={{ color: '#e65100', marginBottom: '1rem' }}>
                  📅 Historical Data Analysis - {new Date(selectedDate).toLocaleDateString()}
                </h3>
                
                {/* Historical AC Parameters */}
                <div style={{ marginBottom: 32 }}>
                  <h4>Historical AC Parameters</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1rem' }}>
                    {AC_PARAMS.map(param => (
                      <div key={`hist-${param.key}`} style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem', background: '#fff' }}>
                        <h5 style={{ margin: '0 0 1rem 0', color: '#333' }}>{param.label}</h5>
                        <ResponsiveContainer width="100%" height={200}>
                          <LineChart data={getFilteredHistoricalData().map(d => ({ 
                            timestamp: d.timestamp, 
                            value: d.ac?.[param.key] || 0 
                          }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis 
                              dataKey="timestamp" 
                              tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                              angle={-45}
                              textAnchor="end"
                              height={60}
                            />
                            <YAxis />
                            <Tooltip 
                              labelFormatter={ts => new Date(ts).toLocaleString()}
                              formatter={(value, name) => [value, param.label]}
                            />
                            <Line 
                              type="monotone" 
                              dataKey="value" 
                              stroke={param.color} 
                              dot={false} 
                              name={param.label}
                              strokeWidth={2}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Historical DC Parameters */}
                <div style={{ marginBottom: 32 }}>
                  <h4>Historical DC Parameters</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1rem' }}>
                    {DC_PARAMS.map(param => (
                      <div key={`hist-${param.key}`} style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem', background: '#fff' }}>
                        <h5 style={{ margin: '0 0 1rem 0', color: '#333' }}>{param.label}</h5>
                        <ResponsiveContainer width="100%" height={200}>
                          <LineChart data={getFilteredHistoricalData().map(d => ({ 
                            timestamp: d.timestamp, 
                            value: d.dc?.[param.key] || 0 
                          }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis 
                              dataKey="timestamp" 
                              tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                              angle={-45}
                              textAnchor="end"
                              height={60}
                            />
                            <YAxis />
                            <Tooltip 
                              labelFormatter={ts => new Date(ts).toLocaleString()}
                              formatter={(value, name) => [value, param.label]}
                            />
                            <Line 
                              type="monotone" 
                              dataKey="value" 
                              stroke={param.color} 
                              dot={false} 
                              name={param.label}
                              strokeWidth={2}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Historical Environment Data */}
                <div style={{ marginBottom: 32 }}>
                  <h4>Historical Environment Data</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1rem' }}>
                    <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem', background: '#fff' }}>
                      <h5 style={{ margin: '0 0 1rem 0', color: '#333' }}>Temperature (°C)</h5>
                      <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={getFilteredHistoricalData().map(d => ({ 
                          timestamp: d.timestamp, 
                          value: d.environment?.temperature || 0 
                        }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                            angle={-45}
                            textAnchor="end"
                            height={60}
                          />
                          <YAxis />
                          <Tooltip 
                            labelFormatter={ts => new Date(ts).toLocaleString()}
                            formatter={(value, name) => [value, 'Temperature (°C)']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#ff6b6b" 
                            dot={false} 
                            name="Temperature"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem', background: '#fff' }}>
                      <h5 style={{ margin: '0 0 1rem 0', color: '#333' }}>Humidity (%)</h5>
                      <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={getFilteredHistoricalData().map(d => ({ 
                          timestamp: d.timestamp, 
                          value: d.environment?.humidity || 0 
                        }))} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
                            angle={-45}
                            textAnchor="end"
                            height={60}
                          />
                          <YAxis />
                          <Tooltip 
                            labelFormatter={ts => new Date(ts).toLocaleString()}
                            formatter={(value, name) => [value, 'Humidity (%)']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#4ecdc4" 
                            dot={false} 
                            name="Humidity"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
} 