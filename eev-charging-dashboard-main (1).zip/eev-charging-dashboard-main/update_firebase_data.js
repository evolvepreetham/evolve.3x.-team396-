// update_firebase_data.js
const { initializeApp } = require("firebase/app");
const { getDatabase, ref, set, get } = require("firebase/database");

// Firebase configuration from src/firebase.js
const firebaseConfig = {
  apiKey: "AIzaSyBIxhLuWiZCmVzHA7MLBYAxNj1OjXAqZYQ",
  authDomain: "dbs3-6e2a6.firebaseapp.com",
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "dbs3-6e2a6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to update current status data with test values
async function updateCurrentStatus() {
  console.log("\n=== UPDATING CURRENT STATUS DATA WITH TEST VALUES ===");
  
  try {
    // First, get the current data
    const currentStatusRef = ref(db, "charging_station/current_status");
    const snapshot = await get(currentStatusRef);
    const currentData = snapshot.val() || {};
    
    // Create updated data with some modified values
    // We'll keep most of the structure but update some key values
    const updatedData = {
      ...currentData,
      timestamp: Date.now(),
      power: {
        ac: {
          voltage: 240.5, // Modified value
          current: 15.2,  // Modified value
          power: 3.65,    // Modified value
          power_factor: 0.98
        },
        dc: {
          ...(currentData.power?.dc || {}),
          voltage: 400.2, // Modified value
          current: 10.5,  // Modified value
          power: 4.2      // Modified value
        }
      },
      environment: {
        ...(currentData.environment || {}),
        temperature: 28.5, // Modified value
        humidity: 65.3     // Modified value
      },
      system: {
        ...(currentData.system || {}),
        cpu_load: 45,      // Modified value
        memory_usage: 62,  // Modified value
        storage_usage: 78  // Modified value
      },
      slots: {
        0: { status: "charging", power_output: 7.2 },
        1: { status: "available", power_output: 0 },
        2: { status: "error", power_output: 0 },
        3: { status: "reserved", power_output: 0 }
      }
    };
    
    // Update the data in Firebase
    await set(currentStatusRef, updatedData);
    
    console.log("Successfully updated current status data with test values.");
    console.log("\nUpdated values:");
    console.log("- AC Voltage: 240.5 V");
    console.log("- AC Current: 15.2 A");
    console.log("- AC Power: 3.65 kW");
    console.log("- DC Voltage: 400.2 V");
    console.log("- DC Current: 10.5 A");
    console.log("- DC Power: 4.2 kW");
    console.log("- Temperature: 28.5 °C");
    console.log("- Humidity: 65.3 %");
    console.log("- CPU Load: 45 %");
    console.log("- Memory Usage: 62 %");
    console.log("- Storage Usage: 78 %");
    console.log("- Slot 0: charging (7.2 kW)");
    console.log("- Slot 1: available (0 kW)");
    console.log("- Slot 2: error (0 kW)");
    console.log("- Slot 3: reserved (0 kW)");
    
    console.log("\nVerification Instructions:");
    console.log("1. Check if the dashboard updates with these new values");
    console.log("2. The dashboard should display these exact values for Station 1");
    console.log("3. This confirms that the dashboard is correctly displaying data from the database");
    
    return true;
  } catch (error) {
    console.error("Error updating current status:", error);
    return false;
  }
}

// Run the update
console.log("Starting Firebase data update...");
console.log("This script will update the database with test values to verify dashboard updates.");

updateCurrentStatus()
  .then(() => {
    console.log("\nUpdate process completed. Check the dashboard for changes.");
  })
  .catch(console.error);