// check_firebase_data.js
const { initializeApp } = require("firebase/app");
const { getDatabase, ref, get } = require("firebase/database");

// Firebase configuration from src/firebase.js
const firebaseConfig = {
  apiKey: "AIzaSyBIxhLuWiZCmVzHA7MLBYAxNj1OjXAqZYQ",
  authDomain: "dbs3-6e2a6.firebaseapp.com",
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "dbs3-6e2a6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to check current status data
async function checkCurrentStatus() {
  console.log("\n=== CHECKING CURRENT STATUS DATA ===");
  const currentStatusRef = ref(db, "charging_station/current_status");
  
  try {
    const snapshot = await get(currentStatusRef);
    const data = snapshot.val();
    
    if (!data) {
      console.log("No current status data found in the database.");
      return false;
    }
    
    console.log("Current status data found:");
    console.log("- Timestamp:", data.timestamp ? new Date(data.timestamp).toLocaleString() : "Not available");
    console.log("- AC Power data available:", data.power && data.power.ac ? "Yes" : "No");
    console.log("- DC Power data available:", data.power && data.power.dc ? "Yes" : "No");
    console.log("- Environment data available:", data.environment ? "Yes" : "No");
    console.log("- System data available:", data.system ? "Yes" : "No");
    console.log("- Connection data available:", data.connection ? "Yes" : "No");
    console.log("- Slots data available:", data.slots ? "Yes" : "No");
    
    // Print some sample values if available
    if (data.power && data.power.ac) {
      console.log("\nSample AC Power values:");
      console.log("- Voltage:", data.power.ac.voltage);
      console.log("- Current:", data.power.ac.current);
      console.log("- Power:", data.power.ac.power);
      console.log("- Power Factor:", data.power.ac.power_factor);
    }
    
    if (data.environment) {
      console.log("\nSample Environment values:");
      console.log("- Temperature:", data.environment.temperature);
      console.log("- Humidity:", data.environment.humidity);
    }
    
    return true;
  } catch (error) {
    console.error("Error checking current status:", error);
    return false;
  }
}

// Function to check history data
async function checkHistoryData() {
  console.log("\n=== CHECKING HISTORY DATA ===");
  const historyRef = ref(db, "charging_station/history");
  
  try {
    const snapshot = await get(historyRef);
    const data = snapshot.val();
    
    if (!data) {
      console.log("No history data found in the database.");
      return false;
    }
    
    const entries = Object.entries(data);
    console.log(`Found ${entries.length} history entries. Showing the latest 5:`);
    
    // Get the last 5 entries
    const latestEntries = entries.sort((a, b) => b[0] - a[0]).slice(0, 5);
    
    latestEntries.forEach(([key, entry], index) => {
      console.log(`\nEntry ${index + 1} (${key}):`);
      console.log("- Timestamp:", entry.timestamp ? new Date(entry.timestamp).toLocaleString() : "Not available");
      console.log("- AC Power data available:", entry.power && entry.power.ac ? "Yes" : "No");
      console.log("- DC Power data available:", entry.power && entry.power.dc ? "Yes" : "No");
      console.log("- Environment data available:", entry.environment ? "Yes" : "No");
    });
    
    return true;
  } catch (error) {
    console.error("Error checking history data:", error);
    return false;
  }
}

// Run the checks
async function runChecks() {
  console.log("Starting Firebase data verification...");
  
  const currentStatusOk = await checkCurrentStatus();
  const historyDataOk = await checkHistoryData();
  
  console.log("\n=== VERIFICATION SUMMARY ===");
  console.log("Current Status Data:", currentStatusOk ? "✅ Available" : "❌ Not available");
  console.log("History Data:", historyDataOk ? "✅ Available" : "❌ Not available");
  
  if (currentStatusOk && historyDataOk) {
    console.log("\n✅ All data is available in the database and should be displayed in the dashboard for Station 1.");
  } else {
    console.log("\n❌ Some data is missing in the database. The dashboard may not display complete information for Station 1.");
  }
}

runChecks().catch(console.error);