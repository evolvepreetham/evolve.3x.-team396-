// verify_dashboard_data.js
const { initializeApp } = require("firebase/app");
const { getDatabase, ref, onValue } = require("firebase/database");

// Firebase configuration from src/firebase.js
const firebaseConfig = {
  apiKey: "AIzaSyBIxhLuWiZCmVzHA7MLBYAxNj1OjXAqZYQ",
  authDomain: "dbs3-6e2a6.firebaseapp.com",
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app/",
  projectId: "dbs3-6e2a6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to monitor real-time data updates
function monitorCurrentStatus() {
  console.log("\n=== MONITORING CURRENT STATUS DATA IN REAL-TIME ===");
  console.log("This script will show real-time updates from the database.");
  console.log("Compare this data with what you see in the dashboard to verify correct display.\n");
  
  const currentStatusRef = ref(db, "charging_station/current_status");
  
  onValue(currentStatusRef, (snapshot) => {
    const data = snapshot.val();
    if (!data) {
      console.log("No current status data found in the database.");
      return;
    }
    
    const timestamp = new Date().toLocaleTimeString();
    console.log(`\n[${timestamp}] New data received:`);
    
    // Display key metrics that should match the dashboard
    if (data.power && data.power.ac) {
      console.log("AC Power:");
      console.log(`  - Voltage: ${data.power.ac.voltage} V`);
      console.log(`  - Current: ${data.power.ac.current} A`);
      console.log(`  - Power: ${data.power.ac.power} kW`);
    }
    
    if (data.power && data.power.dc) {
      console.log("DC Power:");
      console.log(`  - Voltage: ${data.power.dc.voltage} V`);
      console.log(`  - Current: ${data.power.dc.current} A`);
      console.log(`  - Power: ${data.power.dc.power} kW`);
    }
    
    if (data.environment) {
      console.log("Environment:");
      console.log(`  - Temperature: ${data.environment.temperature} °C`);
      console.log(`  - Humidity: ${data.environment.humidity} %`);
    }
    
    if (data.system) {
      console.log("System Health:");
      console.log(`  - CPU: ${data.system.cpu_load} %`);
      console.log(`  - Memory: ${data.system.memory_usage} %`);
      console.log(`  - Storage: ${data.system.storage_usage} %`);
    }
    
    if (data.slots) {
      console.log("Charging Slots:");
      Object.entries(data.slots).forEach(([slotId, slotData]) => {
        console.log(`  - Slot ${slotId}: ${slotData.status} (${slotData.power_output} kW)`);
      });
    }
    
    console.log("\nVerification Instructions:");
    console.log("1. Compare these values with what you see in the dashboard");
    console.log("2. The dashboard should display the same values for Station 1");
    console.log("3. Press Ctrl+C to stop monitoring when verification is complete");
  });
}

// Start monitoring
console.log("Starting dashboard data verification...");
console.log("This script will help verify if the data in the database is correctly displayed in the dashboard.");
monitorCurrentStatus();

// Keep the script running
console.log("\nMonitoring for data changes. Press Ctrl+C to exit.");