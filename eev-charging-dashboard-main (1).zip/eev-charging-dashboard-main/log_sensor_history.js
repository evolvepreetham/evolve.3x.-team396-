// log_sensor_history.js
const admin = require("firebase-admin");

// Download your service account key from Firebase Console and put the path here:
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dbs3-6e2a6-default-rtdb.asia-southeast1.firebasedatabase.app"
});

const db = admin.database();

const currentStatusRef = db.ref("charging_station/current_status");
const historyRef = db.ref("charging_station/history");

console.log("Listening for charging_station/current_status changes...");

currentStatusRef.on("value", (snapshot) => {
  const data = snapshot.val();
  if (!data) return;
  
  const timestamp = Date.now();
  const historyEntry = {
    timestamp: timestamp,
    power: data.power || {},
    environment: data.environment || {},
    system: data.system || {},
    cycles: data.cycles || 0,
    efficiency: data.efficiency || null
  };
  
  // Store in history with timestamp as key
  historyRef.child(timestamp).set(historyEntry);
  console.log(`Logged data to charging_station/history/${timestamp}`);
});

// Also log data every 5 minutes for continuous monitoring
setInterval(() => {
  currentStatusRef.once("value", (snapshot) => {
    const data = snapshot.val();
    if (!data) return;
    
    const timestamp = Date.now();
    const historyEntry = {
      timestamp: timestamp,
      power: data.power || {},
      environment: data.environment || {},
      system: data.system || {},
      cycles: data.cycles || 0,
      efficiency: data.efficiency || null
    };
    
    historyRef.child(timestamp).set(historyEntry);
    console.log(`Scheduled log: Data logged to charging_station/history/${timestamp}`);
  });
}, 5 * 60 * 1000); // 5 minutes

console.log("Data logging service started. Press Ctrl+C to stop."); 