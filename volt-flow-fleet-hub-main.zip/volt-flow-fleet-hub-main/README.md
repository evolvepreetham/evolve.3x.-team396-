# VoltFlow Fleet Hub

A modern, responsive EV fleet charging schedule application built with React, TypeScript, and Tailwind CSS.

## 🚀 Features

### Fleet Manager Dashboard
- **Real-time Fleet Overview**: Monitor all vehicles with live SOC, status, and location tracking
- **Interactive Fleet Map**: Visual representation of vehicle positions and charging stations
- **Comprehensive Trip Management**: View active trips with detailed charging schedules
- **Fleet Analytics**: Track energy usage, charging costs, and trip efficiency
- **Responsive Design**: Optimized for desktop and mobile devices

### Driver Dashboard
- **Route Visualization**: Interactive map showing trip route with charging stops
- **Live Charging Control**: Start/stop charging sessions with real-time SOC monitoring
- **Navigation Integration**: Direct links to Google Maps for turn-by-turn directions
- **Trip Progress**: Track completion status of charging stops
- **Mobile-First Design**: Optimized for use on mobile devices while driving

### Key Components
- **Navigation Sidebar**: Easy access to all fleet management sections
- **Real-time Data**: Live updates of vehicle status and charging progress
- **Interactive Maps**: Powered by Leaflet for smooth, responsive mapping
- **Charging Session Simulation**: Demo charging functionality with progress tracking
- **Trip Details Modal**: Comprehensive breakdown of charging schedules

## 🛠️ Technology Stack

- **Frontend Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: shadcn/ui for consistent, accessible components
- **Maps**: Leaflet for interactive mapping functionality
- **Routing**: React Router for client-side navigation
- **State Management**: React hooks and context
- **Data Fetching**: TanStack Query for efficient data management

## 📦 Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn package manager

### Getting Started

1. **Clone the repository**
   ```bash
   git clone <your-repository-url>
   cd voltflow-fleet-hub
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:8080` to view the application

### Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint for code quality checks

## 🎯 Usage

### Fleet Manager View (Default Dashboard)
1. **Dashboard Overview**: View fleet-wide metrics including average SOC, energy usage, and active trips
2. **Vehicle Status Table**: Monitor individual vehicle status, current SOC, and next charging stops
3. **Fleet Map**: Visual overview of all vehicle positions and nearby charging stations
4. **Trip Management**: View active trips and click "View Details" for comprehensive trip breakdowns

### Driver Dashboard
1. **Access Driver View**: Navigate to `/driver` or use the navigation sidebar
2. **Route Overview**: View your current trip route with planned charging stops
3. **Charging Control**: Use the charging session controls to start/stop charging
4. **Navigation**: Click "Navigate" buttons to open external navigation apps
5. **Progress Tracking**: Monitor trip progress and completion status

### Navigation
- Use the sidebar to switch between different sections
- The sidebar collapses on mobile for better screen real estate
- All sections are fully responsive and touch-friendly

## 🗂️ Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # shadcn/ui base components
│   ├── AppSidebar.tsx  # Main navigation sidebar
│   ├── Header.tsx      # Application header
│   ├── FleetMap.tsx    # Fleet overview map component
│   ├── RouteMap.tsx    # Driver route map component
│   └── TripDetails.tsx # Trip information modal
├── layouts/            # Layout components
│   └── AppLayout.tsx   # Main application layout
├── pages/              # Page components
│   ├── Dashboard.tsx   # Fleet manager dashboard
│   └── DriverDashboard.tsx # Driver-specific dashboard
├── utils/              # Utility functions and mock data
│   └── mockData.ts     # Sample fleet data
├── hooks/              # Custom React hooks
└── lib/                # Utility libraries
```

## 📊 Mock Data

The application uses comprehensive mock data including:

- **5 Electric Vehicles** with different models, SOC levels, and statuses
- **4 Charging Stations** with various types and availability
- **3 Sample Trips** with detailed charging schedules
- **Fleet Summary Metrics** for dashboard overview

### Sample Vehicle Data
```typescript
{
  id: 'EV001',
  model: 'Tesla Model S',
  status: 'En route',
  currentSOC: 68,
  currentLocation: { lat: 51.505, lng: -0.09 },
  nextChargingStop: {
    stationId: 'CS101',
    eta: '14:30',
    distance: 45,
  },
}
```

### Sample Trip Data
```typescript
{
  id: 'T001',
  vehicleId: 'EV001',
  origin: 'London',
  destination: 'Birmingham',
  scheduledStops: [/* charging stops with SOC, duration, cost */],
  totalCost: 18.50,
  totalDuration: 2.5,
  status: 'In Progress',
}
```

## 🎨 Design System

The application uses a custom design system built on Tailwind CSS:

### Color Palette
- **Primary**: Electric blue (`hsl(197 71% 52%)`) - Main brand color
- **Success**: Green (`hsl(142 76% 36%)`) - Charging status, high SOC
- **Warning**: Amber (`hsl(38 92% 50%)`) - Medium SOC, charging stations
- **Destructive**: Red (`hsl(0 84% 60%)`) - Low SOC, alerts

### Key Design Principles
- **Mobile-First**: Responsive design starting from mobile breakpoints
- **Accessibility**: Proper contrast ratios, semantic HTML, screen reader support
- **Consistency**: Unified spacing, typography, and component behavior
- **Modern**: Clean lines, rounded corners, and subtle shadows

## 📱 Mobile Responsiveness

- **Breakpoints**: Mobile (default), SM (640px+), MD (768px+), LG (1024px+), XL (1280px+)
- **Navigation**: Collapsible sidebar for mobile devices
- **Tables**: Horizontal scrolling on mobile with essential columns prioritized
- **Maps**: Touch-friendly controls and appropriate zoom levels
- **Forms**: Large touch targets and optimized input fields

## ♿ Accessibility Features

- **Semantic HTML**: Proper heading hierarchy and landmark regions
- **Screen Reader Support**: ARIA labels and descriptions where needed
- **Keyboard Navigation**: Full keyboard accessibility for all interactive elements
- **Color Contrast**: WCAG AA compliant color combinations
- **Focus Management**: Clear focus indicators and logical tab order

## 🔮 Future Enhancements

### Backend Integration
- Real-time vehicle tracking via GPS/telematics
- Integration with charging network APIs
- User authentication and role-based access
- Trip optimization algorithms

### Advanced Features
- Predictive charging recommendations
- Weather-based route adjustments
- Cost optimization for charging stops
- Driver behavior analytics
- Maintenance scheduling integration

### Technical Improvements
- Progressive Web App (PWA) capabilities
- Offline functionality for drivers
- Real-time WebSocket connections
- Advanced mapping with routing APIs
- Performance monitoring and analytics

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For questions, issues, or feature requests, please open an issue on the repository or contact the development team.

---

**VoltFlow Fleet Hub** - Powering the future of electric fleet management 🔌⚡