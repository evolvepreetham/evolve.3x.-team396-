// Mock data for EV fleet management application

export interface Vehicle {
  id: string;
  model: string;
  status: 'Idle' | 'En route' | 'Charging';
  currentSOC: number; // percentage
  currentLocation: {
    lat: number;
    lng: number;
  };
  nextChargingStop?: {
    stationId: string;
    eta: string;
    distance: number; // km
  };
}

export interface ChargingStation {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
  };
  type: 'Fast' | 'Rapid' | 'Ultra-rapid';
  availablePorts: number;
  totalPorts: number;
  costPerKwh: number;
}

export interface Trip {
  id: string;
  vehicleId: string;
  origin: string;
  destination: string;
  originCoords: { lat: number; lng: number };
  destinationCoords: { lat: number; lng: number };
  scheduledStops: ChargingStop[];
  totalCost: number;
  totalDuration: number; // hours
  status: 'Planned' | 'In Progress' | 'Completed';
  startTime: string;
}

export interface ChargingStop {
  stationId: string;
  stationName: string;
  arrivalSOC: number;
  departureSOC: number;
  chargeDuration: number; // minutes
  cost: number;
  distance: number; // km from origin
  location: { lat: number; lng: number };
}

export interface FleetSummary {
  averageSOC: number;
  energyUsedToday: number; // kWh
  upcomingTripsCount: number;
  activeVehicles: number;
  chargingVehicles: number;
}

// Mock vehicles data
export const mockVehicles: Vehicle[] = [
  {
    id: 'EV001',
    model: 'Tesla Model S',
    status: 'En route',
    currentSOC: 68,
    currentLocation: { lat: 51.505, lng: -0.09 },
    nextChargingStop: {
      stationId: 'CS101',
      eta: '14:30',
      distance: 45,
    },
  },
  {
    id: 'EV002',
    model: 'BMW iX',
    status: 'Charging',
    currentSOC: 23,
    currentLocation: { lat: 51.515, lng: -0.1 },
  },
  {
    id: 'EV003',
    model: 'Audi e-tron GT',
    status: 'Idle',
    currentSOC: 85,
    currentLocation: { lat: 51.495, lng: -0.08 },
  },
  {
    id: 'EV004',
    model: 'Mercedes EQS',
    status: 'En route',
    currentSOC: 42,
    currentLocation: { lat: 51.52, lng: -0.11 },
    nextChargingStop: {
      stationId: 'CS102',
      eta: '16:15',
      distance: 62,
    },
  },
  {
    id: 'EV005',
    model: 'Volvo XC40 Recharge',
    status: 'Idle',
    currentSOC: 91,
    currentLocation: { lat: 51.485, lng: -0.095 },
  },
];

// Mock charging stations data
export const mockChargingStations: ChargingStation[] = [
  {
    id: 'CS101',
    name: 'Shell Recharge Hub',
    location: { lat: 51.545, lng: -0.05 },
    type: 'Rapid',
    availablePorts: 2,
    totalPorts: 4,
    costPerKwh: 0.65,
  },
  {
    id: 'CS102',
    name: 'BP Pulse Station',
    location: { lat: 51.475, lng: -0.12 },
    type: 'Ultra-rapid',
    availablePorts: 1,
    totalPorts: 6,
    costPerKwh: 0.75,
  },
  {
    id: 'CS103',
    name: 'Ionity Charging Park',
    location: { lat: 51.56, lng: -0.08 },
    type: 'Ultra-rapid',
    availablePorts: 4,
    totalPorts: 8,
    costPerKwh: 0.69,
  },
  {
    id: 'CS104',
    name: 'Gridserve Electric Hub',
    location: { lat: 51.465, lng: -0.15 },
    type: 'Fast',
    availablePorts: 3,
    totalPorts: 12,
    costPerKwh: 0.45,
  },
];

// Mock trips data
export const mockTrips: Trip[] = [
  {
    id: 'T001',
    vehicleId: 'EV001',
    origin: 'London',
    destination: 'Birmingham',
    originCoords: { lat: 51.505, lng: -0.09 },
    destinationCoords: { lat: 52.486, lng: -1.89 },
    scheduledStops: [
      {
        stationId: 'CS101',
        stationName: 'Shell Recharge Hub',
        arrivalSOC: 25,
        departureSOC: 80,
        chargeDuration: 35,
        cost: 18.50,
        distance: 85,
        location: { lat: 51.545, lng: -0.05 },
      },
    ],
    totalCost: 18.50,
    totalDuration: 2.5,
    status: 'In Progress',
    startTime: '2024-01-15T12:00:00Z',
  },
  {
    id: 'T002',
    vehicleId: 'EV004',
    origin: 'London',
    destination: 'Manchester',
    originCoords: { lat: 51.505, lng: -0.09 },
    destinationCoords: { lat: 53.483, lng: -2.244 },
    scheduledStops: [
      {
        stationId: 'CS102',
        stationName: 'BP Pulse Station',
        arrivalSOC: 15,
        departureSOC: 85,
        chargeDuration: 45,
        cost: 26.25,
        distance: 120,
        location: { lat: 51.475, lng: -0.12 },
      },
      {
        stationId: 'CS103',
        stationName: 'Ionity Charging Park',
        arrivalSOC: 30,
        departureSOC: 80,
        chargeDuration: 30,
        cost: 17.25,
        distance: 180,
        location: { lat: 51.56, lng: -0.08 },
      },
    ],
    totalCost: 43.50,
    totalDuration: 3.8,
    status: 'In Progress',
    startTime: '2024-01-15T14:00:00Z',
  },
  {
    id: 'T003',
    vehicleId: 'EV003',
    origin: 'London',
    destination: 'Brighton',
    originCoords: { lat: 51.505, lng: -0.09 },
    destinationCoords: { lat: 50.827, lng: -0.152 },
    scheduledStops: [],
    totalCost: 0,
    totalDuration: 1.2,
    status: 'Planned',
    startTime: '2024-01-15T16:00:00Z',
  },
];

// Mock fleet summary
export const mockFleetSummary: FleetSummary = {
  averageSOC: 61.8,
  energyUsedToday: 247.5,
  upcomingTripsCount: 3,
  activeVehicles: 5,
  chargingVehicles: 1,
};