import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Vehicle, mockChargingStations } from '@/utils/mockData';

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface FleetMapProps {
  vehicles: Vehicle[];
}

/**
 * Interactive map component showing fleet vehicle positions and charging stations
 * Uses Leaflet for map rendering with custom markers for different entity types
 * Responsive design that adapts to container size
 */
export function FleetMap({ vehicles }: FleetMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Initialize map
    mapInstance.current = L.map(mapRef.current).setView([51.505, -0.09], 11);

    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(mapInstance.current);

    // Custom icons
    const vehicleIcon = L.divIcon({
      className: 'custom-vehicle-marker',
      html: `
        <div style="
          background: hsl(197 71% 52%);
          border: 2px solid white;
          border-radius: 50%;
          width: 16px;
          height: 16px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    const chargingIcon = L.divIcon({
      className: 'custom-vehicle-marker',
      html: `
        <div style="
          background: hsl(142 76% 36%);
          border: 2px solid white;
          border-radius: 50%;
          width: 16px;
          height: 16px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    const stationIcon = L.divIcon({
      className: 'custom-station-marker',
      html: `
        <div style="
          background: hsl(38 92% 50%);
          border: 2px solid white;
          border-radius: 4px;
          width: 12px;
          height: 12px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [12, 12],
      iconAnchor: [6, 6],
    });

    // Add vehicle markers
    vehicles.forEach((vehicle) => {
      const icon = vehicle.status === 'Charging' ? chargingIcon : vehicleIcon;
      
      L.marker([vehicle.currentLocation.lat, vehicle.currentLocation.lng], { icon })
        .addTo(mapInstance.current!)
        .bindPopup(`
          <div class="p-2">
            <strong>${vehicle.id}</strong><br/>
            <span class="text-sm text-gray-600">${vehicle.model}</span><br/>
            <span class="text-sm">Status: ${vehicle.status}</span><br/>
            <span class="text-sm">SOC: ${vehicle.currentSOC}%</span>
          </div>
        `);
    });

    // Add charging station markers
    mockChargingStations.forEach((station) => {
      L.marker([station.location.lat, station.location.lng], { icon: stationIcon })
        .addTo(mapInstance.current!)
        .bindPopup(`
          <div class="p-2">
            <strong>${station.name}</strong><br/>
            <span class="text-sm text-gray-600">${station.type}</span><br/>
            <span class="text-sm">Available: ${station.availablePorts}/${station.totalPorts}</span><br/>
            <span class="text-sm">£${station.costPerKwh}/kWh</span>
          </div>
        `);
    });

    // Cleanup function
    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, [vehicles]);

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full rounded-lg" />
      
      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-card border border-border rounded-lg p-3 shadow-lg z-[1000]">
        <h4 className="font-medium text-sm mb-2">Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-primary rounded-full border border-white"></div>
            <span>Active Vehicle</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-success rounded-full border border-white"></div>
            <span>Charging Vehicle</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-warning border border-white"></div>
            <span>Charging Station</span>
          </div>
        </div>
      </div>
    </div>
  );
}