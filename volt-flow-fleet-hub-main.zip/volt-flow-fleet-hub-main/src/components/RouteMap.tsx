import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Trip } from '@/utils/mockData';

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface RouteMapProps {
  trip: Trip;
  currentLocation: { lat: number; lng: number };
}

/**
 * Route-specific map component for driver dashboard
 * Shows trip route with charging stops and current vehicle position
 * Includes distance markers and estimated arrival times
 */
export function RouteMap({ trip, currentLocation }: RouteMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Initialize map centered on route
    const bounds = L.latLngBounds([
      [trip.originCoords.lat, trip.originCoords.lng] as L.LatLngTuple,
      [trip.destinationCoords.lat, trip.destinationCoords.lng] as L.LatLngTuple,
      ...trip.scheduledStops.map(stop => [stop.location.lat, stop.location.lng] as L.LatLngTuple),
    ]);

    mapInstance.current = L.map(mapRef.current).fitBounds(bounds, { padding: [20, 20] });

    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(mapInstance.current);

    // Custom icons
    const currentLocationIcon = L.divIcon({
      className: 'current-location-marker',
      html: `
        <div style="
          background: hsl(197 71% 52%);
          border: 3px solid white;
          border-radius: 50%;
          width: 20px;
          height: 20px;
          box-shadow: 0 0 0 3px hsl(197 71% 52% / 0.3);
          animation: pulse 2s infinite;
        "></div>
        <style>
          @keyframes pulse {
            0% { box-shadow: 0 0 0 0 hsl(197 71% 52% / 0.3); }
            70% { box-shadow: 0 0 0 10px hsl(197 71% 52% / 0); }
            100% { box-shadow: 0 0 0 0 hsl(197 71% 52% / 0); }
          }
        </style>
      `,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });

    const originIcon = L.divIcon({
      className: 'origin-marker',
      html: `
        <div style="
          background: hsl(142 76% 36%);
          border: 2px solid white;
          border-radius: 50%;
          width: 16px;
          height: 16px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    const destinationIcon = L.divIcon({
      className: 'destination-marker',
      html: `
        <div style="
          background: hsl(0 84% 60%);
          border: 2px solid white;
          border-radius: 50%;
          width: 16px;
          height: 16px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    const chargingStopIcon = L.divIcon({
      className: 'charging-stop-marker',
      html: `
        <div style="
          background: hsl(38 92% 50%);
          border: 2px solid white;
          border-radius: 4px;
          width: 14px;
          height: 14px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        "></div>
      `,
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });

    // Add current location marker
    L.marker([currentLocation.lat, currentLocation.lng], { icon: currentLocationIcon })
      .addTo(mapInstance.current!)
      .bindPopup(`
        <div class="p-2">
          <strong>Current Position</strong><br/>
          <span class="text-sm">Vehicle Location</span>
        </div>
      `);

    // Add origin marker
    L.marker([trip.originCoords.lat, trip.originCoords.lng], { icon: originIcon })
      .addTo(mapInstance.current!)
      .bindPopup(`
        <div class="p-2">
          <strong>${trip.origin}</strong><br/>
          <span class="text-sm text-gray-600">Trip Origin</span>
        </div>
      `);

    // Add destination marker
    L.marker([trip.destinationCoords.lat, trip.destinationCoords.lng], { icon: destinationIcon })
      .addTo(mapInstance.current!)
      .bindPopup(`
        <div class="p-2">
          <strong>${trip.destination}</strong><br/>
          <span class="text-sm text-gray-600">Final Destination</span>
        </div>
      `);

    // Add charging stop markers
    trip.scheduledStops.forEach((stop, index) => {
      L.marker([stop.location.lat, stop.location.lng], { icon: chargingStopIcon })
        .addTo(mapInstance.current!)
        .bindPopup(`
          <div class="p-2">
            <strong>${stop.stationName}</strong><br/>
            <span class="text-sm text-gray-600">Stop ${index + 1}</span><br/>
            <span class="text-sm">Charge: ${stop.chargeDuration} min</span><br/>
            <span class="text-sm">Cost: £${stop.cost.toFixed(2)}</span><br/>
            <span class="text-sm">SOC: ${stop.arrivalSOC}% → ${stop.departureSOC}%</span>
          </div>
        `);
    });

    // Draw route line (simplified - in real app would use routing service)
    const routePoints: L.LatLngExpression[] = [
      [trip.originCoords.lat, trip.originCoords.lng] as L.LatLngTuple,
      ...trip.scheduledStops.map(stop => [stop.location.lat, stop.location.lng] as L.LatLngTuple),
      [trip.destinationCoords.lat, trip.destinationCoords.lng] as L.LatLngTuple,
    ];

    const routeLine = L.polyline(routePoints, {
      color: 'hsl(197 71% 52%)',
      weight: 4,
      opacity: 0.8,
      dashArray: '10, 5',
    }).addTo(mapInstance.current!);

    // Add distance labels
    if (trip.scheduledStops.length > 0) {
      trip.scheduledStops.forEach((stop, index) => {
        const labelPosition = L.latLng(stop.location.lat, stop.location.lng);
        
        L.marker(labelPosition, {
          icon: L.divIcon({
            className: 'distance-label',
            html: `
              <div style="
                background: white;
                border: 1px solid hsl(197 71% 52%);
                border-radius: 12px;
                padding: 2px 6px;
                font-size: 10px;
                font-weight: 500;
                color: hsl(197 71% 52%);
                box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                white-space: nowrap;
              ">
                ${stop.distance}km
              </div>
            `,
            iconSize: [0, 0],
            iconAnchor: [0, -25],
          }),
        }).addTo(mapInstance.current!);
      });
    }

    // Cleanup function
    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, [trip, currentLocation]);

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full rounded-lg" />
      
      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-card border border-border rounded-lg p-3 shadow-lg z-[1000]">
        <h4 className="font-medium text-xs mb-2">Map Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-primary rounded-full border border-white"></div>
            <span>Current Position</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-success rounded-full border border-white"></div>
            <span>Origin</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-warning border border-white"></div>
            <span>Charging Stop</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-destructive rounded-full border border-white"></div>
            <span>Destination</span>
          </div>
        </div>
      </div>
    </div>
  );
}