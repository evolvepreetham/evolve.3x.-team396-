import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { MapPin, Clock, Battery, Zap, PoundSterling } from 'lucide-react';
import { Trip } from '@/utils/mockData';

interface TripDetailsProps {
  trip: Trip;
}

/**
 * Detailed trip information component
 * Shows comprehensive breakdown of trip schedule including charging stops
 * Accessible design with proper heading hierarchy and screen reader support
 */
export function TripDetails({ trip }: TripDetailsProps) {
  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-6">
      {/* Trip Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Trip Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <div>
                <div className="font-medium">{trip.origin}</div>
                <div className="text-sm text-muted-foreground">Origin</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <div>
                <div className="font-medium">{trip.destination}</div>
                <div className="text-sm text-muted-foreground">Destination</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <div>
                <div className="font-medium">{formatTime(trip.startTime)}</div>
                <div className="text-sm text-muted-foreground">Start Time</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Status</span>
              <Badge variant={trip.status === 'In Progress' ? 'default' : 'secondary'}>
                {trip.status}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Duration</span>
              <span className="font-medium">{trip.totalDuration}h</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Total Cost</span>
              <span className="font-medium">£{trip.totalCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Charging Stops</span>
              <span className="font-medium">{trip.scheduledStops.length}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charging Schedule */}
      {trip.scheduledStops.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Charging Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {trip.scheduledStops.map((stop, index) => (
                <div key={stop.stationId} className="space-y-3">
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      {index < trip.scheduledStops.length - 1 && (
                        <div className="w-0.5 h-8 bg-border mt-2"></div>
                      )}
                    </div>
                    
                    <div className="flex-1 space-y-3">
                      <div>
                        <h4 className="font-medium">{stop.stationName}</h4>
                        <p className="text-sm text-muted-foreground">
                          {stop.distance}km from origin
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Battery className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">{stop.arrivalSOC}%</div>
                            <div className="text-muted-foreground">Arrival SOC</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Battery className="w-4 h-4 text-success" />
                          <div>
                            <div className="font-medium">{stop.departureSOC}%</div>
                            <div className="text-muted-foreground">Departure SOC</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">{stop.chargeDuration}min</div>
                            <div className="text-muted-foreground">Charge Time</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <PoundSterling className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium">£{stop.cost.toFixed(2)}</div>
                            <div className="text-muted-foreground">Cost</div>
                          </div>
                        </div>
                      </div>

                      {/* SOC Progress */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Charging Progress</span>
                          <span>{stop.arrivalSOC}% → {stop.departureSOC}%</span>
                        </div>
                        <Progress 
                          value={((stop.departureSOC - stop.arrivalSOC) / (100 - stop.arrivalSOC)) * 100} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  </div>
                  
                  {index < trip.scheduledStops.length - 1 && (
                    <Separator className="my-4" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}