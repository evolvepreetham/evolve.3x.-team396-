import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Battery, Zap, Clock, MapPin, Eye } from 'lucide-react';
import { mockVehicles, mockTrips, mockFleetSummary, type Trip, type Vehicle } from '@/utils/mockData';
import { FleetMap } from '@/components/FleetMap';
import { TripDetails } from '@/components/TripDetails';

/**
 * Main dashboard page for fleet managers
 * Displays overview of entire fleet including vehicles, trips, and charging stations
 * Features responsive design with mobile-first approach
 */
export default function Dashboard() {
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);

  const getStatusBadgeVariant = (status: Vehicle['status']) => {
    switch (status) {
      case 'Charging':
        return 'default';
      case 'En route':
        return 'secondary';
      case 'Idle':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getSOCColor = (soc: number) => {
    if (soc >= 70) return 'text-success';
    if (soc >= 30) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">Fleet Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Monitor your electric vehicle fleet in real-time
        </p>
      </div>

      {/* Fleet Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average SOC</CardTitle>
            <Battery className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockFleetSummary.averageSOC}%</div>
            <Progress value={mockFleetSummary.averageSOC} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Energy Used Today</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockFleetSummary.energyUsedToday} kWh</div>
            <p className="text-xs text-muted-foreground mt-1">
              +12% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Trips</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockFleetSummary.upcomingTripsCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Next in 45 minutes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Vehicles</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mockFleetSummary.activeVehicles - mockFleetSummary.chargingVehicles}/
              {mockFleetSummary.activeVehicles}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {mockFleetSummary.chargingVehicles} charging
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Vehicle Status Table */}
        <Card>
          <CardHeader>
            <CardTitle>Vehicle Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>SOC</TableHead>
                    <TableHead className="hidden md:table-cell">Next Stop</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockVehicles.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{vehicle.id}</div>
                          <div className="text-sm text-muted-foreground hidden sm:block">
                            {vehicle.model}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(vehicle.status)}>
                          {vehicle.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${getSOCColor(vehicle.currentSOC)}`}>
                            {vehicle.currentSOC}%
                          </span>
                          <Battery className="h-4 w-4" />
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {vehicle.nextChargingStop ? (
                          <div className="text-sm">
                            <div>{vehicle.nextChargingStop.stationId}</div>
                            <div className="text-muted-foreground">
                              {vehicle.nextChargingStop.distance}km • {vehicle.nextChargingStop.eta}
                            </div>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Fleet Map */}
        <Card>
          <CardHeader>
            <CardTitle>Fleet Overview</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[400px] w-full">
              <FleetMap vehicles={mockVehicles} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Trips */}
      <Card>
        <CardHeader>
          <CardTitle>Active Trips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockTrips.filter(trip => trip.status !== 'Completed').map((trip) => (
              <div
                key={trip.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-border rounded-lg"
              >
                <div className="space-y-1 sm:space-y-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{trip.id}</span>
                    <Badge variant={trip.status === 'In Progress' ? 'default' : 'secondary'}>
                      {trip.status}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {trip.origin} → {trip.destination}
                  </div>
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <span>{trip.scheduledStops.length} stops</span>
                    <span>£{trip.totalCost.toFixed(2)}</span>
                    <span>{trip.totalDuration}h duration</span>
                  </div>
                </div>
                <div className="mt-3 sm:mt-0">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Trip Details - {trip.id}</DialogTitle>
                      </DialogHeader>
                      <TripDetails trip={trip} />
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}