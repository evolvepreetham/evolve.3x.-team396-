import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  MapPin,
  Navigation,
  Clock,
  Battery,
  Zap,
  Play,
  Square,
  ExternalLink,
} from 'lucide-react';
import { mockTrips, mockVehicles, type Trip, type ChargingStop } from '@/utils/mockData';
import { RouteMap } from '@/components/RouteMap';

/**
 * Driver dashboard for individual vehicle/trip management
 * Provides route visualization, charging session control, and navigation assistance
 * Optimized for mobile use with large touch targets and clear information hierarchy
 */
export default function DriverDashboard() {
  const [selectedTrip] = useState<Trip>(mockTrips[0]); // In real app, this would be dynamic
  const [currentSOC, setCurrentSOC] = useState(68);
  const [isCharging, setIsCharging] = useState(false);
  const [chargingTime, setChargingTime] = useState(0);
  const [selectedVehicle] = useState(mockVehicles[0]);

  // Simulate charging session
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isCharging) {
      interval = setInterval(() => {
        setChargingTime(prev => prev + 1);
        setCurrentSOC(prev => Math.min(prev + 0.5, 100)); // Simulate SOC increase
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCharging]);

  const handleStartCharging = () => {
    setIsCharging(true);
    setChargingTime(0);
  };

  const handleStopCharging = () => {
    setIsCharging(false);
  };

  const openNavigation = (location: { lat: number; lng: number }, name: string) => {
    const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}&travelmode=driving`;
    window.open(googleMapsUrl, '_blank');
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getSOCColor = (soc: number) => {
    if (soc >= 70) return 'text-success';
    if (soc >= 30) return 'text-warning';
    return 'text-destructive';
  };

  const nextStop = selectedTrip.scheduledStops[0]; // In real app, this would be the actual next stop

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">{selectedVehicle.id} - Driver View</h1>
          <p className="text-muted-foreground">
            {selectedTrip.origin} → {selectedTrip.destination}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={selectedTrip.status === 'In Progress' ? 'default' : 'secondary'}>
            {selectedTrip.status}
          </Badge>
          <Badge variant="outline">{selectedVehicle.model}</Badge>
        </div>
      </div>

      {/* Current Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Battery className="w-4 h-4" />
              Current SOC
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getSOCColor(currentSOC)}`}>
              {currentSOC.toFixed(1)}%
            </div>
            <Progress value={currentSOC} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Next Stop
            </CardTitle>
          </CardHeader>
          <CardContent>
            {nextStop ? (
              <div>
                <div className="font-medium text-sm">{nextStop.stationName}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {nextStop.distance}km remaining
                </div>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">No stops planned</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {isCharging ? 'Charging Time' : 'ETA'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">
              {isCharging ? formatTime(chargingTime) : '14:30'}
            </div>
            {isCharging && (
              <div className="text-xs text-muted-foreground mt-1">
                Target: 80% SOC
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant={isCharging ? 'default' : 'secondary'} className="w-full justify-center">
              {isCharging ? 'Charging' : selectedVehicle.status}
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Route Map */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Route Overview</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[400px] w-full">
                <RouteMap trip={selectedTrip} currentLocation={selectedVehicle.currentLocation} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls & Information */}
        <div className="space-y-4">
          {/* Next Stop Details */}
          {nextStop && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Next Charging Stop</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium">{nextStop.stationName}</h4>
                  <p className="text-sm text-muted-foreground">
                    {nextStop.distance}km • {nextStop.chargeDuration}min charge
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Expected SOC</span>
                    <span>{nextStop.arrivalSOC}% → {nextStop.departureSOC}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Cost</span>
                    <span>£{nextStop.cost.toFixed(2)}</span>
                  </div>
                </div>

                <Button
                  onClick={() => openNavigation(nextStop.location, nextStop.stationName)}
                  className="w-full"
                  variant="outline"
                >
                  <Navigation className="w-4 h-4 mr-2" />
                  Navigate
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Charging Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Charging Session</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className={`text-3xl font-bold ${getSOCColor(currentSOC)} mb-2`}>
                  {currentSOC.toFixed(1)}%
                </div>
                <Progress value={currentSOC} className="mb-4" />
                
                {isCharging && (
                  <div className="text-sm text-muted-foreground">
                    Charging for {formatTime(chargingTime)}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={handleStartCharging}
                  disabled={isCharging || currentSOC >= 95}
                  variant={isCharging ? "secondary" : "default"}
                  className="w-full"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start
                </Button>
                <Button
                  onClick={handleStopCharging}
                  disabled={!isCharging}
                  variant={isCharging ? "destructive" : "secondary"}
                  className="w-full"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </Button>
              </div>

              {isCharging && (
                <div className="text-xs text-center text-muted-foreground">
                  Estimated completion: {Math.ceil((80 - currentSOC) * 2)} minutes
                </div>
              )}
            </CardContent>
          </Card>

          {/* Trip Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Trip Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-success rounded-full"></div>
                  <span className="text-sm">Started from {selectedTrip.origin}</span>
                </div>
                
                {selectedTrip.scheduledStops.map((stop, index) => (
                  <div key={stop.stationId} className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${
                      index === 0 ? 'bg-primary' : 'bg-muted'
                    }`}></div>
                    <span className={`text-sm ${
                      index === 0 ? 'font-medium' : 'text-muted-foreground'
                    }`}>
                      {stop.stationName}
                      {index === 0 && ' (Current)'}
                    </span>
                  </div>
                ))}
                
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                  <span className="text-sm text-muted-foreground">
                    Arrive at {selectedTrip.destination}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}